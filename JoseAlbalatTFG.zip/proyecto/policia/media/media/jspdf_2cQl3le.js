<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><meta name="google" content="notranslate"><meta http-equiv="X-UA-Compatible" content="IE=edge;"><style>@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fCRc4EsA.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fABc4EsA.woff2)format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fCBc4EsA.woff2)format('woff2');unicode-range:U+1F00-1FFF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fBxc4EsA.woff2)format('woff2');unicode-range:U+0370-03FF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fCxc4EsA.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fChc4EsA.woff2)format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:300;src:local('Roboto Light'),local('Roboto-Light'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmSU5fBBc4.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu72xKOzY.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu5mxKOzY.woff2)format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu7mxKOzY.woff2)format('woff2');unicode-range:U+1F00-1FFF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4WxKOzY.woff2)format('woff2');unicode-range:U+0370-03FF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu7WxKOzY.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu7GxKOzY.woff2)format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:400;src:local('Roboto Regular'),local('Roboto-Regular'),url(//fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xFIzIFKw.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xMIzIFKw.woff2)format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xEIzIFKw.woff2)format('woff2');unicode-range:U+1F00-1FFF;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xLIzIFKw.woff2)format('woff2');unicode-range:U+0370-03FF;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xHIzIFKw.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xGIzIFKw.woff2)format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Roboto';font-style:italic;font-weight:400;src:local('Roboto Italic'),local('Roboto-Italic'),url(//fonts.gstatic.com/s/roboto/v18/KFOkCnqEu92Fr1Mu51xIIzI.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfCRc4EsA.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfABc4EsA.woff2)format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfCBc4EsA.woff2)format('woff2');unicode-range:U+1F00-1FFF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfBxc4EsA.woff2)format('woff2');unicode-range:U+0370-03FF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfCxc4EsA.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfChc4EsA.woff2)format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Roboto';font-style:normal;font-weight:700;src:local('Roboto Bold'),local('Roboto-Bold'),url(//fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmWUlfBBc4.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}</style><title>jspdf.js - Google Drive</title><meta property="og:title" content="jspdf.js"><meta property="og:type" content="article"><meta property="og:site_name" content="Google Docs"><meta property="og:url" content="https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view?usp=embed_facebook"><meta property="og:image" content="https://lh5.googleusercontent.com/5NdpDP5FdxZuvfF-dV_clnCyYmSXxs5THjSiUzbskdze2rSScvud4g=w1200-h630-p"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><script async="" nonce="undefined" src="jspdf.js%20-%20Google%20Drive_files/cbgapi.loaded_2"></script><script async="" src="jspdf.js%20-%20Google%20Drive_files/cbgapi.loaded_1"></script><script async="" src="jspdf.js%20-%20Google%20Drive_files/cbgapi.loaded_0"></script><script gapi_processed="true" async="" src="jspdf.js%20-%20Google%20Drive_files/client.js"></script><script>(function(){(function(){function e(a){this.t={};this.tick=function(a,c,b){var d=void 0!=b?b:(new Date).getTime();this.t[a]=[d,c];if(void 0==b)try{window.console.timeStamp("CSI/"+a)}catch(h){}};this.tick("start",null,a)}var a;if(window.performance)var d=(a=window.performance.timing)&&a.responseStart;var f=0<d?new e(d):new e;window.jstiming={Timer:e,load:f};if(a){var c=a.navigationStart;0<c&&d>=c&&(window.jstiming.srt=d-c)}if(a){var b=window.jstiming.load;0<c&&d>=c&&(b.tick("_wtsrt",void 0,c),b.tick("wtsrt_","_wtsrt",
d),b.tick("tbsd_","wtsrt_"))}try{a=null,window.chrome&&window.chrome.csi&&(a=Math.floor(window.chrome.csi().pageT),b&&0<c&&(b.tick("_tbnd",void 0,window.chrome.csi().startE),b.tick("tbnd_","_tbnd",c))),null==a&&window.gtbExternal&&(a=window.gtbExternal.pageT()),null==a&&window.external&&(a=window.external.pageT,b&&0<c&&(b.tick("_tbnd",void 0,window.external.startE),b.tick("tbnd_","_tbnd",c))),a&&(window.jstiming.pt=a)}catch(g){}})();}).call(this);
</script><script>window.gapi_onload=function(){};var scriptEl$jscomp$inline_0=document.createElement("script");scriptEl$jscomp$inline_0.src="https://apis.google.com/js/client.js";scriptEl$jscomp$inline_0.async=!0;var firstScriptEl$jscomp$inline_1=document.getElementsByTagName("script")[0];firstScriptEl$jscomp$inline_1.parentNode.insertBefore(scriptEl$jscomp$inline_0,firstScriptEl$jscomp$inline_1);
</script><link rel="shortcut icon" href="https://ssl.gstatic.com/docs/doclist/images/icon_14_text_favicon.ico"><link rel="stylesheet" href="jspdf.js%20-%20Google%20Drive_files/2666356592-projector_css_ltr.css">
<script>_docs_flag_initialData={"docs-ails":"docs_cold","docs-fwds":"docs_sdf","docs-crs":"docs_crs_nfd","docs-decs":0,"info_params":{"token":"-XeOWWMBAAA.MkQy31heTwxGnpsGsDmjkQ.3m8OrO5HftIjsSXFwyceyQ"},"docosEmbedApiJs":"//docs.google.com/comments/u/0/d/AAHRpnXvNNaZ4CvpU4y30CDwOliD2aov4Vyjbeewj2co9wx51ONgrorddXZ_OxwFMIzSTG_CJhgl0QsyUqbowcqwhlGBeWgt2gg/api/js?hl\u003des\u0026token\u003dAGNctVZ9ZqgVjeb7OOdgXBQE_k99rQ90fQ:1526215779129","docs-edcsp":false,"uls":"{\"langs\":[\"es\"],\"itcs\":[],\"override\":\"\",\"selected\":\"\",\"activated\":false}","icso":false,"docs-obsImUrl":"https://ssl.gstatic.com/docs/common/cleardot.gif","docs_oogt":"NONE","docs-ce":false,"buildLabel":"texmex_2018.17-Thu_RC03","docs-show_debug_info":false,"ondlburl":"https://docs.google.com","drive_url":"https://drive.google.com?authuser\u003d0","app_url":"https://drive.google.com/file/?authuser\u003d0","docs-mid":2048,"docs-eicd":false,"docs-icdmt":[],"docs-sup":"/file","docs-seu":"https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/edit","docs-ecvca":false,"docs-uptc":["lsrp","noreplica","ouid","dl","usp","urp","utm_source","utm_medium","utm_campaign","utm_term","utm_content","sle"],"docs-doddn":"","docs-dodn":"","docs-uddn":"","docs-udn":"","docs-cwsd":"","docs-al":[0,0,0,1,0],"docs-ndt":"Untitled Texmex","docs-prn":"","docs-rpe":false,"docs-sfcnidt":false,"docs-ecat":false,"docs-sfcnidtwi":false,"docs-as":"","docs-etdimo":false,"docs-mdck":"","docs-etiff":false,"docs-spfe":true,"docs-mriim":1800000,"docs-eccbs":false,"docos-sosj":false,"docs-rlmp":false,"docs-mmpt":15000,"docs-erd":false,"docs-erfar":false,"docs-ensb":false,"docs-ddts":false,"docs-uootuns":false,"docs-amawso":false,"docs-mdso":false,"docs-ofmpp":false,"docs-anlpfdo":false,"docs-esdc":false,"docs-esdcf":false,"docs-fwswmrrfn":false,"docs-pid":"104870249889718419468","ecid":true,"docs-pedd":true,"docs-eir":false,"docs-edll":false,"docs-eivu":false,"server_time_ms":1526215779135,"gaia_session_id":"0","app-bc":"#d1d1d1","enable_iframed_embed_api":true,"docs-fut":"https://drive.google.com?authuser\u003d0#folders/{folderId}","esid":true,"esubid":false,"docs-etbs":true,"docs-isb":false,"docs-enct":false,"docs-emtrlrc":false,"docs-emtrb1r":false,"docs-mtrb1c":"","docs-mtrb2c":"","docs-mtrb3c":"","docs-agdc":false,"docs-anddc":true,"docs-efts":false,"docs-tdd":false,"docs-dwc":false,"docs-elds":false,"docs-esdp":false,"docs-rsc":"","docs-eppd":false,"docs-elmc":false,"docs-edtoc":false,"docs-eddm":false,"docs-ebidu":false,"docs-fwd":false,"docs-elsr":false,"docs-sasic":false,"docs-eoaip":false,"docs-emtrb2r":false,"docs-mcssa":false,"docs-esdttfl":false,"docs-eflimt":false,"docs-depquafr":false,"docs-rldce":false,"docs-amcacd":false,"docs-frbanmc":false,"docs-daa":false,"docs-emtrb3r":false,"docs-ssi":false,"docs-mib":5242880,"docs-mip":6250000,"docs-cp":false,"docs-dom":false,"enable_kennedy":true,"docs-gth":"","projector_view_url":"https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view?usp\u003ddocs_web","opendv":false,"onePickImportDocumentUrl":"","opmbs":5242880,"opmpd":2500,"opbu":"https://docs.google.com/picker","opru":"https://drive.google.com/relay.html","opdu":true,"opccp":false,"ophi":"texmex","opst":"000770F203AEAB814E1E42AA5511E39FBEBB636373CF22CB03::1526215779138","opuci":"","docs-to":"https://drive.google.com","docs-eopiiv2":false,"docs-eopiiv2wc":false,"jobset":"prod","docs-ealre":false,"docs-ecad":false,"docs-se":false,"docs-corsbc":true,"docs-spdy":true,"xdbcfAllowHostNamePrefix":true,"xdbcfAllowXpc":true,"docs-iror":true,"enable_pinned_revisions":false,"enable_edit_blob_revisions":false,"upload_url":"https://drive.google.com/upload/resumableupload?authuser\u003d0","enable_toolbar":true,"enable_link_opener":true,"promo_url":"","promo_title":"","promo_title_prefix":"","promo_content_html":"","promo_link_text":"","promo_element_id":"","promo_orientation":1,"promo_arrow_alignment":0,"promo_show_on_click":false,"promo_hide_arrow":false,"promo_show_on_load":false,"promo_mark_dismissed_on_show":false,"promo_use_global_preference":false,"promo_close_button_text":"","promo_icon_url":"","promo_action_id":"","promo_impression_id":0,"enable_microscope":true,"enable_manage_timed_text":true,"video_embed_type":"PREFER_FLASH","enable_maps_embed":false,"maps_api_uri":"https://maps.googleapis.com/maps/api/js?key\u003dAIzaSyBCjpnguVjzi6vS67NdBtyYuvCYz3yBxCY\u0026sensor\u003dfalse","maps_display_uri":"https://maps.google.com/maps","docs-epcc":false,"docs_abuse_link":"https://docs.google.com/abuse?id\u003d0BwHqLHKAfVJeUGVDRmw1aWZCQUk","enable_csi":true,"csi_service_name":"texmex","docs-msoil":"docs_kansas","docs-fsd":false}; _docs_flag_cek= null ;</script><script>;this.gbar_={CONFIG:[[[0,"www.gstatic.com","og.qtm.en_US.Kt71ixIAUsI.O","es","es","25",0,[4,2,".40.40.40.40.40.40.","","1300102,3700062,3700209,3700282,3700489,3700521","195607034","0"],null,"YzT4WpHCB-nO5gKru7SgDg",null,0,"og.qtm.1bx7hm4kz4gqj.L.F4.O","AA2YrTuG3aV28Uy2-ES-xuamSB8mj-KVYg","AA2YrTvppCLL-fVOKeHJBD2efsgZHezqLA","",2,0,200,"ESP",null,null,"25","25",1],null,null,null,[1,0,0,null,"0","proyectojosealbalat@gmail.com","","AEz_aqWxUjtzF6KL69MQKQQPrvBdV6_Xjk2ugdz7lD9c_oUiLcnTlmKcIkXYDZU5zqs9ozbi1d4oXO9KViaTDCoq4RBTdYZ76w"],[0,0,"",1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,"","","","","","","",0,0,0],["%1$s (predeterminada)","Cuenta de marca",1,"%1$s (delegada)",1,null,96,"/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view?authuser=$authuser",null,null,null,1,"https://accounts.google.com/ListAccounts?authuser=0\u0026pid=25\u0026gpsia=1\u0026source=ogb\u0026mo=1\u0026mn=1\u0026hl=es",0,"dashboard",null,null,null,null,"Perfil","",1,null,"Se ha cerrado la sesión","https://accounts.google.com/AccountChooser?source=ogb\u0026continue=$continue\u0026Email=$email","https://accounts.google.com/RemoveLocalAccount?source=ogb\u0026Email=$email","QUITAR","INICIAR SESIÓN",0,0,1,0,1,0,0,"000770F2034D42BDFBF3F4D26046A1EE21047B820E26E4923D::1526215779125"],null,["1","gci_91f30755d6a6b787dcc2a4062e6e9824.js","googleapis.client:plusone:gapi.iframes","0","es"],null,null,null,[1,null,null,"[[]]",["https","ogs.google.com",0,"/u/0","rt=j\u0026sourceid=25",["/u/0/_/og/customization/get",""],["/u/0/_/og/customization/set",""],["/u/0/_/og/customization/remove",""]],"AEz_aqWxUjtzF6KL69MQKQQPrvBdV6_Xjk2ugdz7lD9c_oUiLcnTlmKcIkXYDZU5zqs9ozbi1d4oXO9KViaTDCoq4RBTdYZ76w"],["m;/_/scs/abc-static/_/js/k=gapi.gapi.en.EKLzTAFgbdI.O/m=__features__/rt=j/d=1/rs=AHpOoo8apauHMW38EVl_zJQ-P1rw34TUnw","https://apis.google.com","","","1","",null,1,"es_plusone_gc_20180425.0_p0","es"],[0.009999999776482582,"es","25",[null,"","w",null,1,5184000,1,0,"",0,1,"",0,0,null,0,0],null,[["","","0",0,0,-1]],null,0,null,null,["5061451","google\\.(com|ru|ca|by|kz|com\\.mx|com\\.tr)$",1]],[1,0.1000000014901161,0,40400,25,"ESP","es","195607034.0",8,0.001000000047497451,1,0],[[null,null,null,"https://www.gstatic.com/og/_/js/k=og.qtm.en_US.Kt71ixIAUsI.O/rt=j/m=qgl,q_d,qdid,qmutsd/exm=qaaw,qabr,qadd,qaid,qalo,qano,qebr,qein,qhaw,qhbr,qhch,qhga,qhid,qhin,qhlo,qhmn,qhno,qhpc,qhpr,qhsf,qhtb,qhtt/d=1/ed=1/rs=AA2YrTuG3aV28Uy2-ES-xuamSB8mj-KVYg"],[null,null,null,"https://www.gstatic.com/og/_/ss/k=og.qtm.1bx7hm4kz4gqj.L.F4.O/m=q_d,qdid/excm=qaaw,qabr,qadd,qaid,qalo,qano,qebr,qein,qhaw,qhbr,qhch,qhga,qhid,qhin,qhlo,qhmn,qhno,qhpc,qhpr,qhsf,qhtb,qhtt/d=1/ed=1/rs=AA2YrTvppCLL-fVOKeHJBD2efsgZHezqLA"]],null,null,[""]]],};/* _GlobalPrefix_ */
this.gbar_=this.gbar_||{};(function(_){var window=this;
/* _Module_:qhin */
try{
var ba,ha,ia,ja,ta,ua;_.aa="function"==typeof Object.create?Object.create:function(a){var c=function(){};c.prototype=a;return new c};if("function"==typeof Object.setPrototypeOf)ba=Object.setPrototypeOf;else{var ca;a:{var da={jg:!0},ea={};try{ea.__proto__=da;ca=ea.jg;break a}catch(a){}ca=!1}ba=ca?function(a,c){a.__proto__=c;if(a.__proto__!==c)throw new TypeError(a+" is not extensible");return a}:null}_.fa=ba;
ha="function"==typeof Object.defineProperties?Object.defineProperty:function(a,c,d){a!=Array.prototype&&a!=Object.prototype&&(a[c]=d.value)};ia="undefined"!=typeof window&&window===this?this:"undefined"!=typeof window.global&&null!=window.global?window.global:this;ja=function(a,c){if(c){var d=ia;a=a.split(".");for(var e=0;e<a.length-1;e++){var f=a[e];f in d||(d[f]={});d=d[f]}a=a[a.length-1];e=d[a];c=c(e);c!=e&&null!=c&&ha(d,a,{configurable:!0,writable:!0,value:c})}};
ja("String.prototype.startsWith",function(a){return a?a:function(a,d){if(null==this)throw new TypeError("The 'this' value for String.prototype.startsWith must not be null or undefined");if(a instanceof RegExp)throw new TypeError("First argument to String.prototype.startsWith must not be a regular expression");var c=this.length,f=a.length;d=Math.max(0,Math.min(d|0,this.length));for(var g=0;g<f&&d<c;)if(this[d++]!=a[g++])return!1;return g>=f}});ja("Number.MAX_SAFE_INTEGER",function(){return 9007199254740991});
_.ka=_.ka||{};_.l=this;_.la=function(a){return void 0!==a};_.n=function(a){return"string"==typeof a};_.ma=function(a){return"number"==typeof a};_.na=function(){};_.oa=function(a){a.te=void 0;a.ra=function(){return a.te?a.te:a.te=new a}};
_.pa=function(a){var c=typeof a;if("object"==c)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return c;var d=Object.prototype.toString.call(a);if("[object Window]"==d)return"object";if("[object Array]"==d||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==d||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==c&&"undefined"==typeof a.call)return"object";return c};_.p=function(a){return"array"==_.pa(a)};_.qa=function(a){return"function"==_.pa(a)};_.ra=function(a){var c=typeof a;return"object"==c&&null!=a||"function"==c};_.sa="closure_uid_"+(1E9*Math.random()>>>0);ta=function(a,c,d){return a.call.apply(a.bind,arguments)};
ua=function(a,c,d){if(!a)throw Error();if(2<arguments.length){var e=Array.prototype.slice.call(arguments,2);return function(){var d=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(d,e);return a.apply(c,d)}}return function(){return a.apply(c,arguments)}};_.r=function(a,c,d){Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?_.r=ta:_.r=ua;return _.r.apply(null,arguments)};_.va=Date.now||function(){return+new Date};
_.u=function(a,c){a=a.split(".");var d=_.l;a[0]in d||"undefined"==typeof d.execScript||d.execScript("var "+a[0]);for(var e;a.length&&(e=a.shift());)!a.length&&_.la(c)?d[e]=c:d[e]&&d[e]!==Object.prototype[e]?d=d[e]:d=d[e]={}};_.v=function(a,c){function d(){}d.prototype=c.prototype;a.J=c.prototype;a.prototype=new d;a.prototype.constructor=a;a.kk=function(a,d,g){for(var e=Array(arguments.length-2),f=2;f<arguments.length;f++)e[f-2]=arguments[f];return c.prototype[d].apply(a,e)}};
_.wa=function(a){if(Error.captureStackTrace)Error.captureStackTrace(this,_.wa);else{var c=Error().stack;c&&(this.stack=c)}a&&(this.message=String(a))};_.v(_.wa,Error);_.wa.prototype.name="CustomError";_.xa=Array.prototype.indexOf?function(a,c){return Array.prototype.indexOf.call(a,c,void 0)}:function(a,c){if(_.n(a))return _.n(c)&&1==c.length?a.indexOf(c,0):-1;for(var d=0;d<a.length;d++)if(d in a&&a[d]===c)return d;return-1};_.za=Array.prototype.forEach?function(a,c,d){Array.prototype.forEach.call(a,c,d)}:function(a,c,d){for(var e=a.length,f=_.n(a)?a.split(""):a,g=0;g<e;g++)g in f&&c.call(d,f[g],g,a)};
_.Aa=Array.prototype.filter?function(a,c,d){return Array.prototype.filter.call(a,c,d)}:function(a,c,d){for(var e=a.length,f=[],g=0,h=_.n(a)?a.split(""):a,m=0;m<e;m++)if(m in h){var q=h[m];c.call(d,q,m,a)&&(f[g++]=q)}return f};_.Ba=Array.prototype.map?function(a,c,d){return Array.prototype.map.call(a,c,d)}:function(a,c,d){for(var e=a.length,f=Array(e),g=_.n(a)?a.split(""):a,h=0;h<e;h++)h in g&&(f[h]=c.call(d,g[h],h,a));return f};
_.Da=Array.prototype.some?function(a,c){return Array.prototype.some.call(a,c,void 0)}:function(a,c){for(var d=a.length,e=_.n(a)?a.split(""):a,f=0;f<d;f++)if(f in e&&c.call(void 0,e[f],f,a))return!0;return!1};_.Ea=function(a,c){return 0<=(0,_.xa)(a,c)};
var Ga;_.Fa=String.prototype.trim?function(a){return a.trim()}:function(a){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]};
_.Ia=function(a,c){var d=0;a=(0,_.Fa)(String(a)).split(".");c=(0,_.Fa)(String(c)).split(".");for(var e=Math.max(a.length,c.length),f=0;0==d&&f<e;f++){var g=a[f]||"",h=c[f]||"";do{g=/(\d*)(\D*)(.*)/.exec(g)||["","","",""];h=/(\d*)(\D*)(.*)/.exec(h)||["","","",""];if(0==g[0].length&&0==h[0].length)break;d=Ga(0==g[1].length?0:(0,window.parseInt)(g[1],10),0==h[1].length?0:(0,window.parseInt)(h[1],10))||Ga(0==g[2].length,0==h[2].length)||Ga(g[2],h[2]);g=g[3];h=h[3]}while(0==d)}return d}; Ga=function(a,c){return a<c?-1:a>c?1:0};
a:{var Ka=_.l.navigator;if(Ka){var La=Ka.userAgent;if(La){_.Ja=La;break a}}_.Ja=""}_.x=function(a){return-1!=_.Ja.indexOf(a)};var Ma;Ma="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");_.Na=function(a,c){for(var d,e,f=1;f<arguments.length;f++){e=arguments[f];for(d in e)a[d]=e[d];for(var g=0;g<Ma.length;g++)d=Ma[g],Object.prototype.hasOwnProperty.call(e,d)&&(a[d]=e[d])}};
var Oa;_.Pa=function(){return _.x("Safari")&&!(Oa()||_.x("Coast")||_.x("Opera")||_.x("Edge")||_.x("Silk")||_.x("Android"))};Oa=function(){return(_.x("Chrome")||_.x("CriOS"))&&!_.x("Edge")};_.Qa=function(){return _.x("Android")&&!(Oa()||_.x("Firefox")||_.x("Opera")||_.x("Silk"))};
_.Ra=function(){return _.x("iPhone")&&!_.x("iPod")&&!_.x("iPad")};_.Sa=function(){return _.Ra()||_.x("iPad")||_.x("iPod")};_.Ta=function(a){_.Ta[" "](a);return a};_.Ta[" "]=_.na;var Va=function(a,c){var d=Ua;return Object.prototype.hasOwnProperty.call(d,a)?d[a]:d[a]=c(a)};var jb,kb,Ua,sb;_.Wa=_.x("Opera");_.y=_.x("Trident")||_.x("MSIE");_.Xa=_.x("Edge");_.Ya=_.Xa||_.y;_.Za=_.x("Gecko")&&!(-1!=_.Ja.toLowerCase().indexOf("webkit")&&!_.x("Edge"))&&!(_.x("Trident")||_.x("MSIE"))&&!_.x("Edge");_.$a=-1!=_.Ja.toLowerCase().indexOf("webkit")&&!_.x("Edge");_.ab=_.x("Macintosh");_.bb=_.x("Windows");_.cb=_.x("Linux")||_.x("CrOS");_.db=_.x("Android");_.eb=_.Ra();_.fb=_.x("iPad");_.gb=_.x("iPod");_.hb=_.Sa();jb=function(){var a=_.l.document;return a?a.documentMode:void 0};
a:{var lb="",mb=function(){var a=_.Ja;if(_.Za)return/rv:([^\);]+)(\)|;)/.exec(a);if(_.Xa)return/Edge\/([\d\.]+)/.exec(a);if(_.y)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);if(_.$a)return/WebKit\/(\S+)/.exec(a);if(_.Wa)return/(?:Version)[ \/]?(\S+)/.exec(a)}();mb&&(lb=mb?mb[1]:"");if(_.y){var nb=jb();if(null!=nb&&nb>(0,window.parseFloat)(lb)){kb=String(nb);break a}}kb=lb}_.ob=kb;Ua={};_.pb=function(a){return Va(a,function(){return 0<=_.Ia(_.ob,a)})};_.rb=function(a){return Number(qb)>=a}; var tb=_.l.document;sb=tb&&_.y?jb()||("CSS1Compat"==tb.compatMode?(0,window.parseInt)(_.ob,10):5):void 0;var qb=sb;
_.ub=_.x("Firefox");_.vb=_.Ra()||_.x("iPod");_.wb=_.x("iPad");_.xb=_.Qa();_.yb=Oa();_.zb=_.Pa()&&!_.Sa();var Ab=null;var Db,Fb;_.z=function(){};_.Bb="function"==typeof window.Uint8Array;_.A=function(a,c,d,e,f){a.b=null;c||(c=d?[d]:[]);a.F=d?String(d):void 0;a.w=0===d?-1:0;a.j=c;a:{if(a.j.length&&(c=a.j.length-1,(d=a.j[c])&&"object"==typeof d&&!_.p(d)&&!(_.Bb&&d instanceof window.Uint8Array))){a.A=c-a.w;a.o=d;break a}-1<e?(a.A=e,a.o=null):a.A=Number.MAX_VALUE}a.D={};if(f)for(e=0;e<f.length;e++)c=f[e],c<a.A?(c+=a.w,a.j[c]=a.j[c]||_.Cb):(Db(a),a.o[c]=a.o[c]||_.Cb)};_.Cb=[];
Db=function(a){var c=a.A+a.w;a.j[c]||(a.o=a.j[c]={})};_.B=function(a,c){if(c<a.A){c+=a.w;var d=a.j[c];return d===_.Cb?a.j[c]=[]:d}if(a.o)return d=a.o[c],d===_.Cb?a.o[c]=[]:d};_.C=function(a,c,d){a=_.B(a,c);return null==a?d:a};_.D=function(a,c,d){c<a.A?a.j[c+a.w]=d:(Db(a),a.o[c]=d)};_.E=function(a,c,d){a.b||(a.b={});if(!a.b[d]){var e=_.B(a,d);e&&(a.b[d]=new c(e))}return a.b[d]};Fb=function(a){if(a.b)for(var c in a.b){var d=a.b[c];if(_.p(d))for(var e=0;e<d.length;e++)d[e]&&d[e].Tb();else d&&d.Tb()}};
_.z.prototype.Tb=function(){Fb(this);return this.j};
_.z.prototype.f=_.Bb?function(){var a=window.Uint8Array.prototype.toJSON;window.Uint8Array.prototype.toJSON=function(){if(!Ab){Ab={};for(var a=0;65>a;a++)Ab[a]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(a)}a=Ab;for(var d=[],e=0;e<this.length;e+=3){var f=this[e],g=e+1<this.length,h=g?this[e+1]:0,m=e+2<this.length,q=m?this[e+2]:0,t=f>>2;f=(f&3)<<4|h>>4;h=(h&15)<<2|q>>6;q&=63;m||(q=64,g||(h=64));d.push(a[t],a[f],a[h],a[q])}return d.join("")};try{return JSON.stringify(this.j&&
this.Tb(),Gb)}finally{window.Uint8Array.prototype.toJSON=a}}:function(){return JSON.stringify(this.j&&this.Tb(),Gb)};var Gb=function(a,c){return _.ma(c)&&((0,window.isNaN)(c)||window.Infinity===c||-window.Infinity===c)?String(c):c};_.z.prototype.toString=function(){Fb(this);return this.j.toString()};
_.F=function(){this.Ga=this.Ga;this.Bb=this.Bb};_.F.prototype.Ga=!1;_.F.prototype.ha=function(){this.Ga||(this.Ga=!0,this.O())};_.F.prototype.O=function(){if(this.Bb)for(;this.Bb.length;)this.Bb.shift()()};var Hb=function(a){_.A(this,a,0,-1,null)};_.v(Hb,_.z);_.Ib=function(a){_.A(this,a,0,-1,null)};_.v(_.Ib,_.z);_.Jb=function(a){_.A(this,a,0,-1,null)};_.v(_.Jb,_.z);var Kb=function(a){_.F.call(this);this.j=a;this.b=[];this.f={}};_.v(Kb,_.F);Kb.prototype.rd=function(){for(var a=this.b.length,c=this.b,d=[],e=0;e<a;++e){var f=c[e].b();a:{var g=this.j;for(var h=f.split("."),m=h.length,q=0;q<m;++q)if(g[h[q]])g=g[h[q]];else{g=null;break a}g=g instanceof Function?g:null}if(g&&g!=this.f[f])try{c[e].rd(g)}catch(t){}else d.push(c[e])}this.b=d.concat(c.slice(a))};
var Lb=function(a){_.F.call(this);this.A=a;this.j=this.b=null;this.w=0;this.o={};this.f=!1;a=window.navigator.userAgent;0<=a.indexOf("MSIE")&&0<=a.indexOf("Trident")&&(a=/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a))&&a[1]&&9>(0,window.parseFloat)(a[1])&&(this.f=!0)};_.v(Lb,_.F);Lb.prototype.B=function(a,c){this.b=c;this.j=a;c.preventDefault?c.preventDefault():c.returnValue=!1};
_.Nb=function(a){_.A(this,a,0,-1,null)};_.v(_.Nb,_.z);_.Ob=function(a){_.A(this,a,0,-1,null)};_.v(_.Ob,_.z);_.G=function(a,c){return null!=a?!!a:!!c};_.H=function(a,c){void 0==c&&(c="");return null!=a?a:c};_.I=function(a,c){void 0==c&&(c=0);return null!=a?a:c};var Pb,Sb,Rb;_.Qb=function(a){var c=window.google&&window.google.logUrl?"":"https://www.google.com";c+="/gen_204?";c+=a.f(2040-c.length);Pb(c)};Pb=function(a){var c=new window.Image,d=Rb;c.onerror=c.onload=c.onabort=function(){d in Sb&&delete Sb[d]};Sb[Rb++]=c;c.src=a};Sb=[];Rb=0;
var Tb=function(a){this.b=a};Tb.prototype.log=function(a,c){try{if(this.B(a)){var d=this.j(a,c);this.f(d)}}catch(e){}};Tb.prototype.f=function(a){this.b?a.b():_.Qb(a)};_.Ub=function(){this.data={}};_.Ub.prototype.b=function(){window.console&&window.console.log&&window.console.log("Log data: ",this.data)};_.Ub.prototype.f=function(a){var c=[],d;for(d in this.data)c.push((0,window.encodeURIComponent)(d)+"="+(0,window.encodeURIComponent)(String(this.data[d])));return("atyp=i&zx="+(new Date).getTime()+"&"+c.join("&")).substr(0,a)};
var Vb=function(a,c){this.data={};var d=_.E(a,Hb,8)||new Hb;this.data.ei=window.google&&window.google.kEI?window.google.kEI:_.H(_.B(a,10));this.data.ogf=_.H(_.B(d,3));var e=window.google&&window.google.sn?/.*hp$/.test(window.google.sn)?!1:!0:_.G(_.B(a,7));this.data.ogrp=e?"1":"";this.data.ogv=_.H(_.B(d,6))+"."+_.H(_.B(d,7));this.data.ogd=_.H(_.B(a,21));this.data.ogc=_.H(_.B(a,20));this.data.ogl=_.H(_.B(a,5));c&&(this.data.oggv=c)};_.v(Vb,_.Ub);
_.Wb=function(a,c,d,e,f){Vb.call(this,a,c);_.Na(this.data,{jexpid:_.H(_.B(a,9)),srcpg:"prop="+_.H(_.B(a,6)),jsr:Math.round(1/e),emsg:d.name+":"+d.message});if(f){f._sn&&(f._sn="og."+f._sn);for(var g in f)this.data[(0,window.encodeURIComponent)(g)]=f[g]}};_.v(_.Wb,Vb);
var Xb=function(a){_.A(this,a,0,-1,null)};_.v(Xb,_.z);_.Yb=function(a){_.A(this,a,0,-1,null)};_.v(_.Yb,_.z);var dc;_.Zb=function(){this.b={};this.f={}};_.oa(_.Zb);_.ac=function(a,c){var d=_.Zb.ra();if(a in d.b){if(d.b[a]!=c)throw new $b(a);}else{d.b[a]=c;if(c=d.f[a])for(var e=0,f=c.length;e<f;e++)c[e].b(d.b,a);delete d.f[a]}};_.cc=function(a,c){if(c in a.b)return a.b[c];throw new bc(c);};dc=function(){_.wa.call(this)};_.v(dc,_.wa);var $b=function(){_.wa.call(this)};_.v($b,dc);var bc=function(){_.wa.call(this)};_.v(bc,dc);
_.ec=function(a,c,d,e){this.b=e;this.L=c;this.Ga=d;this.w=_.I(+_.C(a,2,.001),.001);this.F=_.G(_.B(a,1))&&Math.random()<this.w;this.C=_.I(_.C(a,3,1),1);this.A=0;this.o=null;this.D=_.G(_.C(a,4,!0),!0)};_.v(_.ec,Tb);_.ec.prototype.log=function(a,c){_.ec.J.log.call(this,a,c);if(this.b&&this.D)throw a;};_.ec.prototype.B=function(){return this.b||this.F&&this.A<this.C};_.ec.prototype.j=function(a,c){try{return(this.o||_.cc(_.Zb.ra(),"lm")).b(a,c)}catch(d){return new _.Wb(this.L,this.Ga,a,this.w,c)}}; _.ec.prototype.f=function(a){_.ec.J.f.call(this,a);this.A++};
var fc=[1,2,3,4,5,6,9,10,11,13,14,28,29,30,34,35,37,38,39,40,41,42,43,48,49,50,51,52,53,55,56,57,58,59,62,500],hc=function(a,c,d,e,f,g){Vb.call(this,a,c);_.Na(this.data,{oge:e,ogex:_.H(_.B(a,9)),ogp:_.H(_.B(a,6)),ogsr:Math.round(1/(gc(e)?_.I(+_.C(d,3,1)):_.I(+_.C(d,2,1E-4)))),ogus:f});if(g){"ogw"in g&&(this.data.ogw=g.ogw,delete g.ogw);"ved"in g&&(this.data.ved=g.ved,delete g.ved);a=[];for(var h in g)0!=a.length&&a.push(","),a.push(h.replace(".","%2E").replace(",","%2C")),a.push("."),a.push(g[h].replace(".", "%2E").replace(",","%2C"));g=a.join("");""!=g&&(this.data.ogad=g)}};_.v(hc,Vb);var ic=null,gc=function(a){if(!ic){ic={};for(var c=0;c<fc.length;c++)ic[fc[c]]=!0}return!!ic[a]};
var jc=function(a,c,d,e,f){this.b=f;this.F=a;this.D=c;this.L=e;this.C=_.I(+_.C(a,2,1E-4),1E-4);this.A=_.I(+_.C(a,3,1),1);c=Math.random();this.w=_.G(_.B(a,1))&&c<this.C;this.o=_.G(_.B(a,1))&&c<this.A;a=0;_.G(_.B(d,1))&&(a|=1);_.G(_.B(d,2))&&(a|=2);_.G(_.B(d,3))&&(a|=4);this.Ga=a};_.v(jc,Tb);jc.prototype.B=function(a){return this.b||(gc(a)?this.o:this.w)};jc.prototype.j=function(a,c){return new hc(this.D,this.L,this.F,a,this.Ga,c)};
var kc=function(a){this.b=a;this.f=void 0;this.j=[]};kc.prototype.then=function(a,c,d){this.j.push(new lc(a,c,d));_.mc(this)};_.mc=function(a){if(0<a.j.length){var c=void 0!==a.b,d=void 0!==a.f;if(c||d){c=c?a.o:a.A;d=a.j;a.j=[];try{(0,_.za)(d,c,a)}catch(e){window.console.error(e)}}}};kc.prototype.o=function(a){a.f&&a.f.call(a.b,this.b)};kc.prototype.A=function(a){a.j&&a.j.call(a.b,this.f)};var lc=function(a,c,d){this.f=a;this.j=c;this.b=d};
_.J=function(){this.f=new kc;this.b=new kc;this.w=new kc;this.o=new kc;this.A=new kc;this.B=new kc;this.C=new kc;this.j=new kc};_.oa(_.J);_.k=_.J.prototype;_.k.Mg=function(){return this.f};_.k.Vg=function(){return this.b};_.k.$g=function(){return this.w};_.k.Tg=function(){return this.o};_.k.Yg=function(){return this.A};_.k.ah=function(){return this.B};_.k.Qg=function(){return this.C};_.k.Rg=function(){return this.j};
var nc=function(a){_.A(this,a,0,-1,null)};_.v(nc,_.z);_.pc=function(){return _.E(_.oc,_.Ib,1)};_.qc=function(){return _.E(_.oc,_.Jb,5)};var rc;window.gbar_&&window.gbar_.CONFIG?rc=window.gbar_.CONFIG[0]||{}:rc=[];_.oc=new nc(rc);_.u("gbar_._DumpException",function(a){if(this._D)throw a;_.K?_.K.log(a):window.console.error(a)});var sc,tc,vc,wc,xc;sc=_.E(_.oc,_.Yb,3)||new _.Yb;tc=_.pc()||new _.Ib;_.K=new _.ec(sc,tc,"quantum:gapiBuildLabel",!1);vc=_.pc()||new _.Ib;wc=_.qc()||new _.Jb;xc=_.E(_.oc,Xb,4)||new Xb;_.uc=new jc(xc,vc,wc,"quantum:gapiBuildLabel",!1);_.yc=new Lb(_.K);_.uc.log(8,{m:"BackCompat"==window.document.compatMode?"q":"s"});_.u("gbar.A",kc);kc.prototype.aa=kc.prototype.then;_.u("gbar.B",_.J);_.J.prototype.ba=_.J.prototype.Vg;_.J.prototype.bb=_.J.prototype.$g;_.J.prototype.bd=_.J.prototype.Yg;_.J.prototype.be=_.J.prototype.ah;_.J.prototype.bf=_.J.prototype.Mg;_.J.prototype.bg=_.J.prototype.Tg;_.J.prototype.bh=_.J.prototype.Qg;_.J.prototype.bi=_.J.prototype.Rg;_.u("gbar.a",_.J.ra());var zc=new Kb(window);_.ac("api",zc); var Ac=_.qc()||new _.Jb,Bc=_.H(_.B(Ac,8));window.__PVT=Bc;_.ac("eq",_.yc);

}catch(e){_._DumpException(e)}
/* _Module_:qhga */
try{
var Cc=function(a){_.A(this,a,0,-1,null)};_.v(Cc,_.z);var Dc=function(){_.F.call(this);this.f=[];this.b=[]};_.v(Dc,_.F);Dc.prototype.j=function(a,c){this.f.push({sd:a,options:c})};Dc.prototype.init=function(a,c,d){window.gapi={};var e=window.___jsl={};e.h=_.H(_.B(a,1));e.ms=_.H(_.B(a,2));e.m=_.H(_.B(a,3));e.l=[];_.B(c,1)&&(a=_.B(c,3))&&this.b.push(a);_.B(d,1)&&(d=_.B(d,2))&&this.b.push(d);_.u("gapi.load",(0,_.r)(this.j,this));return this};
var Ec=_.E(_.oc,_.Nb,14)||new _.Nb,Fc=_.E(_.oc,_.Ob,9)||new _.Ob,Gc=new Cc,Hc=new Dc;Hc.init(Ec,Fc,Gc);_.ac("gs",Hc);
}catch(e){_._DumpException(e)}
/* _GlobalSuffix_ */
})(this.gbar_);
// Google Inc.
</script><style>@import url('https://fonts.googleapis.com/css?lang=es&family=Product+Sans|Roboto:400,700');.gb_tb{font:13px/27px Roboto,RobotoDraft,Arial,sans-serif;z-index:986}@-moz-keyframes gb__a{0%{opacity:0}50%{opacity:1}}@keyframes gb__a{0%{opacity:0}50%{opacity:1}}a.gb_Ba{border:none;color:#4285f4;cursor:default;font-weight:bold;outline:none;position:relative;text-align:center;text-decoration:none;text-transform:uppercase;white-space:nowrap;-moz-user-select:none}a.gb_Ba:hover:after,a.gb_Ba:focus:after{background-color:rgba(0,0,0,.12);content:'';height:100%;left:0;position:absolute;top:0;width:100%}a.gb_Ba:hover,a.gb_Ba:focus{text-decoration:none}a.gb_Ba:active{background-color:rgba(153,153,153,.4);text-decoration:none}a.gb_Ca{background-color:#4285f4;color:#fff}a.gb_Ca:active{background-color:#0043b2}.gb_Da{-moz-box-shadow:0 1px 1px rgba(0,0,0,.16);box-shadow:0 1px 1px rgba(0,0,0,.16)}.gb_Ba,.gb_Ca,.gb_Ea,.gb_Fa{display:inline-block;line-height:28px;padding:0 12px;-moz-border-radius:2px;border-radius:2px}.gb_Ea{background:#f8f8f8;border:1px solid #c6c6c6}.gb_Fa{background:#f8f8f8}.gb_Ea,#gb a.gb_Ea.gb_Ea,.gb_Fa{color:#666;cursor:default;text-decoration:none}#gb a.gb_Fa.gb_Fa{cursor:default;text-decoration:none}.gb_Fa{border:1px solid #4285f4;font-weight:bold;outline:none;background:#4285f4;background:-moz-linear-gradient(top,#4387fd,#4683ea);background:linear-gradient(top,#4387fd,#4683ea);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#4387fd,endColorstr=#4683ea,GradientType=0)}#gb a.gb_Fa.gb_Fa{color:#fff}.gb_Fa:hover{-moz-box-shadow:0 1px 0 rgba(0,0,0,.15);box-shadow:0 1px 0 rgba(0,0,0,.15)}.gb_Fa:active{-moz-box-shadow:inset 0 2px 0 rgba(0,0,0,.15);box-shadow:inset 0 2px 0 rgba(0,0,0,.15);background:#3c78dc;background:-moz-linear-gradient(top,#3c7ae4,#3f76d3);background:linear-gradient(top,#3c7ae4,#3f76d3);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#3c7ae4,endColorstr=#3f76d3,GradientType=0)}.gb_bb{display:none!important}.gb_cb{visibility:hidden}.gb_9c{display:inline-block;vertical-align:middle}.gb_Qc{position:relative}.gb_b{display:inline-block;outline:none;vertical-align:middle;-moz-border-radius:2px;border-radius:2px;-moz-box-sizing:border-box;box-sizing:border-box;height:40px;width:40px;color:#000;cursor:pointer;text-decoration:none}#gb#gb a.gb_b{color:#000;cursor:pointer;text-decoration:none}.gb_vb{border-color:transparent;border-bottom-color:#fff;border-style:dashed dashed solid;border-width:0 8.5px 8.5px;display:none;position:absolute;left:11.5px;top:43px;z-index:1;height:0;width:0;-moz-animation:gb__a .2s;animation:gb__a .2s}.gb_wb{border-color:transparent;border-style:dashed dashed solid;border-width:0 8.5px 8.5px;display:none;position:absolute;left:11.5px;z-index:1;height:0;width:0;-moz-animation:gb__a .2s;animation:gb__a .2s;border-bottom-color:#ccc;border-bottom-color:rgba(0,0,0,.2);top:42px}x:-o-prefocus,div.gb_wb{border-bottom-color:#ccc}.gb_fa{background:#fff;border:1px solid #ccc;border-color:rgba(0,0,0,.2);color:#000;-moz-box-shadow:0 2px 10px rgba(0,0,0,.2);box-shadow:0 2px 10px rgba(0,0,0,.2);display:none;outline:none;overflow:hidden;position:absolute;right:8px;top:56px;-moz-animation:gb__a .2s;animation:gb__a .2s;-moz-border-radius:2px;border-radius:2px;-moz-user-select:text}.gb_9c.gb_g .gb_vb,.gb_9c.gb_g .gb_wb,.gb_9c.gb_g .gb_fa,.gb_g.gb_fa{display:block}.gb_9c.gb_g.gb_Cf .gb_vb,.gb_9c.gb_g.gb_Cf .gb_wb{display:none}.gb_Df{position:absolute;right:8px;top:56px;z-index:-1}.gb_fb .gb_vb,.gb_fb .gb_wb,.gb_fb .gb_fa{margin-top:-10px}.gb_9c:first-child,#gbsfw:first-child+.gb_9c{padding-left:4px}.gb_Ec{position:relative}.gb_he .gb_Ec,.gb_9d .gb_Ec{float:right}.gb_b{padding:8px;cursor:pointer}.gb_Pe button:focus svg,.gb_Xa .gb_Jb:not(.gb_Ba):focus img,.gb_b:focus{background-color:rgba(0,0,0,0.20);outline:none;-moz-border-radius:50%;border-radius:50%}.gb_9c{padding:4px}.gb_fa{z-index:991;line-height:normal}.gb_fa.gb_Qe{left:8px;right:auto}@media (max-width:350px){.gb_fa.gb_Qe{left:0}}.gb_da .gb_b,.gb_ea .gb_da .gb_b{background-position:-64px -29px}.gb_X .gb_da .gb_b{background-position:-29px -29px;opacity:1}.gb_da .gb_b,.gb_da .gb_b:hover,.gb_da .gb_b:focus{opacity:1}.gb_Cd{display:none}.gb_cc{display:inline-block;position:relative;top:2px;-moz-user-select:-moz-none}.gb_we .gb_cc{display:none}.gb_Ed .gb_dc{line-height:normal;position:relative;padding-left:16px}.gb_xe .gb_dc.gb_ye{padding-left:4px}.gb_fc .gb_Fc:before{content:url('https://www.gstatic.com/images/branding/googlelogo/svg/googlelogo_clr_74x24px.svg');display:inline-block;height:24px;width:74px}.gb_fc .gb_Fc{height:24px;width:74px;display:inline-block;vertical-align:middle}.gb_fc{display:inline-block;vertical-align:middle}.gb_fc .gb_Fc,.gb_fc.gb_ze,.gb_fc:not(.gb_ze):not(:focus){outline:none}.gb_0a{display:inline-block;vertical-align:middle}.gb_ic{border:none;display:block;visibility:hidden}img.gb_1a{border:0;vertical-align:middle}.gb_de .gb_fc .gb_Fc:before{content:url('https://www.gstatic.com/images/branding/googlelogo/svg/googlelogo_light_clr_74x24px.svg')}.gb_ce .gb_fc .gb_Fc:before{content:url('https://www.gstatic.com/images/branding/googlelogo/svg/googlelogo_dark_clr_74x24px.svg')}@media screen and (-ms-high-contrast:black-on-white){.gb_de .gb_fc .gb_Fc:before{content:url('https://www.gstatic.com/images/branding/googlelogo/svg/googlelogo_dark_clr_74x24px.svg')}}@media screen and (-ms-high-contrast:white-on-black){.gb_ce .gb_fc .gb_Fc:before{content:url('https://www.gstatic.com/images/branding/googlelogo/svg/googlelogo_light_clr_74x24px.svg')}}.gb_0a{background-repeat:no-repeat}.gb_le{display:inline-block;font-family:'Product Sans',Arial,sans-serif;font-size:22px;line-height:24px;padding-left:8px;position:relative;top:-1.5px;vertical-align:middle}.gb_1a.gb_Ae{padding-right:4px}.gb_ge.gb_le{opacity:.54}.gb_ke:focus .gb_le{text-decoration:underline}.gb_ye img.gb_1a{margin-bottom:4px}.gb_Vc{color:inherit;font-size:22px;font-weight:400;line-height:48px;overflow:hidden;padding-left:16px;position:relative;text-overflow:ellipsis;vertical-align:middle;top:2px;white-space:nowrap;flex:1 1 auto}.gb_Xa.gb_Za .gb_Wc{position:relative;top:-2px}.gb_Xa.gb_Za .gb_Vc{font-size:20px}.gb_Xa{min-width:320px;position:relative;-moz-transition:box-shadow 250ms;transition:box-shadow 250ms}.gb_Xa.gb_Dd .gb_Cc{display:none}.gb_Xa.gb_Dd .gb_Ed{height:56px}header.gb_Xa{display:block}.gb_Xa svg{fill:currentColor}.gb_Fd{position:fixed;top:0;width:100%}.gb_Hd{-moz-box-shadow:0 4px 5px 0 rgba(0,0,0,0.14),0 1px 10px 0 rgba(0,0,0,0.12),0 2px 4px -1px rgba(0,0,0,0.2);box-shadow:0 4px 5px 0 rgba(0,0,0,0.14),0 1px 10px 0 rgba(0,0,0,0.12),0 2px 4px -1px rgba(0,0,0,0.2)}.gb_Id{height:64px}.gb_Xa:not(.gb_qc) .gb_Zc.gb_0c,.gb_Xa:not(.gb_qc) .gb_yd{display:none!important}.gb_Ed{box-sizing:border-box;position:relative;width:100%;display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;justify-content:space-between;min-width:-webkit-min-content;min-width:-moz-min-content;min-width:-ms-min-content;min-width:min-content}.gb_Xa:not(.gb_Za) .gb_Ed{padding:8px}.gb_Xa.gb_Jd .gb_Ed{flex:1 0 auto}.gb_Xa .gb_Ed.gb_Kd.gb_Ld{min-width:0}.gb_Xa.gb_Za .gb_Ed{padding:4px;min-width:0}.gb_Cc{height:48px;vertical-align:middle;white-space:nowrap;-moz-box-align:center;align-items:center;display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-moz-user-select:-moz-none}.gb_Nd>.gb_Cc{display:table-cell;width:100%}.gb_Cc.gb_Od:not(.gb_Pd) .gb_Qd{padding-left:16px}.gb_Cc.gb_Rd.gb_Od:not(.gb_Pd) .gb_Qd,.gb_Cc.gb_Sd:not(.gb_Pd) .gb_Qd{padding-right:16px}.gb_Cc:not(.gb_Pd) .gb_Qd{width:100%;flex:1 1 auto}.gb_Qd.gb_cb{display:none}.gb_Td.gb_Ud>.gb_Vd{min-width:initial!important;min-width:auto!important}.gb_Wd{padding-right:32px;-moz-box-sizing:border-box;box-sizing:border-box;flex:1 0 auto}.gb_Wd.gb_Xd{padding-right:0}.gb_Xa.gb_Za .gb_Wd:not(.gb_Xd){padding-right:8px}.gb_Xa.gb_Za .gb_Wd:not(.gb_Zd),.gb_Ed.gb_Kd.gb_Ld>.gb_Wd{flex:1 1 auto;overflow:hidden}.gb_Xa.gb_Za .gb_Td:not(.gb_Zd),.gb_Ed.gb_Kd.gb_Ld>.gb_Td{flex:0 0 auto}.gb_Td{flex:1 1 100%}.gb_0d,.gb_1d:not(.gb_Kd):not(.gb_Ud).gb_2d{justify-content:flex-end}.gb_1d:not(.gb_Kd):not(.gb_Ud){justify-content:center}.gb_1d:not(.gb_Kd):not(.gb_Ud).gb_3d,.gb_1d:not(.gb_Kd):not(.gb_Ud).gb_4d{justify-content:flex-start}.gb_Td.gb_Kd,.gb_Td.gb_Ud{justify-content:space-between}.gb_Td>:only-child{display:inline-block}.gb_Dc.gb_5d.gb_6d{padding-left:4px}.gb_Dc.gb_5d.gb_7d{padding-left:0}.gb_Xa.gb_Za .gb_Dc.gb_5d.gb_7d{padding-left:4px;padding-right:0}.gb_6d{display:inline}.gb_Dc.gb_5d{box-sizing:border-box;padding-left:32px;flex:0 0 auto;justify-content:flex-end}.gb_Vc{display:inline-block}.gb_Dc{height:48px;line-height:normal;padding:0 4px}.gb_9d{height:48px}.gb_Xa.gb_9d{min-width:initial;min-width:auto}.gb_9d .gb_Dc{float:right}.gb_ae{font-size:14px;max-width:200px;overflow:hidden;padding:0 12px;text-overflow:ellipsis;white-space:nowrap;-moz-user-select:text}.gb_Xa{color:black}.gb_be{background-color:#fff;transition:background-color .4s}.gb_ce{color:black;background-color:#e0e0e0}.gb_de{color:white;background-color:#616161}.gb_Xa a,.gb_oc a{color:inherit}.gb_3{color:rgba(0,0,0,0.87)}.gb_Xa svg,.gb_oc svg{color:black;opacity:.54}.gb_de svg{color:white;opacity:1}.gb_ee:hover,.gb_ee:focus,.gb_fe:hover,.gb_fe:focus{opacity:.85}.gb_ge{color:inherit;opacity:1;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale}.gb_de .gb_ge,.gb_ce .gb_ge{opacity:1}.gb_he>*{display:block;min-height:48px}.gb_Xa.gb_Za .gb_he>*{padding-top:4px;padding-bottom:4px;padding-left:16px}.gb_Xa:not(.gb_Za) .gb_he>*{padding-top:8px;padding-bottom:8px;padding-left:24px}.gb_Xa:not(.gb_Za) .gb_Wd .gb_cc{-moz-box-align:center;align-items:center;display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.gb_he .gb_cc{display:table-cell;height:48px;vertical-align:middle}.gb_he .gb_Dc,.gb_he .gb_6d{background-color:#f5f5f5;display:block}.gb_he .gb_6d .gb_9c{float:right}.gb_Xa.gb_Za .gb_he .gb_Dc,.gb_Xa.gb_Za .gb_he .gb_6d{padding:4px}.gb_Xa:not(.gb_Za) .gb_he .gb_Dc,.gb_Xa:not(.gb_Za) .gb_he .gb_6d{padding:8px}.gb_he .gb_eb{width:40px}.gb_he .gb_hb{position:absolute;right:0;top:50%}.gb_ie{position:relative}.gb_oc .gb_ke{text-decoration:none}.gb_oc .gb_le{display:inline;white-space:normal;word-break:break-all;word-break:break-word}body.gb_me [data-ogpc]{-moz-transition:margin-left .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear .25s;transition:margin-left .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear .25s}body.gb_me.gb_ne [data-ogpc]{-moz-transition:margin-left .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear 0s;transition:margin-left .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear 0s}body [data-ogpc]{margin-left:0}body.gb_ne [data-ogpc]{margin-left:280px}.gb_oe{line-height:normal;padding-right:15px}a.gb_P,span.gb_P{color:rgba(0,0,0,0.87);text-decoration:none}.gb_X a.gb_P,.gb_X span.gb_P{color:#fff}a.gb_P:hover,a.gb_P:focus{opacity:.85;text-decoration:underline}.gb_Q{display:inline-block;padding-left:15px}.gb_Q .gb_P{display:inline-block;line-height:24px;outline:none;vertical-align:middle}.gb_S .gb_P{display:none}.gb_re{padding-left:16px}.gb_re:not(.gb_Za){padding-left:24px}.gb_se{color:black;opacity:.54}.gb_te{background:white;-moz-box-shadow:0 5px 5px -3px rgba(0,0,0,0.2),0 8px 10px 1px rgba(0,0,0,0.14),0 3px 14px 2px rgba(0,0,0,0.12);box-shadow:0 5px 5px -3px rgba(0,0,0,0.2),0 8px 10px 1px rgba(0,0,0,0.14),0 3px 14px 2px rgba(0,0,0,0.12);overflow-y:hidden;position:absolute;right:24px;top:48px}.gb_Va{background-color:rgba(255,255,255,0.88);cursor:pointer;display:inline-block;overflow:hidden;padding:0;vertical-align:middle;border:1px solid #dadce0;outline:none;box-sizing:border-box;-moz-border-radius:8px;border-radius:8px}.gb_Va:hover{border:1px solid #d2e3fc;background-color:rgba(248,250,255,0.88)}.gb_Va:focus{border:1px solid #fff;background-color:rgba(255,255,255);-moz-box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 1px 3px 1px rgba(60,64,67,0.15);box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 1px 3px 1px rgba(60,64,67,0.15)}.gb_Wa{display:inline-block;padding-left:7px;padding-bottom:2px;text-align:center;vertical-align:middle}.gb_Xa:not(.gb_Za) .gb_Va{margin-left:12px}.gb_Va .gb_0a.gb_1a{min-width:0}.gb_db{background-size:32px 32px;-moz-border-radius:50%;border-radius:50%;display:block;margin:0;overflow:hidden;position:relative;height:32px;width:32px;z-index:0}@media (min-resolution:1.25dppx),(-o-min-device-pixel-ratio:5/4),(-webkit-min-device-pixel-ratio:1.25),(min-device-pixel-ratio:1.25){.gb_db::before{display:inline-block;-moz-transform:scale(.5);transform:scale(.5);-moz-transform-origin:left 0;transform-origin:left 0}.gb_Eb::before{display:inline-block;-moz-transform:scale(.5);transform:scale(.5);-moz-transform-origin:left 0;transform-origin:left 0}}.gb_db:hover,.gb_db:focus{-moz-box-shadow:0 1px 0 rgba(0,0,0,.15);box-shadow:0 1px 0 rgba(0,0,0,.15)}.gb_db:active{-moz-box-shadow:inset 0 2px 0 rgba(0,0,0,.15);box-shadow:inset 0 2px 0 rgba(0,0,0,.15)}.gb_db:active::after{background:rgba(0,0,0,.1);-moz-border-radius:50%;border-radius:50%;content:'';display:block;height:100%}.gb_eb{cursor:pointer;line-height:40px;min-width:30px;opacity:.75;overflow:hidden;vertical-align:middle;text-overflow:ellipsis}.gb_b.gb_eb{width:auto}.gb_eb:hover,.gb_eb:focus{opacity:.85}.gb_fb .gb_eb,.gb_fb .gb_gb{line-height:26px}#gb#gb.gb_fb a.gb_eb,.gb_fb .gb_gb{font-size:11px;height:auto}.gb_hb{border-top:4px solid #000;border-left:4px dashed transparent;border-right:4px dashed transparent;display:inline-block;margin-left:6px;opacity:.75;vertical-align:middle}.gb_ib:hover .gb_hb{opacity:.85}.gb_Va>.gb_jb{padding:3px 3px 3px 4px}.gb_X .gb_eb,.gb_X .gb_hb{opacity:1}#gb#gb.gb_X.gb_X a.gb_eb,#gb#gb .gb_X.gb_X a.gb_eb{color:#fff}.gb_X.gb_X .gb_hb{border-top-color:#fff;opacity:1}.gb_ea .gb_db:hover,.gb_X .gb_db:hover,.gb_ea .gb_db:focus,.gb_X .gb_db:focus{-moz-box-shadow:0 1px 0 rgba(0,0,0,.15),0 1px 2px rgba(0,0,0,.2);box-shadow:0 1px 0 rgba(0,0,0,.15),0 1px 2px rgba(0,0,0,.2)}.gb_kb .gb_jb,.gb_lb .gb_jb{position:absolute;right:1px}.gb_jb.gb_R,.gb_mb.gb_R,.gb_ib.gb_R{flex:0 1 auto;flex:0 1 main-size}.gb_nb.gb_W .gb_eb{width:30px!important}.gb_ob.gb_cb{display:none}@-moz-keyframes progressmove{0%{margin-left:-100%}to{margin-left:100%}}@keyframes progressmove{0%{margin-left:-100%}to{margin-left:100%}}.gb_pb.gb_bb{display:none}.gb_pb{background-color:#ccc;height:3px;overflow:hidden}.gb_qb{background-color:#f4b400;height:100%;width:50%;-moz-animation:progressmove 1.5s linear 0s infinite;animation:progressmove 1.5s linear 0s infinite}.gb_sb{height:40px;position:absolute;right:-5px;top:-5px;width:40px}.gb_tb .gb_sb,.gb_ub .gb_sb{right:0;top:0}.gb_jb .gb_b{padding:4px}.gb_ve{display:none}.gb_jc{-moz-border-radius:50%;border-radius:50%;display:inline-block;margin:0 4px;padding:12px;overflow:hidden;vertical-align:middle;cursor:pointer;height:24px;width:24px;-moz-user-select:none;flex:0 0 auto}.gb_Za .gb_jc{margin:0 4px 0 0}.gb_jc:focus,.gb_jc:hover{background-color:rgba(0,0,0,0.071);outline:none}.gb_kc{display:none}.gb_lc{transform:none}.gb_nc{display:none}.gb_oc{background-color:#fff;bottom:0;color:#000;height:-moz-calc(100vh - 100%);height:calc(100vh - 100%);overflow-y:auto;overflow-x:hidden;position:absolute;top:100%;z-index:990;will-change:visibility;visibility:hidden;display:-webkit-flex;display:flex;flex-direction:column;-moz-transition:transform .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear .25s;transition:transform .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear .25s}.gb_oc.gb_Za{width:264px;transform:translateX(-264px)}.gb_oc:not(.gb_Za){width:280px;transform:translateX(-280px)}.gb_oc.gb_g{transform:translateX(0);visibility:visible;-moz-box-shadow:0 0 16px rgba(0,0,0,.28);box-shadow:0 0 16px rgba(0,0,0,.28);-moz-transition:transform .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear 0s;transition:transform .25s cubic-bezier(0.4,0.0,0.2,1),visibility 0s linear 0s}.gb_pc.gb_qc{background-color:transparent;-moz-box-shadow:0 0;box-shadow:0 0}.gb_pc.gb_qc>:not(.gb_rc){display:none}.gb_rc{display:-webkit-flex;display:flex;flex:1 1 auto;flex-direction:column}.gb_rc>.gb_sc{flex:1 0 auto}.gb_rc>.gb_tc{flex:0 0 auto}.gb_uc{list-style:none;margin-top:0;margin-bottom:0;padding:8px 0}.gb_oc:not(.gb_pc) .gb_uc:first-child{padding:0 0 8px 0}.gb_uc:not(:last-child){border-bottom:1px solid #ddd}.gb_vc{cursor:pointer}.gb_wc:empty{display:none}.gb_vc,.gb_wc{display:block;min-height:40px;padding-bottom:4px;padding-top:4px;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif;color:rgba(0,0,0,0.87)}.gb_oc.gb_Za .gb_vc{padding-left:16px}.gb_oc:not(.gb_Za) .gb_vc,.gb_oc:not(.gb_Za) .gb_wc{padding-left:24px}.gb_vc:hover{background:rgba(0,0,0,0.12)}.gb_vc.gb_xc{background:rgba(0,0,0,0.12);font-weight:bold;color:rgba(0,0,0,0.87)}.gb_vc .gb_yc{text-decoration:none;display:inline-block;width:100%}.gb_vc .gb_yc:focus{outline:none}.gb_vc .gb_zc,.gb_wc{padding-left:32px;display:inline-block;line-height:40px;vertical-align:top;width:176px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.gb_rc.gb_5 .gb_yc:focus .gb_zc{text-decoration:underline}.gb_vc .gb_Ac{height:24px;width:24px;float:left;margin-top:8px;vertical-align:middle}.gb_Nc .gb_Qc{font-size:14px;font-weight:bold;top:0;right:0}.gb_Nc .gb_b{display:inline-block;vertical-align:middle;-moz-box-sizing:border-box;box-sizing:border-box;height:40px;width:40px}.gb_Nc .gb_vb{border-bottom-color:#e5e5e5}.gb_Rc{background-color:rgba(0,0,0,.55);color:white;font-size:12px;font-weight:bold;line-height:24px;margin:5px;padding:0 2px;text-align:center;-moz-box-sizing:border-box;box-sizing:border-box;-moz-border-radius:50%;border-radius:50%;height:24px;width:24px}.gb_Rc.gb_Sc{background-position:-79px 0}.gb_Rc.gb_Tc{background-position:-79px -64px}.gb_b:hover .gb_Rc,.gb_b:focus .gb_Rc{background-color:rgba(0,0,0,.85)}#gbsfw.gb_Uc{background:#e5e5e5;border-color:#ccc}.gb_ea .gb_Rc{background-color:rgba(0,0,0,.7)}.gb_X .gb_Rc.gb_Rc,.gb_X .gb_Kc .gb_Rc.gb_Rc,.gb_X .gb_Kc .gb_b:hover .gb_Rc,.gb_X .gb_Kc .gb_b:focus .gb_Rc{background-color:#fff;color:#404040}.gb_X .gb_Rc.gb_Sc{background-position:-54px -64px}.gb_X .gb_Rc.gb_Tc{background-position:0 -64px}.gb_Kc .gb_Rc.gb_Rc{background-color:#db4437;color:white}.gb_Kc .gb_b:hover .gb_Rc,.gb_Kc .gb_b:focus .gb_Rc{background-color:#a52714}.gb_Be{line-height:20px;margin:2px;text-align:center;vertical-align:middle;-moz-box-sizing:border-box;box-sizing:border-box;-moz-border-radius:50%;border-radius:50%;height:20px;width:20px}.gb_Nc a{line-height:24px;-moz-border-radius:50%;border-radius:50%}.gb_Ce.gb_Sc .gb_Be{display:none}.gb_Ce svg{display:none;height:24px;width:24px}.gb_Ce.gb_Sc svg{display:block}.gb_Ce.gb_Tc svg{display:none}.gb_Kc .gb_Be{color:white;background-color:#db4437;opacity:1}.gb_ce .gb_Kc .gb_Be{color:white;background-color:#db4437}.gb_de .gb_Kc .gb_Be{color:#212121;background-color:white}.gb_De{display:none}.gb_zf{cursor:pointer;padding:13px}.gb_Af{background-color:rgba(0,0,0,0.1);-moz-box-shadow:inset 1px 1px 3px rgba(0,0,0,.24);box-shadow:inset 1px 1px 3px rgba(0,0,0,.24);width:34px;height:17px;-moz-border-radius:8px;border-radius:8px;position:relative;-moz-transition:background-color ease 150ms;transition:background-color ease 150ms}.gb_zf[aria-pressed=true] .gb_Af{background-color:rgba(255,255,255,0.1)}.gb_Bf{position:absolute;width:25px;height:25px;-moz-border-radius:50%;border-radius:50%;-moz-box-shadow:0 0 2px rgba(0,0,0,.12),0 2px 4px rgba(0,0,0,.24);box-shadow:0 0 2px rgba(0,0,0,.12),0 2px 4px rgba(0,0,0,.24);top:-4px;transform:translateX(-12px);background-color:white;-moz-transition:transform ease 150ms;transition:transform ease 150ms}.gb_zf[aria-pressed=true] .gb_Bf{transform:translateX(20px)}.gb_Bf img{position:absolute;margin:5px;width:15px;height:15px}.gb_Vd{line-height:0;-moz-user-select:-moz-none}.gb_Td>.gb_Vd:only-child{float:right}.gb_Vd .gb_Je{display:inline-block}.gb_Vd .gb_Jb{cursor:pointer}.gb_Vd .gb_Jb img{opacity:.54;width:24px;height:24px;padding:12px}.gb_de .gb_Vd .gb_Jb img{opacity:1}.gb_Ee{text-align:right}.gb_Je{text-align:initial}.gb_Vd .gb_Ke,.gb_Vd .gb_Le{display:table-cell;height:48px;vertical-align:middle}.gb_Vd .gb_Ke{overflow:hidden}.gb_Xc{display:none}.gb_Xc.gb_g{display:block}.gb_Zc{background-color:#fff;-moz-box-shadow:0 1px 0 rgba(0,0,0,0.08);box-shadow:0 1px 0 rgba(0,0,0,0.08);color:#000;position:relative;z-index:986}.gb_0c{height:40px;padding:16px 24px;white-space:nowrap}.gb_1c{position:fixed;bottom:16px;padding:16px;right:16px;white-space:normal;width:328px;transition:width .2s,bottom .2s,right .2s;-moz-border-radius:2px;border-radius:2px;-moz-box-shadow:0 5px 5px -3px rgba(0,0,0,0.2),0 8px 10px 1px rgba(0,0,0,0.14),0 3px 14px 2px rgba(0,0,0,0.12);box-shadow:0 5px 5px -3px rgba(0,0,0,0.2),0 8px 10px 1px rgba(0,0,0,0.14),0 3px 14px 2px rgba(0,0,0,0.12)}@media (max-width:400px){.gb_Zc.gb_1c{max-width:368px;width:auto;bottom:0;right:0}}.gb_Zc .gb_Jb{border:0;font-weight:500;font-size:14px;line-height:36px;min-width:32px;padding:0 16px;vertical-align:middle}.gb_Zc .gb_Jb:before{content:'';height:6px;left:0;position:absolute;top:-6px;width:100%}.gb_Zc .gb_Jb:after{bottom:-6px;content:'';height:6px;left:0;position:absolute;width:100%}.gb_Zc .gb_Jb+.gb_Jb{margin-left:8px}.gb_2c{height:48px;padding:4px;margin:-8px 0 0 -8px}.gb_1c .gb_2c{float:left;margin:-4px}.gb_3c{font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif;overflow:hidden;vertical-align:top}.gb_0c .gb_3c{display:inline-block;padding-left:8px;width:640px}.gb_1c .gb_3c{display:block;margin-left:56px;padding-bottom:16px}.gb_4c{background-color:inherit}.gb_0c .gb_4c{display:inline-block;position:absolute;top:18px;right:24px}.gb_1c .gb_4c{text-align:right;padding-right:24px;padding-top:6px}.gb_4c .gb_5c{height:1.5em;margin:-.25em 10px -.25em 0;vertical-align:text-top;width:1.5em}.gb_6c{line-height:20px;font-size:16px;font-weight:700;color:rgba(0,0,0,.87)}.gb_1c .gb_6c{color:rgba(0,0,0,.87);font-size:16px;line-height:20px;padding-top:8px}.gb_0c .gb_6c,.gb_0c .gb_7c{width:640px}.gb_7c .gb_8c,.gb_7c{line-height:20px;font-size:13px;font-weight:400;color:rgba(0,0,0,.54)}.gb_1c .gb_7c .gb_8c{font-size:14px}.gb_1c .gb_7c{padding-top:12px}.gb_1c .gb_7c a{color:rgba(66,133,244,1)}.gb_9c.gb_ad{padding:0}.gb_ad .gb_fa{padding:26px 26px 22px 13px;background:#ffffff}.gb_bd.gb_ad .gb_fa{background:#4d90fe}a.gb_cd{color:#666666!important;font-size:22px;height:9px;opacity:.8;position:absolute;right:14px;top:4px;text-decoration:none!important;width:9px}.gb_bd a.gb_cd{color:#c1d1f4!important}a.gb_cd:hover,a.gb_cd:active{opacity:1}.gb_dd{padding:0;width:258px;white-space:normal;display:table}.gb_ed .gb_fa{top:56px;border:0;padding:16px;-moz-box-shadow:4px 4px 12px rgba(0,0,0,0.4);box-shadow:4px 4px 12px rgba(0,0,0,0.4)}.gb_ed .gb_dd{width:328px}.gb_ed .gb_Fa,.gb_ed .gb_fd,.gb_ed .gb_8c,.gb_ed .gb_Ba,.gb_gd{line-height:normal;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}.gb_ed .gb_Fa,.gb_ed .gb_fd,.gb_ed .gb_Ba{font-weight:500}.gb_ed .gb_Fa,.gb_ed .gb_Ba{border:0;padding:10px 8px}.gb_ad .gb_Fa:active{outline:none;-moz-box-shadow:0 4px 5px rgba(0,0,0,.16);box-shadow:0 4px 5px rgba(0,0,0,.16)}.gb_ed .gb_fd{color:#222;margin-bottom:8px}.gb_ed .gb_8c{color:#808080;font-size:14px}.gb_hd{text-align:right;font-size:14px;padding-bottom:0;white-space:nowrap}.gb_hd .gb_id{margin-left:8px}.gb_hd .gb_jd.gb_id img{background-color:inherit;-moz-border-radius:initial;border-radius:initial;height:1.5em;margin:-0.25em 10px -0.25em 2px;vertical-align:text-top;width:1.5em}.gb_ed .gb_dd .gb_kd .gb_jd{border:2px solid transparent}.gb_ed .gb_dd .gb_kd .gb_jd:focus{border-color:#bbccff}.gb_ed .gb_dd .gb_kd .gb_jd:focus:after,.gb_ed .gb_dd .gb_kd .gb_jd:hover:after{background-color:transparent}.gb_gd{background-color:#404040;color:#fff;padding:16px;position:absolute;top:56px;min-width:328px;max-width:650px;right:8px;-moz-border-radius:2px;border-radius:2px;-moz-box-shadow:4px 4px 12px rgba(0,0,0,0.4);box-shadow:4px 4px 12px rgba(0,0,0,0.4)}.gb_gd a,.gb_gd a:visited{color:#5e97f6;text-decoration:none}.gb_ld{text-transform:uppercase}.gb_md{padding-left:50px}.gb_bd .gb_dd{width:200px}.gb_fd{color:#333333;font-size:16px;line-height:20px;margin:0;margin-bottom:16px}.gb_bd .gb_fd{color:#ffffff}.gb_8c{color:#666666;line-height:17px;margin:0;margin-bottom:5px}.gb_bd .gb_8c{color:#ffffff}.gb_8c a.gb_od{text-decoration:none;color:#5e97f6}.gb_8c a.gb_od:visited{color:#5e97f6}.gb_8c a.gb_od:hover,.gb_8c a.gb_od:active{text-decoration:underline}.gb_pd{position:absolute;background:transparent;top:-999px;z-index:-1;visibility:hidden;margin-top:1px;margin-left:1px}#gb .gb_ad{margin:0}.gb_ad .gb_Jb{background:#4d90fe;border-color:#3079ed;margin-top:15px}.gb_ed .gb_Fa{background:#4285f4}#gb .gb_ad a.gb_Jb.gb_Jb{color:#ffffff}.gb_ad .gb_Jb:hover{background:#357ae8;border-color:#2f5bb7}.gb_qd .gb_Qc .gb_vb{border-bottom-color:#ffffff;display:block}.gb_rd .gb_Qc .gb_vb{border-bottom-color:#4d90fe;display:block}.gb_qd .gb_Qc .gb_wb,.gb_rd .gb_Qc .gb_wb{display:block}.gb_sd,.gb_kd{display:table-cell}.gb_sd{vertical-align:middle}.gb_ed .gb_sd{vertical-align:top}.gb_kd{padding-left:13px;width:100%}.gb_ed .gb_kd{padding-left:20px}.gb_td{display:block;display:inline-block;padding:1em 0 0 0;position:relative;width:100%}.gb_ud{color:#ff0000;font-style:italic;margin:0;padding-left:46px}.gb_td .gb_vd{float:right;margin:-20px 0;width:-moz-calc(100% - 46px);width:calc(100% - 46px)}.gb_wd svg{fill:grey}.gb_wd.gb_xd svg{fill:#4285f4}.gb_td .gb_vd label:after{background-color:#4285f4}.gb_wd{display:inline;float:right;margin-right:22px;position:relative;top:-4px}.gb_yd{color:#ffffff;font-size:13px;font-weight:bold;height:25px;line-height:19px;padding-top:5px;padding-left:12px;position:relative;background-color:#4d90fe}.gb_yd .gb_zd{color:#ffffff;cursor:default;font-size:22px;font-weight:normal;position:absolute;right:12px;top:5px}.gb_yd .gb_id,.gb_yd .gb_Ad{color:#ffffff;display:inline-block;font-size:11px;margin-left:16px;padding:0 8px;white-space:nowrap}.gb_Bd{background:none;background-image:-moz-linear-gradient(top,rgba(0,0,0,0.16),rgba(0,0,0,0.2));background-image:linear-gradient(top,rgba(0,0,0,0.16),rgba(0,0,0,0.2));background-image:-moz-linear-gradient(top,rgba(0,0,0,0.16),rgba(0,0,0,0.2));-moz-border-radius:2px;border-radius:2px;border:1px solid #dcdcdc;border:1px solid rgba(0,0,0,0.1);cursor:default!important;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#160000ff,endColorstr=#220000ff);text-decoration:none!important}.gb_Bd:hover{background:none;background-image:-moz-linear-gradient(top,rgba(0,0,0,0.14),rgba(0,0,0,0.2));background-image:linear-gradient(top,rgba(0,0,0,0.14),rgba(0,0,0,0.2));background-image:-moz-linear-gradient(top,rgba(0,0,0,0.14),rgba(0,0,0,0.2));border:1px solid rgba(0,0,0,0.2);box-shadow:0 1px 1px rgba(0,0,0,0.1);-moz-box-shadow:0 1px 1px rgba(0,0,0,0.1);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#14000000,endColorstr=#22000000)}.gb_Bd:active{box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.3)}.gb_Xa .gb_Ba{color:#4285f4}.gb_Xa .gb_Ca{color:#fff}.gb_Xa .gb_Jb:not(.gb_Me):focus{outline:none}.gb_ef,.gb_ff,.gb_gf{display:none}.gb_Qd{height:48px;max-width:720px}.gb_Td.gb_4d .gb_Qd{max-width:100%;flex:1 1 auto}.gb_Nd>.gb_Cc .gb_Qd{display:table-cell;vertical-align:middle;width:100%}.gb_Td.gb_4d .gb_Qd .gb_Pe{margin-left:0;margin-right:0}.gb_Pe{background:rgba(0,0,0,0.04);border:1px solid rgba(0,0,0,0);-moz-border-radius:4px;border-radius:4px;margin-left:auto;margin-right:auto;max-width:720px;position:relative;-moz-transition:background 100ms ease-in,width 100ms ease-out;transition:background 100ms ease-in,width 100ms ease-out}.gb_Pe.gb_hf{-moz-border-radius:4px 4px 0 0;border-radius:4px 4px 0 0}.gb_de .gb_Pe{background:rgba(255,255,255,0.16)}.gb_if.gb_Pe{background:rgba(255,255,255,1)}.gb_de .gb_if.gb_Pe .gb_7e{color:rgba(0,0,0,0.87)}.gb_Pe button{background:none;border:none;cursor:pointer;outline:none;padding:0 4px;line-height:0}.gb_Pe button svg,.gb_Pe button img{padding:7px;margin:4px}.gb_9e{float:left}.gb_8e .gb_9e{position:absolute;right:0}.gb_jf{display:none;float:left}.gb_kf{position:absolute;right:0;cursor:default;visibility:hidden;top:0;-moz-transition:opacity 250ms ease-out;transition:opacity 250ms ease-out}.gb_lf .gb_kf{right:35px}.gb_8e .gb_kf{display:none}.gb_kf.gb_mf{visibility:inherit}.gb_nf{position:absolute;right:0;top:0}.gb_8e .gb_nf{right:35px}.gb_8e>.gb_of{padding:0 11px}.gb_of{height:46px;padding:0;margin-right:50px;overflow:hidden}.gb_lf .gb_of{margin-right:83px}.gb_7e{border:none;font:normal 16px Roboto,sans-serif;font-variant-ligatures:none;height:46px;outline:none;padding:11px 16px 11px 16px;width:100%;background:transparent;-moz-box-sizing:border-box;box-sizing:border-box}.gb_de .gb_7e{color:rgba(255,255,255,0.7)}.gb_7e.gb_pf{padding-left:0}.gb_pf{height:46px;line-height:46px;padding-bottom:0;padding-top:0}.gb_Pe:not(.gb_6e) input::-moz-placeholder{color:rgba(0,0,0,0.54)}.gb_de .gb_Pe:not(.gb_6e) input::-moz-placeholder{color:rgba(255,255,255,0.7)}.gb_Pe.gb_Pd:not(.gb_ma){background:transparent;float:right}.gb_Pe.gb_Pd:not(.gb_ma) .gb_of,.gb_Pe.gb_Pd:not(.gb_ma) .gb_kf,.gb_Pe.gb_Pd:not(.gb_ma) .gb_nf{display:none}.gb_Pe.gb_Pd.gb_ma{margin-left:0;position:absolute;width:auto}.gb_Pe.gb_Pd.gb_ma:not(.gb_8e) .gb_9e{display:none}.gb_Pe.gb_Pd .gb_9e{padding:0}.gb_Pe.gb_Pd.gb_ma .gb_jf{display:block}.gb_qf{position:relative}.gb_rf{margin:0 58px;padding:0;text-align:center;white-space:nowrap;-moz-user-select:none;overflow:hidden}.gb_Za .gb_rf,.gb_Dd .gb_rf{margin:0 24px}.gb_sf,.gb_tf{display:none;height:48px;position:absolute;top:0;width:100px}.gb_qf.gb_uf .gb_sf,.gb_qf.gb_vf .gb_tf{display:block}.gb_tf{pointer-events:none}.gb_sf{pointer-events:none;left:0}.gb_tf{right:0}.gb_wf{cursor:pointer;display:inline-table;outline:none}.gb_wf>.gb_xf{border:0 solid transparent;border-width:2px 0;display:table-cell;height:44px;padding:0 22px;opacity:.7;text-decoration:none;text-transform:uppercase;vertical-align:middle}.gb_wf.gb_xc:focus{background-color:rgba(0,0,0,.16)}.gb_wf.gb_xc>.gb_xf{border-bottom-color:black;opacity:1}.gb_de .gb_wf.gb_xc>.gb_xf{border-bottom-color:white}.gb_ce .gb_wf.gb_xc>.gb_xf{border-bottom-color:black}.gb_rf.gb_yf>.gb_wf.gb_xc>.gb_xf{border-bottom-color:#4285f4;color:#4285f4}sentinel{}.gbii::before{content:url(https://lh3.googleusercontent.com/-dNn56SgAmO8/AAAAAAAAAAI/AAAAAAAAAAA/AIcfdXAjGe_QCIAYQ908NFgNYirJhV0kzw/s32-c-mo/photo.jpg)}.gbip::before{content:url(https://lh3.googleusercontent.com/-dNn56SgAmO8/AAAAAAAAAAI/AAAAAAAAAAA/AIcfdXAjGe_QCIAYQ908NFgNYirJhV0kzw/s96-c-mo/photo.jpg)}@media (min-resolution:1.25dppx),(-o-min-device-pixel-ratio:5/4),(-webkit-min-device-pixel-ratio:1.25),(min-device-pixel-ratio:1.25){.gbii::before{content:url(https://lh3.googleusercontent.com/-dNn56SgAmO8/AAAAAAAAAAI/AAAAAAAAAAA/AIcfdXAjGe_QCIAYQ908NFgNYirJhV0kzw/s64-c-mo/photo.jpg)}.gbip::before{content:url(https://lh3.googleusercontent.com/-dNn56SgAmO8/AAAAAAAAAAI/AAAAAAAAAAA/AIcfdXAjGe_QCIAYQ908NFgNYirJhV0kzw/s192-c-mo/photo.jpg)}}
</style><script src="jspdf.js%20-%20Google%20Drive_files/rsAA2YrTuG3aV28Uy2-ES-xuamSB8mj-KVYg" charset="UTF-8" type="text/javascript" async=""></script><link href="jspdf.js%20-%20Google%20Drive_files/rsAA2YrTvppCLL-fVOKeHJBD2efsgZHezqLA.css" rel="stylesheet" type="text/css"><script src="jspdf.js%20-%20Google%20Drive_files/81244139-docos_binary_i18n__es.js" charset="UTF-8" type="text/javascript" nonce="undefined"></script><style>.dcs-d-dcs-od-dcs-pd{width:500px}.dcs-od-dcs-pd-dcs-t{color:black;font-family:arial,sans-serif;font-family:var(--docs-material-font-family,arial,sans-serif);font-size:13px;white-space:normal}.dcs-od-dcs-pd-dcs-vj-dcs-vf{position:absolute;top:0px;padding-top:16px;left:220px}.dcs-od-dcs-pd-dcs-t button.dcs-od-dcs-pd-dcs-qd-dcs-bb,.dcs-od-dcs-pd-dcs-t button.dcs-od-dcs-pd-dcs-qd-dcs-bb:hover{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background-color:#4d90fe;background-color:#4d90fe;background-image:-webkit-linear-gradient(top,#4d90fe,#4787ed);background-image:-moz-linear-gradient(top,#4d90fe,#4787ed);background-image:-ms-linear-gradient(top,#4d90fe,#4787ed);background-image:-o-linear-gradient(top,#4d90fe,#4787ed);background-image:linear-gradient(top,#4d90fe,#4787ed);border:1px solid #3079ed;color:#fff}#docs-instant-button-bubble{border:1px solid #eee;box-shadow:0 3px 3px rgba(0,0,0,0.05);background:rgba(255,255,255,0.85);border-radius:100%;position:absolute;top:0;width:40px;text-align:center;height:40px;z-index:-2;cursor:default;opacity:0;transition:opacity .25s ease-in-out,z-index .26s linear .25s}.dcs-d-dcs-vd-dcs-bb-dcs-ke-dcs-ef-dcs-mi{transform:translate(-50%,-50%)}.dcs-d-dcs-vd-dcs-bb-dcs-ke-dcs-ef-dcs-wd{transform:translate(-65%,-50%)}#docs-instant-button-bubble.dcs-d-dcs-vd-dcs-bb-dcs-qe{opacity:1;cursor:pointer;z-index:101;transition:opacity .25s ease-in-out}#docs-instant-button-bubble.dcs-d-dcs-vd-dcs-bb-dcs-li-dcs-h{z-index:-2;opacity:0;top:0;transition:none}.dcs-d-dcs-vd-dcs-bb-dcs-ke-dcs-hb{display:inline-block;opacity:0.5;margin-top:13px;margin-left:-3px;transition:opacity .15s ease-in-out}.dcs-d-dcs-e .dcs-d-dcs-vd-dcs-bb-dcs-ke-dcs-hb{margin-top:11px}#docs-instant-button-bubble:hover .dcs-d-dcs-vd-dcs-bb-dcs-ke-dcs-hb,#docs-instant-button-bubble .dcs-d-dcs-vd-dcs-bb-dcs-ke-dcs-hb:hover{opacity:1}#docs-instant-button-bubble:hover{background:rgba(255,255,255,1)}#docs-instant-button-bubble:focus{outline:0}#docs-instant-button-bubble.dcs-d-dcs-w-dcs-bj{-ms-high-contrast-adjust:none}.dcs-cc-dcs-yj-dcs-zj{position:relative;display:-moz-inline-box;display:inline-block}* html .dcs-cc-dcs-yj-dcs-zj{display:inline}*:first-child+html .dcs-cc-dcs-yj-dcs-zj{display:inline}.dcs-cc-dcs-dc-dcs-bb{background:#ddd url(//ssl.gstatic.com/editor/button-bg.png) repeat-x top left;border:0;color:#000;cursor:pointer;list-style:none;margin:2px;outline:none;padding:0;text-decoration:none;vertical-align:middle}.dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border-style:solid;border-color:#aaa;vertical-align:top}.dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh{margin:0;border-width:1px 0;padding:0}.dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{margin:0 -1px;border-width:0 1px;padding:3px 4px}* html .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{left:-1px}* html .dcs-cc-dcs-dc-dcs-bb-dcs-wd .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh{left:-1px;right:auto}* html .dcs-cc-dcs-dc-dcs-bb-dcs-wd .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{right:auto}*:first-child+html .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{left:-1px}*:first-child+html .dcs-cc-dcs-dc-dcs-bb-dcs-wd .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{left:1px;right:auto}::root .dcs-cc-dcs-dc-dcs-bb,::root .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,::root .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{line-height:0}::root .dcs-cc-dcs-dc-dcs-bb-dcs-ff,::root .dcs-cc-dcs-dc-dcs-bb-dcs-ec{line-height:normal}.dcs-cc-dcs-dc-dcs-bb-dcs-bf{background-image:none!important;opacity:0.3;-moz-opacity:0.3;filter:alpha(opacity=30)}.dcs-cc-dcs-dc-dcs-bb-dcs-bf .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-bf .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-bf .dcs-cc-dcs-dc-dcs-bb-dcs-ff,.dcs-cc-dcs-dc-dcs-bb-dcs-bf .dcs-cc-dcs-dc-dcs-bb-dcs-ec{color:#333!important;border-color:#999!important}* html .dcs-cc-dcs-dc-dcs-bb-dcs-bf{margin:2px 1px!important;padding:0 1px!important}*:first-child+html .dcs-cc-dcs-dc-dcs-bb-dcs-bf{margin:2px 1px!important;padding:0 1px!important}.dcs-cc-dcs-dc-dcs-bb-dcs-le .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-le .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border-color:#9cf #69e #69e #7af!important}.dcs-cc-dcs-dc-dcs-bb-dcs-gb,.dcs-cc-dcs-dc-dcs-bb-dcs-ui{background-color:#bbb;background-position:bottom left}.dcs-cc-dcs-dc-dcs-bb-dcs-gh .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-gh .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border-color:orange}.dcs-cc-dcs-dc-dcs-bb-dcs-ff{padding:0 4px 0 0;vertical-align:top}.dcs-cc-dcs-dc-dcs-bb-dcs-ec{height:15px;width:7px;background:url(//ssl.gstatic.com/editor/editortoolbar.png) no-repeat -388px 0;vertical-align:top}.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-ph,.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-ph .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-ph .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{margin-right:0}.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-u,.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-u .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-u .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{margin-left:0}.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-u .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border-left:1px solid #fff}.dcs-cc-dcs-dc-dcs-bb-dcs-ah-dcs-u.dcs-cc-dcs-dc-dcs-bb-dcs-di .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border-left:1px solid #ddd}.dcs-f-dcs-bb{-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;cursor:default;font-size:11px;font-weight:bold;text-align:center;white-space:nowrap;margin-right:16px;height:27px;line-height:27px;min-width:54px;outline:0px;padding:0 8px}.dcs-f-dcs-bb-dcs-le{-webkit-box-shadow:0 1px 1px rgba(0,0,0,.1);-moz-box-shadow:0 1px 1px rgba(0,0,0,.1);box-shadow:0 1px 1px rgba(0,0,0,.1)}.dcs-f-dcs-bb-dcs-qb{-webkit-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.1);-moz-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.1);box-shadow:inset 0px 1px 2px rgba(0,0,0,0.1)}.dcs-f-dcs-bb .dcs-f-dcs-bb-dcs-ye{margin-top:-3px;vertical-align:middle}.dcs-f-dcs-bb-dcs-af{margin-left:5px}.dcs-f-dcs-bb-dcs-nf{min-width:34px;padding:0}.dcs-f-dcs-bb-dcs-ah-dcs-u,.dcs-f-dcs-bb-dcs-ah-dcs-ph{z-index:1}.dcs-f-dcs-bb-dcs-ah-dcs-u.dcs-f-dcs-bb-dcs-bf{z-index:0}.dcs-f-dcs-bb-dcs-di.dcs-f-dcs-bb-dcs-ah-dcs-u,.dcs-f-dcs-bb-dcs-di.dcs-f-dcs-bb-dcs-ah-dcs-ph{z-index:2}.dcs-f-dcs-bb-dcs-ah-dcs-u:focus,.dcs-f-dcs-bb-dcs-ah-dcs-ph:focus,.dcs-f-dcs-bb-dcs-le.dcs-f-dcs-bb-dcs-ah-dcs-u,.dcs-f-dcs-bb-dcs-le.dcs-f-dcs-bb-dcs-ah-dcs-ph{z-index:3}.dcs-f-dcs-bb-dcs-ah-dcs-u{margin-left:-1px;-moz-border-radius-bottomleft:0;-moz-border-radius-topleft:0;-webkit-border-bottom-left-radius:0;-webkit-border-top-left-radius:0;border-bottom-left-radius:0;border-top-left-radius:0}.dcs-f-dcs-bb-dcs-ah-dcs-ph{margin-right:0px;-moz-border-radius-topright:0;-moz-border-radius-bottomright:0;-webkit-border-top-right-radius:0;-webkit-border-bottom-right-radius:0;border-top-right-radius:0;border-bottom-right-radius:0}.dcs-f-dcs-bb.dcs-f-dcs-bb-dcs-bf:active{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.dcs-f-dcs-bb-dcs-ue{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background-color:#4d90fe;background-image:-webkit-linear-gradient(top,#4d90fe,#4787ed);background-image:-moz-linear-gradient(top,#4d90fe,#4787ed);background-image:-ms-linear-gradient(top,#4d90fe,#4787ed);background-image:-o-linear-gradient(top,#4d90fe,#4787ed);background-image:linear-gradient(top,#4d90fe,#4787ed);border:1px solid #3079ed;color:#fff}.dcs-f-dcs-bb-dcs-ue.dcs-f-dcs-bb-dcs-le{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background-color:#357ae8;background-image:-webkit-linear-gradient(top,#4d90fe,#357ae8);background-image:-moz-linear-gradient(top,#4d90fe,#357ae8);background-image:-ms-linear-gradient(top,#4d90fe,#357ae8);background-image:-o-linear-gradient(top,#4d90fe,#357ae8);background-image:linear-gradient(top,#4d90fe,#357ae8);border:1px solid #2f5bb7;border-bottom-color:#2f5bb7}.dcs-f-dcs-bb-dcs-ue:focus{-webkit-box-shadow:inset 0 0 0 1px #fff;-moz-box-shadow:inset 0 0 0 1px #fff;box-shadow:inset 0 0 0 1px #fff;border:1px solid #fff;border:rgba(0,0,0,0) solid 1px;outline:1px solid #4d90fe;outline:rgba(0,0,0,0) 0}.dcs-f-dcs-bb-dcs-ue.dcs-f-dcs-bb-dcs-i-dcs-j{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;outline:none}.dcs-f-dcs-bb-dcs-ue:active{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);background:#357ae8;border:1px solid #2f5bb7;border-top:1px solid #2f5bb7}.dcs-f-dcs-bb-dcs-ue.dcs-f-dcs-bb-dcs-bf{background:#4d90fe;filter:alpha(opacity=50);opacity:0.5}.dcs-f-dcs-bb-dcs-tc{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background-color:#f5f5f5;background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-moz-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-ms-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:linear-gradient(top,#f5f5f5,#f1f1f1);color:#444;border:1px solid #dcdcdc;border:1px solid rgba(0,0,0,0.1)}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-le,.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-i-dcs-j.dcs-f-dcs-bb-dcs-le{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background-color:#f8f8f8;background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-moz-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-ms-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #c6c6c6;color:#333}.dcs-f-dcs-bb-dcs-tc:active,.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-le:active{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1);background:#f8f8f8;color:#333}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-qb,.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-i-dcs-j.dcs-f-dcs-bb-dcs-qb{background-color:#eee;background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-moz-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-ms-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #ccc;color:#333}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-di,.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-i-dcs-j.dcs-f-dcs-bb-dcs-di{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1);background-color:#eee;background-image:-webkit-linear-gradient(top,#eee,#e0e0e0);background-image:-moz-linear-gradient(top,#eee,#e0e0e0);background-image:-ms-linear-gradient(top,#eee,#e0e0e0);background-image:-o-linear-gradient(top,#eee,#e0e0e0);background-image:linear-gradient(top,#eee,#e0e0e0);border:1px solid #ccc;color:#333}.dcs-f-dcs-bb-dcs-tc:focus{border:1px solid #4d90fe;outline:none}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-i-dcs-j{border:1px solid #dcdcdc;border:1px solid rgba(0,0,0,0.1);outline:none}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-bf{background:#fff;border:1px solid #f3f3f3;border:1px solid rgba(0,0,0,0.05);color:#b8b8b8}.dcs-f-dcs-bb-dcs-tc .dcs-f-dcs-bb-dcs-ye{opacity:.55}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-di .dcs-f-dcs-bb-dcs-ye,.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-qb .dcs-f-dcs-bb-dcs-ye,.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-le .dcs-f-dcs-bb-dcs-ye{opacity:0.9}.dcs-f-dcs-bb-dcs-tc.dcs-f-dcs-bb-dcs-bf .dcs-f-dcs-bb-dcs-ye{filter:alpha(opacity=33);opacity:0.333}.dcs-f-dcs-fb{-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px;background-color:rgba(255,255,255,.05);border:1px solid #c6c6c6;border:1px solid rgba(155,155,155,.57);font-size:1px;height:11px;margin:0px 4px 0px 1px;outline:0;vertical-align:text-bottom;width:11px}.dcs-f-dcs-fb-dcs-xe{background-color:#fff;background-color:rgba(255,255,255,.65)}.dcs-f-dcs-fb-dcs-di{background-color:#fff;background-color:rgba(255,255,255,.65)}.dcs-f-dcs-fb-dcs-le{-webkit-box-shadow:inset 0px 1px 1px rgba(0,0,0,.1);-moz-box-shadow:inset 0px 1px 1px rgba(0,0,0,.1);box-shadow:inset 0px 1px 1px rgba(0,0,0,.1);border:1px solid #b2b2b2}.dcs-f-dcs-fb-dcs-gb{background-color:#ebebeb}.dcs-f-dcs-fb-dcs-gh{border:1px solid #4d90fe}.dcs-f-dcs-fb-dcs-bh.dcs-f-dcs-fb-dcs-gh{border:1px solid #c6c6c6;border:1px solid rgba(155,155,155,.57)}.dcs-f-dcs-fb-dcs-bf,.dcs-f-dcs-fb-dcs-bh.dcs-f-dcs-fb-dcs-bf{background-color:#fff;border:1px solid #f1f1f1;cursor:default}.dcs-f-dcs-fb-dcs-v{height:15px;outline:0;width:15px;left:0;position:relative;top:-3px}.dcs-f-dcs-fb-dcs-xe .dcs-f-dcs-fb-dcs-v{background:url(//ssl.gstatic.com/ui/v1/menu/checkmark-partial.png) no-repeat -5px -3px;background-image:-webkit-image-set(url(//ssl.gstatic.com/ui/v1/menu/checkmark-partial.png) 1x,url(//ssl.gstatic.com/ui/v1/menu/checkmark-partial_2x.png) 2x)}.dcs-f-dcs-fb-dcs-di .dcs-f-dcs-fb-dcs-v{background:url(//ssl.gstatic.com/ui/v1/menu/checkmark.png) no-repeat -5px -3px;background-image:-webkit-image-set(url(//ssl.gstatic.com/ui/v1/menu/checkmark.png) 1x,url(//ssl.gstatic.com/ui/v1/menu/checkmark_2x.png) 2x)}.dcs-cc-dcs-wh,.dcs-s-dcs-t{-webkit-box-shadow:0 4px 16px rgba(0,0,0,.2);-moz-box-shadow:0 4px 16px rgba(0,0,0,.2);box-shadow:0 4px 16px rgba(0,0,0,.2);background:#fff;background-clip:padding-box;border:1px solid #acacac;border:1px solid rgba(0,0,0,.333);outline:0;position:absolute}.dcs-cc-dcs-wh-dcs-xb,.dcs-s-dcs-t-dcs-xb{background:#fff;left:0;position:absolute;top:0}div.dcs-cc-dcs-wh-dcs-xb,div.dcs-s-dcs-t-dcs-xb{filter:alpha(opacity=75);-moz-opacity:.75;opacity:.75}.dcs-s-dcs-t{color:#000;padding:30px 42px}.dcs-s-dcs-t-dcs-k{background-color:#fff;color:#000;cursor:default;font-size:16px;font-weight:normal;line-height:24px;margin:0 0 16px}.dcs-s-dcs-t-dcs-k-dcs-wj{height:11px;opacity:0.7;padding:17px;position:absolute;right:0px;top:0px;width:11px}.dcs-s-dcs-t-dcs-k-dcs-wj:after{content:'';background:url(//ssl.gstatic.com/ui/v1/dialog/close-x.png);position:absolute;height:11px;width:11px;right:17px}.dcs-s-dcs-t-dcs-k-dcs-wj:hover{opacity:1}.dcs-s-dcs-t-dcs-c{background-color:#fff;line-height:1.4em;word-wrap:break-word}.dcs-s-dcs-t-dcs-uh{margin-top:16px}.dcs-s-dcs-t-dcs-uh button{-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;background-color:#f5f5f5;background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-moz-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-ms-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:linear-gradient(top,#f5f5f5,#f1f1f1);border:1px solid #dcdcdc;border:1px solid rgba(0,0,0,0.1);color:#444;cursor:default;font-family:inherit;font-size:11px;font-weight:bold;height:29px;line-height:27px;margin:0 16px 0 0;min-width:72px;outline:0;padding:0 8px}.dcs-s-dcs-t-dcs-uh button:hover,.dcs-s-dcs-t-dcs-uh button:active{-webkit-box-shadow:0px 1px 1px rgba(0,0,0,0.1);-moz-box-shadow:0px 1px 1px rgba(0,0,0,0.1);box-shadow:0px 1px 1px rgba(0,0,0,0.1);background-color:#f8f8f8;background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-moz-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-ms-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #c6c6c6;color:#333}.dcs-s-dcs-t-dcs-uh button:active{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1)}.dcs-s-dcs-t-dcs-uh button:focus{border:1px solid #4d90fe}.dcs-s-dcs-t-dcs-uh button[disabled]{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background:#fff;background-image:none;border:1px solid #f3f3f3;border:1px solid rgba(0,0,0,0.05);color:#b8b8b8}.dcs-s-dcs-t-dcs-uh .dcs-cc-dcs-ch-dcs-ue{background-color:#4d90fe;background-image:-webkit-linear-gradient(top,#4d90fe,#4787ed);background-image:-moz-linear-gradient(top,#4d90fe,#4787ed);background-image:-ms-linear-gradient(top,#4d90fe,#4787ed);background-image:-o-linear-gradient(top,#4d90fe,#4787ed);background-image:linear-gradient(top,#4d90fe,#4787ed);border:1px solid #3079ed;color:#fff}.dcs-s-dcs-t-dcs-uh .dcs-cc-dcs-ch-dcs-ue:hover,.dcs-s-dcs-t-dcs-uh .dcs-cc-dcs-ch-dcs-ue:active{background-color:#357ae8;background-image:-webkit-linear-gradient(top,#4d90fe,#357ae8);background-image:-moz-linear-gradient(top,#4d90fe,#357ae8);background-image:-ms-linear-gradient(top,#4d90fe,#357ae8);background-image:-o-linear-gradient(top,#4d90fe,#357ae8);background-image:linear-gradient(top,#4d90fe,#357ae8);border:1px solid #2f5bb7;color:#fff}.dcs-s-dcs-t-dcs-uh .dcs-cc-dcs-ch-dcs-ue:active{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);box-shadow:inset 0 1px 2px rgba(0,0,0,0.3)}.dcs-s-dcs-t-dcs-uh .dcs-cc-dcs-ch-dcs-ue:focus{-webkit-box-shadow:inset 0 0 0 1px #fff;-moz-box-shadow:inset 0 0 0 1px #fff;box-shadow:inset 0 0 0 1px #fff;border:1px solid #fff;border:rgba(0,0,0,0) solid 1px;outline:1px solid #4d90fe;outline:rgba(0,0,0,0) 0}.dcs-s-dcs-t-dcs-uh .dcs-cc-dcs-ch-dcs-ue[disabled]{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background:#4d90fe;color:#fff;filter:alpha(opacity=50);opacity:0.5}.dcs-f-dcs-gi,.dcs-f-dcs-ti,.dcs-f-dcs-hd{width:512px}.dcs-cc-dcs-dc{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-shadow:0 2px 4px rgba(0,0,0,0.2);-moz-box-shadow:0 2px 4px rgba(0,0,0,0.2);box-shadow:0 2px 4px rgba(0,0,0,0.2);-webkit-transition:opacity 0.218s;-moz-transition:opacity 0.218s;-o-transition:opacity 0.218s;transition:opacity 0.218s;background:#fff;border:1px solid #ccc;border:1px solid rgba(0,0,0,.2);cursor:default;font-size:13px;margin:0;outline:none;padding:6px 0;position:absolute}.dcs-cc-dcs-cf-dcs-dc-dcs-bb{-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;background-color:#f5f5f5;background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-moz-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-ms-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);background-image:linear-gradient(top,#f5f5f5,#f1f1f1);border:1px solid #dcdcdc;color:#444;cursor:default;font-size:11px;font-weight:bold;line-height:27px;list-style:none;margin:0 2px;min-width:46px;outline:none;padding:0 18px 0 6px;text-align:center;text-decoration:none}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-bf{background-color:#fff;border-color:#f3f3f3;color:#b8b8b8}.dcs-cc-dcs-cf-dcs-dc-dcs-bb.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le{background-color:#f8f8f8;background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-moz-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-ms-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:linear-gradient(top,#f8f8f8,#f1f1f1);-webkit-box-shadow:0 1px 1px rgba(0,0,0,.1);-moz-box-shadow:0 1px 1px rgba(0,0,0,.1);box-shadow:0 1px 1px rgba(0,0,0,.1);border-color:#c6c6c6;color:#333}.dcs-cc-dcs-cf-dcs-dc-dcs-bb.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gh{border-color:#4d90fe}.dcs-cc-dcs-cf-dcs-dc-dcs-bb.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ui,.dcs-cc-dcs-cf-dcs-dc-dcs-bb.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gb{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1);background-color:#eee;background-image:-webkit-linear-gradient(top,#eee,#e0e0e0);background-image:-moz-linear-gradient(top,#eee,#e0e0e0);background-image:-ms-linear-gradient(top,#eee,#e0e0e0);background-image:-o-linear-gradient(top,#eee,#e0e0e0);background-image:linear-gradient(top,#eee,#e0e0e0);border:1px solid #ccc;color:#333;z-index:2}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ff{vertical-align:top;white-space:nowrap}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec{border-color:#777 transparent;border-style:solid;border-width:4px 4px 0 4px;height:0;width:0;position:absolute;right:5px;top:12px}.dcs-cc-dcs-cf-dcs-dc-dcs-bb .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ye{margin-top:-3px;opacity:.55;vertical-align:middle}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gb .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ye,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ui .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ye,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-qb .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ye,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ye{opacity:0.9}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gb .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ui .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-qb .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec{border-color:#595959 transparent}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-u,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ph{z-index:1}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-u.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-bf{z-index:0}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ph:focus,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ah-dcs-ph{z-index:2}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-u:focus,.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ah-dcs-u{z-index:2}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ah-dcs-u{margin-left:-1px;-moz-border-radius-bottomleft:0;-moz-border-radius-topleft:0;-webkit-border-bottom-left-radius:0;-webkit-border-top-left-radius:0;border-bottom-left-radius:0;border-top-left-radius:0;min-width:0;padding-left:0;vertical-align:top}.dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ah-dcs-ph{margin-right:0px;-moz-border-radius-topright:0;-moz-border-radius-bottomright:0;-webkit-border-top-right-radius:0;-webkit-border-bottom-right-radius:0;border-top-right-radius:0;border-bottom-right-radius:0}.dcs-cc-dcs-hf,.dcs-cc-dcs-uk,.dcs-cc-dcs-vk{position:relative;color:#333;cursor:pointer;list-style:none;margin:0;padding:6px 8em 6px 30px;white-space:nowrap}.dcs-cc-dcs-dc-dcs-wk .dcs-cc-dcs-hf,.dcs-cc-dcs-dc-dcs-xk .dcs-cc-dcs-hf{padding-left:16px;vertical-align:middle}.dcs-cc-dcs-dc-dcs-yk .dcs-cc-dcs-hf{padding-right:44px}.dcs-cc-dcs-hf-dcs-bf{cursor:default}.dcs-cc-dcs-hf-dcs-bf .dcs-cc-dcs-hf-dcs-tk,.dcs-cc-dcs-hf-dcs-bf .dcs-cc-dcs-hf-dcs-c{color:#ccc!important}.dcs-cc-dcs-hf-dcs-bf .dcs-cc-dcs-hf-dcs-hb{filter:alpha(opacity=30);opacity:0.3}.dcs-cc-dcs-hf-dcs-ne,.dcs-cc-dcs-hf-dcs-le{background-color:#eee;border-color:#eee;border-style:dotted;border-width:1px 0;padding-top:5px;padding-bottom:5px}.dcs-cc-dcs-hf-dcs-ne .dcs-cc-dcs-hf-dcs-c,.dcs-cc-dcs-hf-dcs-le .dcs-cc-dcs-hf-dcs-c{color:#333}.dcs-cc-dcs-hf-dcs-fb,.dcs-cc-dcs-hf-dcs-hb{background-repeat:no-repeat;height:21px;left:3px;position:absolute;right:auto;top:3px;vertical-align:middle;width:21px}.dcs-cc-dcs-uc-dcs-qb{background-image:url(//ssl.gstatic.com/ui/v1/menu/checkmark.png);background-repeat:no-repeat;background-position:left center}.dcs-cc-dcs-uc-dcs-qb .dcs-cc-dcs-hf-dcs-c{color:#333}.dcs-cc-dcs-hf-dcs-tk{color:#777;direction:ltr;left:auto;padding:0 6px;position:absolute;right:0;text-align:right}.dcs-cc-dcs-hf-dcs-rh-dcs-zk{text-decoration:underline}.dcs-cc-dcs-hf-dcs-rh-dcs-sh{color:#777;font-size:12px;padding-left:4px}.dcs-cc-dcs-qk-dcs-bb,.dcs-cc-dcs-qk-dcs-dc-dcs-bb{-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;background:0;border-color:transparent;border-style:solid;border-width:1px;outline:none;padding:0;height:24px;color:#444;line-height:24px;list-style:none;font-size:11px;font-weight:bold;text-decoration:none;vertical-align:middle;cursor:default}.dcs-cc-dcs-qk-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-qk-dcs-bb-dcs-ud-dcs-fh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border:0;vertical-align:top}.dcs-cc-dcs-qk-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-kh-dcs-fh{margin:0;padding:0}.dcs-cc-dcs-qk-dcs-bb-dcs-ud-dcs-fh,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ud-dcs-fh{padding:0 2px}.dcs-cc-dcs-qk-dcs-bb-dcs-le,.dcs-cc-dcs-qk-dcs-bb-dcs-gb,.dcs-cc-dcs-qk-dcs-bb-dcs-di,.dcs-cc-dcs-qk-dcs-bb-dcs-qb{color:#222;padding:0}.dcs-cc-dcs-qk-dcs-bb-dcs-le,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-le{border-color:#c6c6c6!important;color:#222}.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ui{color:#222}.dcs-cc-dcs-qk-dcs-bb-dcs-le,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-le{-webkit-box-shadow:0 1px 1px rgba(0,0,0,.1);-moz-box-shadow:0 1px 1px rgba(0,0,0,.1);box-shadow:0 1px 1px rgba(0,0,0,.1);background-color:#f8f8f8;background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-moz-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-ms-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:linear-gradient(top,#f8f8f8,#f1f1f1)}.dcs-cc-dcs-qk-dcs-bb-dcs-gb,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-gb{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1);background-color:#f6f6f6;background-image:-webkit-linear-gradient(top,#f6f6f6,#f1f1f1);background-image:-moz-linear-gradient(top,#f6f6f6,#f1f1f1);background-image:-ms-linear-gradient(top,#f6f6f6,#f1f1f1);background-image:-o-linear-gradient(top,#f6f6f6,#f1f1f1);background-image:linear-gradient(top,#f6f6f6,#f1f1f1);border-color:#c6c6c6}.dcs-cc-dcs-qk-dcs-bb-dcs-qb,.dcs-cc-dcs-qk-dcs-bb-dcs-di,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ui{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1);background-color:#eee;background-image:-webkit-linear-gradient(top,#eee,#e0e0e0);background-image:-moz-linear-gradient(top,#eee,#e0e0e0);background-image:-ms-linear-gradient(top,#eee,#e0e0e0);background-image:-o-linear-gradient(top,#eee,#e0e0e0);background-image:linear-gradient(top,#eee,#e0e0e0);border-color:#ccc}.dcs-cc-dcs-qk-dcs-bb-dcs-bf,.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-bf{color:#222!important;opacity:0.3;filter:alpha(opacity=30)}.dcs-cc-dcs-qk-dcs-bb-dcs-ah-dcs-ph,.dcs-cc-dcs-qk-dcs-bb-dcs-ah-dcs-ph .dcs-cc-dcs-qk-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-qk-dcs-bb-dcs-ah-dcs-ph .dcs-cc-dcs-qk-dcs-bb-dcs-ud-dcs-fh{margin-right:0}.dcs-cc-dcs-qk-dcs-bb-dcs-ah-dcs-u,.dcs-cc-dcs-qk-dcs-bb-dcs-ah-dcs-u .dcs-cc-dcs-qk-dcs-bb-dcs-kh-dcs-fh,.dcs-cc-dcs-qk-dcs-bb-dcs-ah-dcs-u .dcs-cc-dcs-qk-dcs-bb-dcs-ud-dcs-fh{margin-left:0}.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ec{background:url(//ssl.gstatic.com/ui/v1/disclosure/small-grey-disclosure-arrow-down.png) center no-repeat;float:right;margin:10px 2px 0 3px;padding:0;opacity:.8;vertical-align:middle;width:5px;height:7px;*float:none;*position:relative;*top:-3px}.dcs-cc-dcs-qk-dcs-sh{border-left:1px solid #ccc;height:17px;line-height:normal;list-style:none;margin:0 2px;outline:none;overflow:hidden;padding:0;text-decoration:none;vertical-align:middle;width:0}.dcs-cc-dcs-qk-dcs-ob .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ec{background:url(//ssl.gstatic.com/ui/v1/disclosure/small-grey-disclosure-arrow-down.png) center no-repeat;height:11px;margin-top:7px;width:7px;-webkit-transform:none;-moz-transform:none;transform:none;filter:none}.dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ff{padding:0;margin:0}.dcs-f-dcs-se::-webkit-scrollbar{height:16px;overflow:visible;width:16px}.dcs-f-dcs-se::-webkit-scrollbar-button{height:0;width:0}.dcs-f-dcs-se::-webkit-scrollbar-track{background-clip:padding-box;border:solid transparent;border-width:0 0 0 4px}.dcs-f-dcs-se::-webkit-scrollbar-track:horizontal{border-width:4px 0 0}.dcs-f-dcs-se::-webkit-scrollbar-track:hover{background-color:rgba(0,0,0,.05);box-shadow:inset 1px 0 0 rgba(0,0,0,.1)}.dcs-f-dcs-se::-webkit-scrollbar-track:horizontal:hover{box-shadow:inset 0 1px 0 rgba(0,0,0,.1)}.dcs-f-dcs-se::-webkit-scrollbar-track:active{background-color:rgba(0,0,0,.05);box-shadow:inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07)}.dcs-f-dcs-se::-webkit-scrollbar-track:horizontal:active{box-shadow:inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-track:hover{background-color:rgba(255,255,255,.1);box-shadow:inset 1px 0 0 rgba(255,255,255,.2)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-track:horizontal:hover{box-shadow:inset 0 1px 0 rgba(255,255,255,.2)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-track:active{background-color:rgba(255,255,255,.1);box-shadow:inset 1px 0 0 rgba(255,255,255,.25),inset -1px 0 0 rgba(255,255,255,.15)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-track:horizontal:active{box-shadow:inset 0 1px 0 rgba(255,255,255,.25),inset 0 -1px 0 rgba(255,255,255,.15)}.dcs-f-dcs-se::-webkit-scrollbar-thumb{background-color:rgba(0,0,0,.2);background-clip:padding-box;border:solid transparent;border-width:1px 1px 1px 6px;min-height:28px;padding:100px 0 0;box-shadow:inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07)}.dcs-f-dcs-se::-webkit-scrollbar-thumb:horizontal{border-width:6px 1px 1px;padding:0 0 0 100px;box-shadow:inset 1px 1px 0 rgba(0,0,0,.1),inset -1px 0 0 rgba(0,0,0,.07)}.dcs-f-dcs-se::-webkit-scrollbar-thumb:hover{background-color:rgba(0,0,0,.4);box-shadow:inset 1px 1px 1px rgba(0,0,0,.25)}.dcs-f-dcs-se::-webkit-scrollbar-thumb:active{background-color:rgba(0,0,0,0.5);box-shadow:inset 1px 1px 3px rgba(0,0,0,0.35)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-thumb{background-color:rgba(255,255,255,.3);box-shadow:inset 1px 1px 0 rgba(255,255,255,.15),inset 0 -1px 0 rgba(255,255,255,.1)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-thumb:horizontal{box-shadow:inset 1px 1px 0 rgba(255,255,255,.15),inset -1px 0 0 rgba(255,255,255,.1)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-thumb:hover{background-color:rgba(255,255,255,.6);box-shadow:inset 1px 1px 1px rgba(255,255,255,.37)}.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-thumb:active{background-color:rgba(255,255,255,.75);box-shadow:inset 1px 1px 3px rgba(255,255,255,.5)}.dcs-f-dcs-se-dcs-bl.dcs-f-dcs-se::-webkit-scrollbar-track{border-width:0 1px 0 6px}.dcs-f-dcs-se-dcs-bl.dcs-f-dcs-se::-webkit-scrollbar-track:horizontal{border-width:6px 0 1px}.dcs-f-dcs-se-dcs-bl.dcs-f-dcs-se::-webkit-scrollbar-track:hover{background-color:rgba(0,0,0,.035);box-shadow:inset 1px 1px 0 rgba(0,0,0,.14),inset -1px -1px 0 rgba(0,0,0,.07)}.dcs-f-dcs-se-dcs-bl.dcs-f-dcs-se-dcs-al.dcs-f-dcs-se::-webkit-scrollbar-track:hover{background-color:rgba(255,255,255,.07);box-shadow:inset 1px 1px 0 rgba(255,255,255,.25),inset -1px -1px 0 rgba(255,255,255,.15)}.dcs-f-dcs-se-dcs-bl.dcs-f-dcs-se::-webkit-scrollbar-thumb{border-width:0 1px 0 6px}.dcs-f-dcs-se-dcs-bl.dcs-f-dcs-se::-webkit-scrollbar-thumb:horizontal{border-width:6px 0 1px}.dcs-f-dcs-se::-webkit-scrollbar-corner{background:transparent}body.dcs-f-dcs-se::-webkit-scrollbar-track-piece{background-clip:padding-box;background-color:#f5f5f5;border:solid #fff;border-width:0 0 0 3px;box-shadow:inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07)}body.dcs-f-dcs-se::-webkit-scrollbar-track-piece:horizontal{border-width:3px 0 0;box-shadow:inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07)}body.dcs-f-dcs-se::-webkit-scrollbar-thumb{border-width:1px 1px 1px 5px}body.dcs-f-dcs-se::-webkit-scrollbar-thumb:horizontal{border-width:5px 1px 1px}body.dcs-f-dcs-se::-webkit-scrollbar-corner{background-clip:padding-box;background-color:#f5f5f5;border:solid #fff;border-width:3px 0 0 3px;box-shadow:inset 1px 1px 0 rgba(0,0,0,.14)}.dcs-f-dcs-ke{-webkit-box-shadow:0 1px 3px rgba(0,0,0,.2);-moz-box-shadow:0 1px 3px rgba(0,0,0,.2);box-shadow:0 1px 3px rgba(0,0,0,.2);background-color:#fff;border:1px solid;border-color:#bbb #bbb #a8a8a8;padding:16px;position:absolute;z-index:1201!important}.dcs-f-dcs-ke-dcs-cl{background:url("//ssl.gstatic.com/ui/v1/icons/common/x_8px.png") no-repeat;border:1px solid transparent;height:21px;opacity:.4;outline:0;position:absolute;right:2px;top:2px;width:21px}.dcs-f-dcs-ke-dcs-cl:focus{border:1px solid #4d90fe;opacity:.8}.dcs-f-dcs-ke-dcs-td{position:absolute}.dcs-f-dcs-ke-dcs-td .dcs-f-dcs-ke-dcs-rf,.dcs-f-dcs-ke-dcs-td .dcs-f-dcs-ke-dcs-wi{display:block;height:0;position:absolute;width:0}.dcs-f-dcs-ke-dcs-td .dcs-f-dcs-ke-dcs-rf{border:9px solid}.dcs-f-dcs-ke-dcs-td .dcs-f-dcs-ke-dcs-wi{border:8px solid}.dcs-f-dcs-ke-dcs-cj{bottom:0}.dcs-f-dcs-ke-dcs-gc{top:-9px}.dcs-f-dcs-ke-dcs-rg{left:-9px}.dcs-f-dcs-ke-dcs-ri{right:0}.dcs-f-dcs-ke-dcs-cj .dcs-f-dcs-ke-dcs-rf,.dcs-f-dcs-ke-dcs-gc .dcs-f-dcs-ke-dcs-rf{border-color:#bbb transparent;left:-9px}.dcs-f-dcs-ke-dcs-cj .dcs-f-dcs-ke-dcs-rf{border-color:#a8a8a8 transparent}.dcs-f-dcs-ke-dcs-cj .dcs-f-dcs-ke-dcs-wi,.dcs-f-dcs-ke-dcs-gc .dcs-f-dcs-ke-dcs-wi{border-color:#fff transparent;left:-8px}.dcs-f-dcs-ke-dcs-cj .dcs-f-dcs-ke-dcs-rf{border-bottom-width:0}.dcs-f-dcs-ke-dcs-cj .dcs-f-dcs-ke-dcs-wi{border-bottom-width:0}.dcs-f-dcs-ke-dcs-gc .dcs-f-dcs-ke-dcs-rf{border-top-width:0}.dcs-f-dcs-ke-dcs-gc .dcs-f-dcs-ke-dcs-wi{border-top-width:0;top:1px}.dcs-f-dcs-ke-dcs-rg .dcs-f-dcs-ke-dcs-rf,.dcs-f-dcs-ke-dcs-ri .dcs-f-dcs-ke-dcs-rf{border-color:transparent #bbb;top:-9px}.dcs-f-dcs-ke-dcs-rg .dcs-f-dcs-ke-dcs-wi,.dcs-f-dcs-ke-dcs-ri .dcs-f-dcs-ke-dcs-wi{border-color:transparent #fff;top:-8px}.dcs-f-dcs-ke-dcs-rg .dcs-f-dcs-ke-dcs-rf{border-left-width:0}.dcs-f-dcs-ke-dcs-rg .dcs-f-dcs-ke-dcs-wi{border-left-width:0;left:1px}.dcs-f-dcs-ke-dcs-ri .dcs-f-dcs-ke-dcs-rf{border-right-width:0}.dcs-f-dcs-ke-dcs-ri .dcs-f-dcs-ke-dcs-wi{border-right-width:0}.dcs-f-dcs-g{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;-webkit-transition:visibility 0,opacity .13s ease-in;-moz-transition:visibility 0,opacity .13s ease-in;-o-transition:visibility 0,opacity .13s ease-in;transition:visibility 0,opacity .13s ease-in;background-color:#2a2a2a;border:1px solid #fff;color:#fff;cursor:default;display:block;font-size:11px;font-weight:bold;margin-left:-1px;opacity:1;padding:7px 9px;position:absolute;visibility:visible;white-space:pre-wrap;word-break:break-all;word-break:break-word}.dcs-f-dcs-g-dcs-h{-webkit-transition:visibility .13s,opacity .13s ease-out,left 0 linear .13s,top 0 linear .13s;-moz-transition:visibility .13s,opacity .13s ease-out,left 0 linear .13s,top 0 linear .13s;-o-transition:visibility .13s,opacity .13s ease-out,left 0 linear .13s,top 0 linear .13s;transition:visibility .13s,opacity .13s ease-out,left 0 linear .13s,top 0 linear .13s;opacity:0;left:20px!important;top:20px!important;visibility:hidden}.dcs-f-dcs-g-dcs-zi{display:none}.dcs-f-dcs-g-dcs-td{pointer-events:none;position:absolute}.dcs-f-dcs-g-dcs-td .dcs-f-dcs-g-dcs-rf,.dcs-f-dcs-g-dcs-td .dcs-f-dcs-g-dcs-wi{content:'';display:block;height:0;position:absolute;width:0}.dcs-f-dcs-g-dcs-td .dcs-f-dcs-g-dcs-rf{border:6px solid}.dcs-f-dcs-g-dcs-td .dcs-f-dcs-g-dcs-wi{border:5px solid}.dcs-f-dcs-g-dcs-cj{bottom:0}.dcs-f-dcs-g-dcs-gc{top:-6px}.dcs-f-dcs-g-dcs-rg{left:-6px}.dcs-f-dcs-g-dcs-ri{right:0}.dcs-f-dcs-g-dcs-cj .dcs-f-dcs-g-dcs-rf,.dcs-f-dcs-g-dcs-gc .dcs-f-dcs-g-dcs-rf{border-color:#fff transparent;left:-6px}.dcs-f-dcs-g-dcs-cj .dcs-f-dcs-g-dcs-wi,.dcs-f-dcs-g-dcs-gc .dcs-f-dcs-g-dcs-wi{border-color:#2a2a2a transparent;left:-5px}.dcs-f-dcs-g-dcs-cj .dcs-f-dcs-g-dcs-rf{border-bottom-width:0}.dcs-f-dcs-g-dcs-cj .dcs-f-dcs-g-dcs-wi{border-bottom-width:0}.dcs-f-dcs-g-dcs-gc .dcs-f-dcs-g-dcs-rf{border-top-width:0}.dcs-f-dcs-g-dcs-gc .dcs-f-dcs-g-dcs-wi{border-top-width:0;top:1px}.dcs-f-dcs-g-dcs-rg .dcs-f-dcs-g-dcs-rf,.dcs-f-dcs-g-dcs-ri .dcs-f-dcs-g-dcs-rf{border-color:transparent #fff;top:-6px}.dcs-f-dcs-g-dcs-rg .dcs-f-dcs-g-dcs-wi,.dcs-f-dcs-g-dcs-ri .dcs-f-dcs-g-dcs-wi{border-color:transparent #2a2a2a;top:-5px}.dcs-f-dcs-g-dcs-rg .dcs-f-dcs-g-dcs-rf{border-left-width:0}.dcs-f-dcs-g-dcs-rg .dcs-f-dcs-g-dcs-wi{border-left-width:0;left:1px}.dcs-f-dcs-g-dcs-ri .dcs-f-dcs-g-dcs-rf{border-right-width:0}.dcs-f-dcs-g-dcs-ri .dcs-f-dcs-g-dcs-wi{border-right-width:0}.dcs-s-dcs-t{z-index:1001}.dcs-s-dcs-t-dcs-xb{z-index:1000}.dcs-s-dcs-t-dcs-k-dcs-wj{background-image:none}.dcs-cc-dcs-dc{z-index:1001}.dcs-a-dcs-jh-dcs-kh{width:11px;height:11px}.dcs-a-dcs-jh-dcs-kh>.dcs-a-dcs-wg-dcs-ec{width:11px;height:11px;margin:auto;vertical-align:top;cursor:pointer}.dcs-a-dcs-jh-dcs-kh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ec{width:11px;height:11px;margin:0;padding:0}.dcs-a-dcs-jh-dcs-kh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ud-dcs-fh,.dcs-a-dcs-jh-dcs-kh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-kh-dcs-fh{width:11px;min-width:11px;height:11px;min-height:11px}.dcs-a-dcs-jh>.dcs-cc-dcs-hf{padding-left:10px;padding-right:10px}.dcs-a-dcs-cb{background-color:#f5f5f5;cursor:pointer;direction:ltr;position:relative;width:240px;border:none;box-shadow:0 1px 3px rgba(0,0,0,0.3);border-radius:2px}.dcs-a-dcs-q-dcs-gb.dcs-a-dcs-cb{cursor:default}.dcs-a-dcs-cb:focus,.dcs-a-dcs-cb:active{outline:0}.dcs-a-dcs-cb-dcs-td-dcs-ud,.dcs-a-dcs-cb-dcs-td-dcs-kh{display:none}.dcs-a-dcs-cb-dcs-tb{max-height:inherit;overflow-y:auto;overflow-x:hidden}.dcs-a-dcs-cb-dcs-c{overflow-y:auto;overflow-x:hidden}.dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-db-dcs-eb{border:none;display:none;padding:8px}.dcs-a-dcs-cb .dcs-a-dcs-lh-dcs-db-dcs-eb{background:#fff}.dcs-a-dcs-q-dcs-gb.dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-db-dcs-eb{display:block}.dcs-a-dcs-cb-dcs-db-dcs-eb .dcs-a-dcs-db-dcs-te{display:block;height:26px}.dcs-a-dcs-cb-dcs-db-dcs-eb .dcs-a-dcs-db-dcs-uh{text-align:left}.dcs-a-dcs-lh-dcs-db-dcs-eb{border-top:none!important;padding-top:0}.dcs-a-dcs-cb .dcs-a-dcs-db-dcs-ei-dcs-fi-dcs-if,.dcs-a-dcs-cb .dcs-a-dcs-db-dcs-kk-dcs-lk-dcs-if,.dcs-a-dcs-cb .dcs-a-dcs-db-dcs-ld-dcs-if,.dcs-a-dcs-cb .dcs-a-dcs-db-dcs-qi-dcs-if{color:#777;font-size:12px;font-family:Arial,sans-serif;margin-top:8px}.dcs-a-dcs-tf-dcs-hg .dcs-a-dcs-cb{position:absolute;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;z-index:500}.dcs-a-dcs-tf-dcs-hg .dcs-a-dcs-wg-dcs-qe.dcs-a-dcs-cb,.dcs-a-dcs-tf-dcs-hg .dcs-a-dcs-q-dcs-gb.dcs-a-dcs-cb{z-index:501}.dcs-a-dcs-tf-dcs-hg-dcs-ig .dcs-a-dcs-cb{box-shadow:0 2px 4px rgba(0,0,0,0.2)}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb-dcs-td-dcs-ud,.dcs-a-dcs-cb-dcs-td-dcs-kh{height:0;position:absolute;width:0}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-ud{border-top:none;border-bottom:18px solid transparent;border-left:none;border-right:18px solid #fff;left:-13px;top:0}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-q-dcs-r.dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-ud{border-right:18px solid #eee}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-kh{border-top:none;border-bottom:24px solid transparent;border-left:none;border-right:24px solid rgba(0,0,0,0.135);left:-15px;top:-1px;z-index:-1}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-q-dcs-gb.dcs-a-dcs-cb>.dcs-a-dcs-cb-dcs-td-dcs-ud,.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-q-dcs-gb.dcs-a-dcs-cb>.dcs-a-dcs-cb-dcs-td-dcs-kh{display:block}.dcs-a-dcs-cb .dcs-a-dcs-db-dcs-zc{margin-right:10px}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-ud.dcs-a-dcs-nb-dcs-gg{border-right:18px solid #fff}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-ud.dcs-a-dcs-nb-dcs-of{border-right:18px solid #f2f2f2}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-ud.dcs-a-dcs-nb-dcs-pi{border-right:18px solid #4285f4}.dcs-a-dcs-mc .dcs-a-dcs-rb-dcs-sb{background-color:rgba(140,196,116,0.5)}.dcs-a-dcs-mc .dcs-a-dcs-qb-dcs-rb-dcs-sb{background-color:rgba(140,196,116,1)}.dcs-a-dcs-mc,.dcs-a-dcs-dh{border:none;border-bottom:1px solid #e5e5e5;padding:3px 8px 5px 8px;zoom:1;background:#f5f5f5;position:static}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb{box-shadow:0px 3px 6px rgba(0,0,0,0.2)}.dcs-a-dcs-cb .dcs-a-dcs-mc:last-of-type{padding-bottom:12px}.dcs-a-dcs-cb .dcs-a-dcs-z-dcs-be.dcs-a-dcs-mc{padding:8px;border-bottom:1px solid #ddd;background:#fff;min-height:36px}.dcs-a-dcs-q-dcs-r .dcs-a-dcs-mc,.dcs-a-dcs-q-dcs-r .dcs-a-dcs-dh,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-r .dcs-a-dcs-z-dcs-be.dcs-a-dcs-mc{background:#eee}.dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-rk .dcs-a-dcs-z-dcs-be.dcs-a-dcs-mc{border:none}.dcs-a-dcs-mc .dcs-a-dcs-mc-dcs-yc{left:0!important;display:block}.dcs-a-dcs-mc.dcs-a-dcs-z-dcs-be{border-top:none!important}.dcs-a-dcs-mc-dcs-cg .dcs-a-dcs-mc-dcs-kd{margin:0;margin-top:2px;color:#333;font-size:13px;font-weight:normal;height:18px}.dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-db-dcs-eb .dcs-a-dcs-db-dcs-te,.dcs-a-dcs-mc .dcs-a-dcs-mc-dcs-pe .dcs-a-dcs-mc-dcs-zg{line-height:1.4}.dcs-a-dcs-mc .dcs-a-dcs-mc-dcs-pe{word-wrap:break-word;color:#333;padding:0}.dcs-a-dcs-mc-dcs-cg .dcs-a-dcs-mc-dcs-mf{margin:0;color:#777;font-size:11px}.dcs-a-dcs-mc .dcs-a-dcs-z-dcs-ab-dcs-bb-dcs-kf-dcs-lf,.dcs-a-dcs-mc .dcs-a-dcs-qf-dcs-jb,.dcs-a-dcs-mc .dcs-a-dcs-ib-dcs-jb{min-width:28px;width:28px;opacity:0.2}.dcs-a-dcs-mc .dcs-a-dcs-fd-dcs-bb,.dcs-a-dcs-mc .dcs-a-dcs-dg-dcs-bb,.dcs-a-dcs-mc .dcs-a-dcs-z-dcs-ab-dcs-bb-dcs-kf-dcs-lf,.dcs-a-dcs-mc .dcs-a-dcs-qf-dcs-jb,.dcs-a-dcs-mc .dcs-a-dcs-ib-dcs-jb{height:28px;margin:0;position:relative;top:auto;right:auto;display:inline-block;vertical-align:middle}.dcs-a-dcs-mc .dcs-a-dcs-fd-dcs-bb,.dcs-a-dcs-mc .dcs-a-dcs-z-dcs-ab-dcs-bb-dcs-kf-dcs-lf,.dcs-a-dcs-mc .dcs-a-dcs-qf-dcs-jb,.dcs-a-dcs-mc .dcs-a-dcs-ib-dcs-jb{padding:0}.dcs-a-dcs-mc .dcs-a-dcs-qf-dcs-jb{right:-1px}.dcs-a-dcs-mc .dcs-a-dcs-qf-dcs-jb div,.dcs-a-dcs-mc .dcs-a-dcs-ib-dcs-jb div{margin:auto;margin-top:1px}.dcs-a-dcs-qf-dcs-jb{border-radius:3px 0 0 3px}.dcs-a-dcs-ib-dcs-jb{border-radius:0 3px 3px 0}.dcs-a-dcs-qf-dcs-jb.dcs-f-dcs-bb-dcs-bf,.dcs-a-dcs-ib-dcs-jb.dcs-f-dcs-bb-dcs-bf{background-color:#f9f9f9}.dcs-a-dcs-q-dcs-gb.dcs-a-dcs-cb .dcs-a-dcs-z-dcs-jc,.dcs-a-dcs-q-dcs-gb.dcs-a-dcs-dh .dcs-a-dcs-z-dcs-jc{display:block}.dcs-a-dcs-dh-dcs-eh{word-wrap:break-word;color:#15c}.dcs-a-dcs-dh-dcs-eh:hover,.dcs-a-dcs-cb:hover .dcs-a-dcs-dh-dcs-eh{text-decoration:underline}.dcs-a-dcs-qg-dcs-z{position:relative;margin:6px 0;padding:0}.dcs-a-dcs-qg-dcs-z.dcs-a-dcs-qg-dcs-z-dcs-dk{margin:0}.dcs-a-dcs-mc .dcs-a-dcs-eh-dcs-z{height:78px;overflow:hidden}.dcs-a-dcs-zh-dcs-hk,.dcs-a-dcs-zh-dcs-ai{color:#15c;display:none;opacity:1;width:100%;outline:none}.dcs-a-dcs-zh-dcs-hk:focus,.dcs-a-dcs-zh-dcs-ai:focus{text-decoration:underline}.dcs-a-dcs-zh-dcs-hk{bottom:0;padding-top:16px;position:absolute;right:0}.dcs-a-dcs-cb .dcs-a-dcs-zh-dcs-ai,.dcs-a-dcs-cb .dcs-a-dcs-zh-dcs-hk{cursor:pointer;font-size:11px}.dcs-a-dcs-cb .dcs-a-dcs-zh-dcs-ai{background:#f5f5f5;padding:2px 0}.dcs-a-dcs-cb .dcs-a-dcs-zh-dcs-hk{padding:7px 0 2px 0}.dcs-a-dcs-cb .dcs-a-dcs-z-dcs-be .dcs-a-dcs-zh-dcs-ai{background:#fff}.dcs-a-dcs-zh-dcs-hk:hover,.dcs-a-dcs-zh-dcs-ai:hover{text-decoration:underline}.dcs-a-dcs-cb .dcs-a-dcs-zh-dcs-hk{background:#f5f5f5;-ms-filter:none;filter:none}.dcs-a-dcs-cb .dcs-a-dcs-z-dcs-be .dcs-a-dcs-zh-dcs-hk{background:#fff}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-wf-dcs-xf:hover .dcs-a-dcs-zh-dcs-hk{background:#f5f5f5;-ms-filter:none;filter:none}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-wf-dcs-xf:hover .dcs-a-dcs-z-dcs-be .dcs-a-dcs-zh-dcs-hk{background:#fff}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-zh-dcs-hk,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb:hover .dcs-a-dcs-zh-dcs-hk{background:#f5f5f5;-ms-filter:none;filter:none}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-z-dcs-be .dcs-a-dcs-zh-dcs-hk,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb:hover .dcs-a-dcs-z-dcs-be .dcs-a-dcs-zh-dcs-hk{background:#fff}.dcs-a-dcs-eh-dcs-z>.dcs-a-dcs-zh-dcs-hk{display:block}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-zh-dcs-ai{background:#f5f5f5}.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-z-dcs-be .dcs-a-dcs-zh-dcs-ai{background:#fff}.dcs-a-dcs-mc-dcs-cg{margin:6px 0;height:38px;white-space:nowrap;display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.dcs-a-dcs-z-dcs-be .dcs-a-dcs-mc-dcs-cg{margin:0;margin-bottom:8px}.dcs-a-dcs-cb-dcs-rk .dcs-a-dcs-z-dcs-be .dcs-a-dcs-mc-dcs-cg{margin:0}.dcs-a-dcs-mc-dcs-qj{white-space:nowrap}.dcs-a-dcs-cb:hover .dcs-a-dcs-ib-dcs-jb,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-ib-dcs-jb,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-ib-dcs-jb,.dcs-a-dcs-cb:hover .dcs-a-dcs-qf-dcs-jb,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-qf-dcs-jb,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-qf-dcs-jb,.dcs-a-dcs-cb:hover .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-oc,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-oc,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-oc,.dcs-a-dcs-cb:hover .dcs-a-dcs-z-dcs-ab-dcs-bb,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-z-dcs-ab-dcs-bb,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-z-dcs-ab-dcs-bb,.dcs-a-dcs-cb:hover .dcs-a-dcs-xi-dcs-kh>.dcs-a-dcs-wg-dcs-ec,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-xi-dcs-kh>.dcs-a-dcs-wg-dcs-ec,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-xi-dcs-kh>.dcs-a-dcs-wg-dcs-ec{opacity:0.7}.dcs-a-dcs-cb:hover .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-y,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-y,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-y{border:1px solid rgba(255,255,255,.7)}.dcs-a-dcs-xi-dcs-kh .dcs-cc-dcs-dc{z-index:600}.dcs-a-dcs-mc-dcs-qj:hover .dcs-a-dcs-ib-dcs-jb,.dcs-a-dcs-mc-dcs-qj:hover .dcs-a-dcs-z-dcs-ab-dcs-bb{border-top-right-radius:0;border-bottom-right-radius:0}.dcs-a-dcs-mc-dcs-qj>.dcs-a-dcs-ib-dcs-jb:hover,.dcs-a-dcs-mc-dcs-qj>.dcs-a-dcs-z-dcs-ab-dcs-bb:hover{border-top-right-radius:2px;border-bottom-right-radius:2px}.dcs-a-dcs-z-dcs-be .dcs-a-dcs-mc-dcs-qj{padding:4px 0 4px 4px}.dcs-a-dcs-qf-dcs-jb{margin-right:-1px}.dcs-a-dcs-mc-dcs-ih{padding-left:10px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-box-flex:1;box-flex:1;-ms-flex-positive:1;-webkit-flex-grow:1;flex-grow:1}.dcs-a-dcs-mc-dcs-ih>*{overflow:hidden;text-overflow:ellipsis}.dcs-a-dcs-mc-dcs-yc-dcs-vf{max-width:32px}.dcs-a-dcs-mc-dcs-cg .dcs-a-dcs-yc{position:relative}.dcs-a-dcs-ed-dcs-jf{width:32px;height:6px}.dcs-a-dcs-z-dcs-ab-dcs-bb-dcs-jk{display:inline-block;margin:0;opacity:0.2;padding-left:2px;position:relative;padding:0 4px 0 4px;min-width:50px;height:28px;vertical-align:top}.dcs-a-dcs-mc .dcs-a-dcs-z-dcs-bc{margin-left:0}.dcs-a-dcs-mc-dcs-zg{word-wrap:break-word;color:#777;margin:8px -8px 0 -8px;padding:8px 8px 4px 8px;border-color:#e5e5e5;border-top-style:solid;border-top-width:1px;font-size:11px;font-style:italic}.dcs-a-dcs-mc .dcs-a-dcs-ue-dcs-l{color:#707070;font-style:italic;word-wrap:break-word;-ms-word-wrap:break-word;overflow-wrap:break-word}.dcs-a-dcs-ue-dcs-l-dcs-ve-dcs-we{padding:8px 0 3px 0;position:relative}.dcs-a-dcs-cb .dcs-a-dcs-mc:last-of-type .dcs-a-dcs-ue-dcs-l-dcs-ve-dcs-we{padding:8px 0 0 0}.dcs-a-dcs-jd{padding:7px 10px 7px 8px;border-bottom:solid #dddddd 1px}.dcs-a-dcs-jd table{border-spacing:0;width:100%}.dcs-a-dcs-jd.dcs-a-dcs-nb-dcs-of{background-color:#f2f2f2;color:#333333}.dcs-a-dcs-jd.dcs-a-dcs-nb-dcs-pi{background-color:#4285f4;color:white}.dcs-a-dcs-jd-dcs-yc.dcs-a-dcs-yc{position:relative;display:block}.dcs-a-dcs-jd-dcs-hh{padding:0px 0px 0px 10px;width:100%;max-width:135px}.dcs-a-dcs-jd-dcs-nb-dcs-l{font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dcs-a-dcs-jd .dcs-a-dcs-hb-dcs-v-dcs-oc{margin-top:1px}.dcs-a-dcs-jd .dcs-a-dcs-hb-dcs-v-dcs-y{margin-top:6px}.dcs-a-dcs-jd .dcs-a-dcs-th-dcs-qd-dcs-bb{width:28px;height:28px;min-width:28px;padding:0px;margin:0px;background:none}.dcs-a-dcs-jd .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-oc{opacity:0.2}.dcs-a-dcs-jd .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-y{border:1px solid rgba(255,255,255,.38);opacity:0.7}.dcs-a-dcs-jd .dcs-a-dcs-th-dcs-qd-dcs-bb-dcs-y:hover{border:1px solid rgba(255,255,255,1);opacity:1;background:none}.dcs-a-dcs-vg{background:#fff;border:1px solid #c8c8c8;font-family:Arial;margin:0px 0px;padding:4px 0px 4px 0px;position:absolute;z-index:900}.dcs-a-dcs-vg div{cursor:pointer}.dcs-a-dcs-vg .dcs-vg-dcs-ji{height:auto;padding:0px}.dcs-a-dcs-vg .dcs-vg-dcs-gb{background-color:#eee}.dcs-a-dcs-vg div.dcs-gb{background-color:#eee}.dcs-a-dcs-yc{left:0;position:absolute;object-fit:cover}.dcs-a-dcs-yc-dcs-ie{opacity:0.4}.dcs-a-dcs-pf-dcs-id{font:10px/12px Arial;color:#bbb;text-align:right;padding-right:30px}.dcs-a-dcs-pf-dcs-id a{color:#bbb}.dcs-a-dcs-ii-dcs-ji{height:32px;color:rgb(0,0,0);padding:4px 8px;font-family:Arial}.dcs-a-dcs-ii-dcs-ji .dcs-a-dcs-yc{float:left;left:initial;position:relative;padding-right:8px}.dcs-a-dcs-ii-dcs-ji-dcs-yi,.dcs-a-dcs-ii-dcs-ji-dcs-ki{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.dcs-a-dcs-ii-dcs-ji-dcs-ki{color:#777;font-size:0.9em}.dcs-pc-dcs-dl-dcs-s{color:black;font-family:Arial,sans-serif,sans;font-size:13px;white-space:normal}.dcs-pc-dcs-dl-dcs-s button.dcs-pc-dcs-dl-dcs-pc-dcs-bb,.dcs-pc-dcs-dl-dcs-s button.dcs-pc-dcs-dl-dcs-pc-dcs-bb:hover{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;background-color:#4d90fe;background-color:#4d90fe;background-image:-webkit-linear-gradient(top,#4d90fe,#4787ed);background-image:-moz-linear-gradient(top,#4d90fe,#4787ed);background-image:-ms-linear-gradient(top,#4d90fe,#4787ed);background-image:-o-linear-gradient(top,#4d90fe,#4787ed);background-image:linear-gradient(top,#4d90fe,#4787ed);border:1px solid #3079ed;color:#fff}.dcs-a{color:black;font-family:Arial,sans-serif,sans;font-size:13px;white-space:normal}.dcs-a-dcs-hb{overflow:hidden;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none}.dcs-a-dcs-hb-dcs-ye:before{content:url(//ssl.gstatic.com/docs/common/d-icons27.png)}.dcs-a-dcs-hb-dcs-ye-dcs-ze:before{transform:scale(0.5);transform-origin:0 0;display:inline-block;image-rendering:optimizeSpeed;image-rendering:-moz-crisp-edges;image-rendering:-o-crisp-edges;image-rendering:-webkit-optimize-contrast;image-rendering:optimize-contrast;-ms-interpolation-mode:nearest-neighbor}.dcs-a-dcs-hb-dcs-ye{*background:url(//ssl.gstatic.com/docs/common/d-icons27.png)}.dcs-a-dcs-hb-dcs-ye-dcs-de{position:absolute}.dcs-a-dcs-hb-dcs-nc-dcs-oc{top:-88px;left:-4px}.dcs-a-dcs-hb-dcs-nc-dcs-p{top:-106px;left:-4px}.dcs-a-dcs-hb-dcs-nc-dcs-fe{height:18px;width:18px}.dcs-a-dcs-hb-dcs-ag{top:-25px;left:-25px}.dcs-a-dcs-hb-dcs-ag-dcs-fe{height:13px;width:11px}.dcs-a-dcs-hb-dcs-el-dcs-lc{top:-48px;left:-1px}.dcs-a-dcs-hb-dcs-qf-dcs-v-dcs-oc{left:0px;top:0px}.dcs-a-dcs-hb-dcs-qf-dcs-v-dcs-y{top:-140px;left:-49px}.dcs-a-dcs-hb-dcs-qf-dcs-v-dcs-fe{height:21px;width:21px}.dcs-a-dcs-hb-dcs-ib-dcs-jb-dcs-kb{top:-45px;left:-21px}.dcs-a-dcs-hb-dcs-ib-dcs-jb-dcs-kb-dcs-fe{height:21px;width:21px}.dcs-a-dcs-hb-dcs-el-dcs-lc-dcs-fe{height:14px;width:18px}.dcs-a-dcs-hb-dcs-hj-dcs-ij-dcs-jj{left:-25px;top:0px}.dcs-a-dcs-hb-dcs-hj-dcs-ij-dcs-jj-dcs-fe{height:21px;width:14px}.dcs-a-dcs-hb-dcs-ee{top:-64px;left:-2px}.dcs-a-dcs-hb-dcs-ee-dcs-fe{height:21px;width:21px}.dcs-a-dcs-w-dcs-re .dcs-a-dcs-hb-dcs-ye,.dcs-a-dcs-w-dcs-x .dcs-a-dcs-hb-dcs-ye{filter:invert(100%)}.dcs-a-dcs-w-dcs-bj .dcs-a-dcs-hb-dcs-ye{-ms-high-contrast-adjust:none;background-color:white}.dcs-a-dcs-hb-dcs-vd-dcs-a-dcs-mi{top:-48px;left:12px;height:14px;width:18px;position:absolute;clip:rect(48px,20px,72px,0px)}.dcs-a-dcs-hb-dcs-vd-dcs-a-dcs-wd{top:-48px;left:60px;height:14px;width:18px;position:absolute;clip:rect(48px,-28px,63px,-48px)}.dcs-a-dcs-w-dcs-re .dcs-f-dcs-fb-dcs-di .dcs-f-dcs-fb-dcs-v::before,.dcs-a-dcs-w-dcs-x .dcs-f-dcs-fb-dcs-di .dcs-f-dcs-fb-dcs-v::before{content:url(//ssl.gstatic.com/docs/common/d-icons27.png);position:absolute;left:-50px;top:-124px;width:15px;height:15px;clip:rect(125px,65px,140px,51px)}.dcs-d-dcs-e>.dcs-a-dcs-sd-dcs-lc-dcs-hb>.dcs-a-dcs-hb-dcs-kc-dcs-lc{top:-125px;left:-4px}.dcs-d-dcs-e>.dcs-a-dcs-hb-dcs-kc-dcs-lc-dcs-fe{height:18px;width:18px}.dcs-d-dcs-e .dcs-a-dcs-hb-dcs-vd-dcs-a-dcs-mi{top:-125px;left:11px;height:18px;width:18px;clip:rect(125px,20px,145px,0px)}.dcs-d-dcs-e .dcs-a-dcs-hb-dcs-vd-dcs-a-dcs-wd{top:-125px;left:59px;height:18px;width:18px;clip:rect(125px,-28px,145px,-48px)}.dcs-a-dcs-db{position:relative;zoom:1}.dcs-a-dcs-db.dcs-a-dcs-db-dcs-oj{display:block!important}.dcs-a-dcs-db-dcs-dj-dcs-ud{border-top:7px solid transparent;border-right:8px solid #fff;border-bottom:7px solid transparent;height:0;left:-6px;position:absolute;top:3px}.dcs-a-dcs-db-dcs-dj-dcs-kh{border-top:7px solid transparent;border-right:8px solid #c8c8c8;border-bottom:7px solid transparent;height:0;left:-7px;position:absolute;top:3px}.dcs-a-dcs-db-dcs-te{border:1px solid #c8c8c8;box-sizing:border-box;-moz-box-sizing:border-box;-ms-box-sizing:border-box;-webkit-box-sizing:border-box;color:#999;font-family:Arial,sans-serif;font-size:13px;margin:0;overflow-x:hidden;overflow-y:hidden;outline-width:0!important;padding:4px;resize:none;width:100%}.dcs-a-dcs-db-dcs-te:disabled{background-color:#eee!important}*:first-child+html .dcs-a-dcs-db-dcs-te{width:95%}.dcs-a-dcs-db-dcs-uh{display:none;zoom:1}.dcs-a-dcs-db-dcs-uh-dcs-zc{font-weight:bold}.dcs-a-dcs-db-dcs-og>.dcs-a-dcs-db-dcs-te{color:#000}.dcs-a-dcs-db-dcs-og>.dcs-a-dcs-db-dcs-uh{display:block}.dcs-a-dcs-db-dcs-mk-dcs-nk-dcs-l{color:#616161;font-style:italic;padding:5px 0 3px 0;word-wrap:break-word}.dcs-a-dcs-db-dcs-ld-dcs-md{padding:6px 8px 4px 8px;background-color:#f5f5f5;border-style:solid;border-width:0 1px 1px 1px;border-color:#c8c8c8;margin-bottom:8px;cursor:pointer}.dcs-a-dcs-db-dcs-ld-dcs-fh{margin:2px 10px 0 0;float:left;width:11px}.dcs-a-dcs-cb .dcs-a-dcs-db-dcs-nb-dcs-l{margin-top:1px}.dcs-a-dcs-db-dcs-nb-dcs-l{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px;font-family:Arial,sans-serif;color:#707070;font-weight:normal;display:inline-block;width:calc(100% - 51px)}.dcs-a-dcs-db-dcs-nb-dcs-l.dcs-a-dcs-db-dcs-nb-dcs-l-dcs-cd-dcs-jg{width:calc(100% - 23px)}.dcs-a-dcs-lb .dcs-a-dcs-db-dcs-nb-dcs-ob{margin-top:0px}.dcs-a-dcs-nb-dcs-ob-dcs-sf{border:1px solid #4d90fe!important;border-radius:2px}.dcs-a-dcs-db-dcs-nb-dcs-ob{border:none;-moz-box-shadow:none;-webkit-box-shadow:none;background:none;box-shadow:none;cursor:pointer;float:right;width:24px;height:15px;margin:2px}.dcs-a-dcs-db-dcs-nb-dcs-ob .dcs-cc-dcs-dc-dcs-bb-dcs-ff{padding:0px}.dcs-a-dcs-db-dcs-nb-dcs-ob .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{margin:0px}.dcs-a-dcs-nb-dcs-ob-dcs-pb{padding:0px;border-width:0px}.dcs-a-dcs-nb-dcs-ob-dcs-pb.dcs-cc-dcs-hf-dcs-ne{background-color:#f2f2f2}.dcs-cc-dcs-dc.dcs-cc-dcs-dc-dcs-uf.dcs-a-dcs-nb-dcs-ob-dcs-dc{padding:4px 0 4px 0;max-height:222px;overflow-y:auto;box-sizing:border-box}.dcs-a-dcs-db-dcs-ld-dcs-md .dcs-cc-dcs-dc-dcs-bb-dcs-ec{width:24px;background:url(//ssl.gstatic.com/images/icons/material/system/2x/arrow_drop_down_black_24dp.png) center no-repeat;background-size:24px;opacity:0.54;box-sizing:border-box}.dcs-a-dcs-db-dcs-ld-dcs-md .dcs-cc-dcs-dc-dcs-bb-dcs-ec:hover{opacity:0.87}.dcs-a-dcs-db-dcs-ld-dcs-md .dcs-cc-dcs-dc-dcs-bb-dcs-kh-dcs-fh,.dcs-a-dcs-db-dcs-ld-dcs-md .dcs-cc-dcs-dc-dcs-bb-dcs-ud-dcs-fh{border-style:none;padding:0}.dcs-a-dcs-dg-dcs-bb{padding:0px 4px 0px 4px;min-width:20px;background-color:rgba(245,245,245,0.2);border-color:rgba(0,0,0,0.01880392);background-image:-moz-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:-ms-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:-o-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:-webkit-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2))}.dcs-a-dcs-cb:hover .dcs-a-dcs-dg-dcs-bb,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-dg-dcs-bb,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-dg-dcs-bb{background-color:rgba(245,245,245,0.7);border-color:rgba(0,0,0,0.0686274);background-image:-webkit-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:-moz-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:-ms-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:-o-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7))}.dcs-a-dcs-dg-dcs-bb.dcs-f-dcs-bb-dcs-le{border:1px solid rgba(198,198,198,0.7)!important}.dcs-a-dcs-dg-dcs-bb .dcs-f-dcs-bb-dcs-ye{margin-top:0px}.dcs-a-dcs-dg-dcs-bb .dcs-a-dcs-hb{opacity:0.2}.dcs-a-dcs-cb:hover .dcs-a-dcs-hb,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-hb,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-hb{opacity:0.6}.dcs-zc-dcs-ad-dcs-bd-dcs-cd-dcs-dd-dcs-ed-dcs-fd,.dcs-f-dcs-bb-dcs-le .dcs-a-dcs-hb,.dcs-dd-dcs-ed-dcs-ad-dcs-sj-dcs-fd{opacity:1!important}.dcs-dg-dcs-bb-dcs-l{font-size:12px;display:inline-block;vertical-align:middle;color:rgb(51,51,51);opacity:1;margin-left:2px;font-weight:normal}.dcs-dg-dcs-bb-dcs-l.dcs-cd-dcs-bd{display:none}.dcs-a-dcs-o{height:100px;overflow:hidden;position:relative}.dcs-a-dcs-pj-dcs-o{height:28px;left:50%;margin-left:sub(0,divide(28px,2));position:absolute;top:divide(sub(100px,28px),2);width:28px}.dcs-a-dcs-sg-dcs-ff-dcs-hb{display:inline-block;vertical-align:middle;margin:4px 5px 5px 2px}.dcs-a-dcs-sg-dcs-ff{text-align:left}.dcs-a-dcs-sg-dcs-ff-dcs-l{display:inline-block;height:17px}.dcs-a-dcs-sg-dcs-ff-dcs-ni{visibility:hidden}.dcs-a-dcs-bg-dcs-c{width:500px}.dcs-a-dcs-bg-dcs-af{padding:0 3px 0 8px}.dcs-a-dcs-bg-dcs-jc{padding-left:3px;margin-bottom:12px}.dcs-a-dcs-bg-dcs-cg{font-weight:bold;margin-bottom:12px}.dcs-a-dcs-bg-dcs-fg{position:absolute;right:20px}.dcs-a-dcs-xi-dcs-kh{display:inline-block}.dcs-a-dcs-xi-dcs-kh>.dcs-a-dcs-wg-dcs-ec{border:1px solid transparent;width:14px;height:28px;margin:auto;position:relative;left:-1px;opacity:0.2}.dcs-a-dcs-xi-dcs-kh>.dcs-a-dcs-wg-dcs-ec:hover,.dcs-a-dcs-xi-dcs-kh>.dcs-a-dcs-wg-dcs-ec:focus{border:1px solid #4d90fe;border-top-left-radius:0;border-bottom-left-radius:0}.dcs-a-dcs-xi-dcs-kh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ud-dcs-fh,.dcs-a-dcs-xi-dcs-kh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-kh-dcs-fh{min-width:14px;margin:0;padding:0}.dcs-a-dcs-xi-dcs-kh .dcs-a-dcs-hb{vertical-align:middle;opacity:0.7}.dcs-a-dcs-xi-dcs-kh .dcs-cc-dcs-qk-dcs-dc-dcs-bb-dcs-ec{display:none}.dcs-a-dcs-xi .dcs-cc-dcs-hf{padding-right:15px;padding-left:15px}.dcs-a-dcs-pj-dcs-o.dcs-gb{-webkit-animation:container-rotate 1568ms linear infinite;animation:container-rotate 1568ms linear infinite}@-webkit-keyframes container-rotate{to{-webkit-transform:rotate(360deg)}}@keyframes container-rotate{to{transform:rotate(360deg)}}.dcs-o-dcs-ci{position:absolute;width:100%;height:100%;opacity:0}.dcs-o-dcs-nd{border-color:#4285f4}.dcs-o-dcs-yg{border-color:#db4437}.dcs-o-dcs-zf{border-color:#f4b400}.dcs-o-dcs-p{border-color:#0f9d58}.dcs-gb .dcs-o-dcs-ci.dcs-o-dcs-nd{-webkit-animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,blue-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both;animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,blue-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both}.dcs-gb .dcs-o-dcs-ci.dcs-o-dcs-yg{-webkit-animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,red-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both;animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,red-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both}.dcs-gb .dcs-o-dcs-ci.dcs-o-dcs-zf{-webkit-animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,yellow-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both;animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,yellow-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both}.dcs-gb .dcs-o-dcs-ci.dcs-o-dcs-p{-webkit-animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,green-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both;animation:fill-unfill-rotate 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both,green-fade-in-out 5332ms cubic-bezier(0.4,0.0,0.2,1) infinite both}@-webkit-keyframes fill-unfill-rotate{12.5%{-webkit-transform:rotate(135deg)}25%{-webkit-transform:rotate(270deg)}37.5%{-webkit-transform:rotate(405deg)}50%{-webkit-transform:rotate(540deg)}62.5%{-webkit-transform:rotate(675deg)}75%{-webkit-transform:rotate(810deg)}87.5%{-webkit-transform:rotate(945deg)}to{-webkit-transform:rotate(1080deg)}}@keyframes fill-unfill-rotate{12.5%{transform:rotate(135deg)}25%{transform:rotate(270deg)}37.5%{transform:rotate(405deg)}50%{transform:rotate(540deg)}62.5%{transform:rotate(675deg)}75%{transform:rotate(810deg)}87.5%{transform:rotate(945deg)}to{transform:rotate(1080deg)}}@-webkit-keyframes blue-fade-in-out{from{opacity:1}25%{opacity:1}26%{opacity:0}89%{opacity:0}90%{opacity:1}100%{opacity:1}}@keyframes blue-fade-in-out{from{opacity:1}25%{opacity:1}26%{opacity:0}89%{opacity:0}90%{opacity:1}100%{opacity:1}}@-webkit-keyframes red-fade-in-out{from{opacity:0}15%{opacity:0}25%{opacity:1}50%{opacity:1}51%{opacity:0}}@keyframes red-fade-in-out{from{opacity:0}15%{opacity:0}25%{opacity:1}50%{opacity:1}51%{opacity:0}}@-webkit-keyframes yellow-fade-in-out{from{opacity:0}40%{opacity:0}50%{opacity:1}75%{opacity:1}76%{opacity:0}}@keyframes yellow-fade-in-out{from{opacity:0}40%{opacity:0}50%{opacity:1}75%{opacity:1}76%{opacity:0}}@-webkit-keyframes green-fade-in-out{from{opacity:0}65%{opacity:0}75%{opacity:1}90%{opacity:1}100%{opacity:0}}@keyframes green-fade-in-out{from{opacity:0}65%{opacity:0}75%{opacity:1}90%{opacity:1}100%{opacity:0}}.dcs-o-dcs-ek-dcs-fk{position:absolute;box-sizing:border-box;top:0;left:45%;width:10%;height:100%;overflow:hidden;border-color:inherit}.dcs-o-dcs-ek-dcs-fk .dcs-o-dcs-kg{width:1000%;left:-450%}.dcs-o-dcs-kg-dcs-mh{display:inline-block;position:relative;width:50%;height:100%;overflow:hidden;border-color:inherit}.dcs-o-dcs-kg-dcs-mh .dcs-o-dcs-kg{width:200%}.dcs-o-dcs-kg{box-sizing:border-box;height:100%;border-width:3px;border-style:solid;border-color:inherit;border-bottom-color:transparent!important;border-radius:50%;-webkit-animation:none;animation:none}.dcs-o-dcs-kg-dcs-mh.dcs-o-dcs-u .dcs-o-dcs-kg{border-right-color:transparent!important;-webkit-transform:rotate(129deg);transform:rotate(129deg)}.dcs-o-dcs-kg-dcs-mh.dcs-o-dcs-ph .dcs-o-dcs-kg{left:-100%;border-left-color:transparent!important;-webkit-transform:rotate(-129deg);transform:rotate(-129deg)}.dcs-gb .dcs-o-dcs-kg-dcs-mh.dcs-o-dcs-u .dcs-o-dcs-kg{-webkit-animation:left-spin 1333ms cubic-bezier(0.4,0.0,0.2,1) infinite both;animation:left-spin 1333ms cubic-bezier(0.4,0.0,0.2,1) infinite both}.dcs-gb .dcs-o-dcs-kg-dcs-mh.dcs-o-dcs-ph .dcs-o-dcs-kg{-webkit-animation:right-spin 1333ms cubic-bezier(0.4,0.0,0.2,1) infinite both;animation:right-spin 1333ms cubic-bezier(0.4,0.0,0.2,1) infinite both}@-webkit-keyframes left-spin{from{-webkit-transform:rotate(130deg)}50%{-webkit-transform:rotate(-5deg)}to{-webkit-transform:rotate(130deg)}}@keyframes left-spin{from{transform:rotate(130deg)}50%{transform:rotate(-5deg)}to{transform:rotate(130deg)}}@-webkit-keyframes right-spin{from{-webkit-transform:rotate(-130deg)}50%{-webkit-transform:rotate(5deg)}to{-webkit-transform:rotate(-130deg)}}@keyframes right-spin{from{transform:rotate(-130deg)}50%{transform:rotate(5deg)}to{transform:rotate(-130deg)}}.dcs-o-dcs-gf{position:absolute;top:0;bottom:0;right:0;left:0}.dcs-a-dcs-qc .dcs-h-dcs-xg-dcs-qc{display:none!important}.dcs-zh-dcs-xg-dcs-qc{display:none}.dcs-a-dcs-qc .dcs-zh-dcs-xg-dcs-qc{display:inline-block!important}.dcs-a-dcs-ab-dcs-ne{border:1px solid rgba(0,0,0,0.2)}.dcs-a-dcs-ab-dcs-ae{-webkit-transition:all 270ms ease-out;-moz-transition:all 270ms ease-out;-o-transition:all 270ms ease-out;transition:all 270ms ease-out;-webkit-transform:scale(0.3);-moz-transform:scale(0.3);-o-transform:scale(0.3);transform:scale(0.3);-webkit-transform-origin:center top;-moz-transform-origin:center top;-o-transform-origin:center top;transform-origin:center top;opacity:0.3}#docos-shadow-wrapper{position:relative}#docos-shadow{background:#000;background:rgba(0,0,0,0.7);color:#fff;position:absolute;z-index:700;left:0;top:0}#docos-shadow,.dcs-a-dcs-zb-dcs-me{height:100%;width:100%}#docos-shadow-description{font-weight:bold}#docos-shadow-confirm,#docos-shadow-delete{margin:2px 7px}.dcs-a-dcs-ub{min-height:36px}.dcs-a-dcs-ub-dcs-de{padding:8px;background:#f2f2f2}.dcs-a-dcs-ub .dcs-a-dcs-hb-dcs-ee-dcs-de{display:inline-block;padding:3px 2px 0px 2px;width:20px;height:20px;opacity:.54}.dcs-a-dcs-ub-dcs-cg{height:38px}.dcs-a-dcs-ub-dcs-cg table{border-spacing:0}.dcs-a-dcs-ub-dcs-he{padding-left:8px;width:100%;vertical-align:top}.dcs-a-dcs-ub-dcs-he-dcs-kh{position:relative}.dcs-a-dcs-ub-dcs-he-dcs-ud{position:absolute;padding-top:4px;width:100%;color:#616161;font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dcs-a-dcs-ub-dcs-pe{color:#333;padding-bottom:4px;word-wrap:break-word}.dcs-a-dcs-ub-dcs-oi-dcs-de{display:inline-block;margin-top:8px}.dcs-a-dcs-ub-dcs-oi-dcs-bb{color:#616161;font-size:12px}.dcs-a-dcs-ub-dcs-oi-dcs-bb:hover,.dcs-a-dcs-ub-dcs-oi-dcs-bb:focus{text-decoration:underline;cursor:pointer;outline:none}.dcs-a-dcs-ub-dcs-vb{padding:13px 8px 10px 8px;border-top:1px solid #ddd;background-color:#fff}.dcs-a-dcs-ub-dcs-vb-dcs-he{color:#333;font-weight:bold}.dcs-a-dcs-ub-dcs-vb-dcs-vc{margin:7px 0 7px 0}.dcs-a-dcs-ub-dcs-vb-dcs-fb-dcs-de{margin:4px 0 3px 0}.dcs-a-dcs-ub-dcs-vb-dcs-fb-dcs-de label{cursor:pointer}.dcs-a-dcs-ub-dcs-vb-dcs-fb-dcs-de .dcs-f-dcs-fb{border:1px solid rgba(0,0,0,.54);cursor:pointer}.dcs-a-dcs-ub-dcs-vb-dcs-fb-dcs-de .dcs-f-dcs-fb-dcs-gh{border:1px solid #4d90fe}.dcs-a-dcs-ub-dcs-vb-dcs-fb-dcs-de .dcs-f-dcs-fb-dcs-le{border:1px solid #333}.dcs-a-dcs-ub-dcs-vb-dcs-fb-dcs-de .dcs-f-dcs-fb-dcs-bh{border:1px solid rgba(0,0,0,.54)}.dcs-a-dcs-ub-dcs-vb-dcs-fb{margin:0 8px 0 4px}.dcs-a-dcs-ub-dcs-vb-dcs-l{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#333;display:inline-block;vertical-align:middle}.dcs-a-dcs-ub-dcs-tj-dcs-pd{margin:2px 0 5px 0;color:#4285f4;cursor:pointer}.dcs-a-dcs-tf-dcs-uf .dcs-a-dcs-cb .dcs-a-dcs-cb-dcs-td-dcs-ud.dcs-a-dcs-ub-dcs-td-dcs-ud{border-right:18px solid #f2f2f2}.dcs-a-dcs-b .dcs-a-dcs-db-dcs-uh{padding-bottom:6px}.dcs-a-dcs-b .dcs-a-dcs-db-dcs-zc{margin:0 4px 0 0}.dcs-a-dcs-b .dcs-a-dcs-db-dcs-zd{background:none}.dcs-a-dcs-lb{border-top:1px solid #e8e8e8;font-family:Arial,sans-serif;font-size:12px;padding:18px 0 7px 0;position:relative;outline:none;zoom:1}.dcs-a-dcs-lb:last-child{padding-bottom:0}.dcs-a-dcs-lb:last-child .dcs-a-dcs-lb-dcs-ik{padding-bottom:0}.dcs-a-dcs-lb .dcs-a-dcs-q-dcs-lj{min-height:48px}.dcs-a-dcs-ak{margin-right:12px;min-height:51px;padding:0 6px;position:relative;top:-3px}.dcs-a-dcs-q-dcs-r .dcs-a-dcs-ak{background-color:#f6f6f6}.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-ak{background-color:#fffbe1}.dcs-a-dcs-lb-dcs-c{margin-left:60px;position:relative}.dcs-a-dcs-lb-dcs-yb{font-weight:bold}.dcs-a-dcs-lb-dcs-pe{color:#333;word-wrap:break-word;top:-7px;zoom:1}.dcs-a-dcs-lb-dcs-mf,.dcs-a-dcs-lb-dcs-wc-dcs-xc{font-size:11px;color:#999;padding:0}.dcs-a-dcs-lb-dcs-mf,.dcs-a-dcs-lb-dcs-ic-dcs-jc{right:2px}.dcs-a-dcs-lb-dcs-mb{color:#ccc;font-size:12px;line-height:100%;padding:0 2px}.dcs-a-dcs-lb-dcs-ik{padding:4px 0}.dcs-a-dcs-lb-dcs-mf:hover{text-decoration:underline;cursor:pointer}.dcs-a-dcs-lb-dcs-db-dcs-eb{padding-right:6px;margin-left:30px}.dcs-a-dcs-lb-dcs-db-dcs-eb .dcs-a-dcs-db-dcs-te{background-color:#fff;border:1px solid #c9d4ec;height:23px;font-size:12px}.dcs-a-dcs-lb-dcs-db-dcs-eb.dcs-a-dcs-db-dcs-og .dcs-a-dcs-db-dcs-te{background-color:#fff}.dcs-a-dcs-lb-dcs-bc-dcs-eb .dcs-a-dcs-db-dcs-te{height:36px}.dcs-a-dcs-lb-dcs-ok,.dcs-a-dcs-lb-dcs-bi{margin:4px 12px 3px 0}.dcs-a-dcs-lb-dcs-ok{background-color:#eff2f9;-moz-border-radius:0 0 6px 6px;-webkit-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px;padding:6px 0 2px 6px;position:relative;zoom:1}.dcs-a-dcs-q-dcs-r .dcs-a-dcs-lb-dcs-ok{background-color:#f6f6f6}.dcs-a-dcs-lb-dcs-uj{position:absolute;right:0;top:0}.dcs-a-dcs-lb.dcs-a-dcs-q-dcs-r .dcs-a-dcs-lb-dcs-uj{right:4px}.dcs-a-dcs-lb .dcs-a-dcs-jh-dcs-kh{position:absolute;right:-12px;top:3px}.dcs-a-dcs-lb-dcs-ic-dcs-jc{display:inline}.dcs-a-dcs-lb-dcs-ic-dcs-jc>.dcs-a-dcs-q-dcs-ic{font-size:11px;color:#15c}.dcs-a-dcs-lb-dcs-lc-dcs-jc>.dcs-a-dcs-q-dcs-lc,.dcs-a-dcs-lb-dcs-ab-dcs-jc>.dcs-a-dcs-q-dcs-ab{color:#999;line-height:100%}.dcs-a-dcs-lb-dcs-lc-dcs-jc>.dcs-a-dcs-q-dcs-lc:hover,.dcs-a-dcs-lb-dcs-ic-dcs-jc>.dcs-a-dcs-q-dcs-ic:hover,.dcs-a-dcs-lb-dcs-ab-dcs-jc>.dcs-a-dcs-q-dcs-ab:hover{text-decoration:underline;cursor:pointer}.dcs-a-dcs-ak:hover .dcs-a-dcs-q-dcs-lc,.dcs-a-dcs-ak:hover .dcs-a-dcs-q-dcs-ab,.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-q-dcs-lc,.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-q-dcs-ab{color:#15c}.dcs-a-dcs-b-dcs-de{line-height:140%;outline:none}.dcs-a-dcs-b-dcs-c{position:relative}.dcs-a-dcs-b-dcs-fj{color:#15c;cursor:pointer;font-size:12px;position:absolute;right:0;top:-3px}.dcs-a-dcs-b-dcs-fj:hover{text-decoration:underline}.dcs-a-dcs-xd .dcs-a-dcs-b-dcs-fj{color:#999;cursor:default}.dcs-a-dcs-xd .dcs-a-dcs-b-dcs-fj:hover{text-decoration:none}.dcs-a-dcs-b-dcs-fl{bottom:-10px;color:#15c;cursor:pointer;font-size:12px;padding-right:5px;padding-top:5px;position:absolute;right:5px;text-decoration:none}.dcs-a-dcs-xd .dcs-a-dcs-b-dcs-fl{display:none}.dcs-a-dcs-b-dcs-si{color:#333;padding:12px 0 12px 20px}.dcs-a-dcs-b-dcs-lg{margin:6px 29px 10px 20px;position:relative;zoom:1}.dcs-a-dcs-b-dcs-lg-dcs-c{margin-left:61px;position:relative;zoom:1}.dcs-a-dcs-b-dcs-yd{font-size:12px;font-weight:bold;margin-bottom:3px;top:-3px}.dcs-a-dcs-b-dcs-k{font-size:1.2em;margin:20px 5px 2px}.dcs-a-dcs-b-dcs-db-dcs-eb{top:-4px}.dcs-a-dcs-b-dcs-db-dcs-eb .dcs-a-dcs-db-dcs-zc{font-weight:bold}.dcs-a-dcs-b-dcs-db-dcs-eb .dcs-a-dcs-db-dcs-te{font-size:12px;height:30px}.dcs-a-dcs-lb-dcs-ok .dcs-a-dcs-db-dcs-ei-dcs-fi-dcs-if,.dcs-a-dcs-lb-dcs-ok .dcs-a-dcs-db-dcs-kk-dcs-lk-dcs-if,.dcs-a-dcs-lb-dcs-ok .dcs-a-dcs-db-dcs-ld-dcs-if,.dcs-a-dcs-lb-dcs-ok .dcs-a-dcs-db-dcs-qi-dcs-if{color:#777;line-height:normal;margin-top:8px}.dcs-a-dcs-b-dcs-qh{background-color:#dd4b39;border:1px solid #602019;border-radius:4px;color:#fff;margin:6px;padding:6px;text-align:center}.dcs-a-dcs-b-dcs-cg{overflow:hidden;padding:10px 29px 10px 20px;background-color:#f5f5f5}.dcs-a-dcs-b-dcs-cg .dcs-a-dcs-m-dcs-n,.dcs-a-dcs-b-dcs-cg .dcs-a-dcs-sd-dcs-lc-dcs-bb,.dcs-a-dcs-b-dcs-cg .dcs-a-dcs-vb-dcs-bb{display:inline-block;float:right}.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb,.dcs-a-dcs-b-dcs-cg .dcs-f-dcs-bb{border-color:transparent;background-color:transparent;background-image:none}.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le,.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gb,.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ui,.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gh,.dcs-a-dcs-b-dcs-cg .dcs-f-dcs-bb-dcs-le,.dcs-a-dcs-b-dcs-cg .dcs-f-dcs-bb-dcs-gb,.dcs-a-dcs-b-dcs-cg .dcs-f-dcs-bb-dcs-gh{border-color:#c6c6c6;background-color:#f8f8f8;background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-moz-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-ms-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);background-image:linear-gradient(top,#f8f8f8,#f1f1f1)}.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec{visibility:hidden}.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-le .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec,.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gb .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec,.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ui .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec,.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-gh .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-ec{visibility:visible}.dcs-a-dcs-b-dcs-cg .dcs-cc-dcs-cf-dcs-dc-dcs-bb-dcs-bf .dcs-a-dcs-sg-dcs-ff-dcs-hb{opacity:0.3}.dcs-a-dcs-b-dcs-cg .dcs-f-dcs-bb-dcs-bf .dcs-a-dcs-sd-dcs-lc-dcs-hb{opacity:0.15}.dcs-a-dcs-b-dcs-cg .dcs-a-dcs-sd-dcs-lc-dcs-bb,.dcs-a-dcs-b-dcs-cg .dcs-a-dcs-vb-dcs-bb{margin-left:12px;margin-right:0}.dcs-a-dcs-mg-dcs-ng{padding:0 29px 0 20px}.dcs-a-dcs-xh-dcs-d-dcs-cg .dcs-a-dcs-mg-dcs-ng{position:relative;overflow:auto;max-height:450px}.dcs-a-dcs-xh-dcs-d-dcs-cg .dcs-a-dcs-mg-dcs-ng>.dcs-a-dcs-lb:first-child{border-top-color:transparent}.dcs-a-dcs-sd-dcs-lc-dcs-hb{display:inline-block;vertical-align:middle;margin:4px 5px 5px 2px;opacity:0.65}.dcs-a-dcs-fc{background-color:#eff2f9;color:#666;font-size:12px;padding:6px 6px 0 6px;position:relative;margin-bottom:3px;min-height:24px}.dcs-a-dcs-q-dcs-r .dcs-a-dcs-fc{background-color:#f6f6f6}.dcs-a-dcs-fc-dcs-yc{left:6px}.dcs-a-dcs-fc-dcs-c{padding-left:30px}.dcs-a-dcs-fc-dcs-kd{color:black;font-weight:bold;left:-2px;margin:0 4px;right:-2px}.dcs-a-dcs-fc-dcs-pe{color:#333;margin:0;top:-4px;width:100%;word-wrap:break-word}.dcs-a-dcs-fc-dcs-l,.dcs-a-dcs-fc-dcs-mf{position:relative;top:-3px}.dcs-a-dcs-fc-dcs-l{width:100%}.dcs-a-dcs-fc-dcs-zg{padding-bottom:4px;font-style:italic}.dcs-a-dcs-fc-dcs-zg,.dcs-a-dcs-fc-dcs-mf{color:#999;font-size:11px;white-space:pre}.dcs-a-dcs-lb .dcs-a-dcs-fc .dcs-a-dcs-z-dcs-jc{display:inline;top:-3px;z-index:-1}.dcs-a-dcs-lb .dcs-a-dcs-fc:hover .dcs-a-dcs-z-dcs-jc,.dcs-a-dcs-lb .dcs-a-dcs-fc .dcs-a-dcs-z-dcs-jc-dcs-gh{z-index:auto}.dcs-a-dcs-fc-dcs-bc-dcs-eb .dcs-a-dcs-db-dcs-te{height:23px}.dcs-a-dcs-lb .dcs-a-dcs-z-dcs-eg{border-left:1px solid #ccc;font-style:italic;padding:3px 10px 3px 10px;position:relative;zoom:1;word-wrap:break-word}.dcs-a-dcs-z-dcs-eg-dcs-ff{font-size:11px;color:#999;margin-right:2px;padding:0}.dcs-a-dcs-z-dcs-eg-dcs-eh{overflow:hidden;height:18px}.dcs-a-dcs-z-dcs-eg-dcs-bk{background:#fff;padding:3px 5px 0 5px;position:absolute;right:0;top:0}.dcs-a-dcs-z-dcs-eg-dcs-ah,.dcs-a-dcs-z-dcs-eg-dcs-bk{color:#15c;visibility:hidden}.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-z-dcs-eg-dcs-ah,.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-z-dcs-eg-dcs-bk{visibility:visible}.dcs-a-dcs-z-dcs-eg-dcs-ah{padding-left:3px}.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-z-dcs-eg-dcs-bk{background:#fffbe1}.dcs-a-dcs-z-dcs-eg-dcs-ah:hover,.dcs-a-dcs-z-dcs-eg-dcs-bk:hover{cursor:pointer;text-decoration:underline}.dcs-a-dcs-ak .dcs-a-dcs-ue-dcs-l,.dcs-a-dcs-fc .dcs-a-dcs-ue-dcs-l{color:#777;font-style:italic;word-wrap:break-word;-ms-word-wrap:break-word;overflow-wrap:break-word}.dcs-a-dcs-ak .dcs-a-dcs-ue-dcs-l{display:inline-block}.dcs-a-dcs-lb-dcs-c .dcs-a-dcs-db-dcs-ld-dcs-md{margin-top:-5px}.dcs-a-dcs-te{margin:0;padding:2px;font-family:arial,sans-serif;outline-width:0!important;resize:none}.dcs-a-dcs-z-dcs-pc,.dcs-a-dcs-z-dcs-bc{color:#15c;font-size:11px;margin:0 2px}.dcs-a-dcs-z-dcs-pc:hover,.dcs-a-dcs-z-dcs-bc:hover{text-decoration:underline;cursor:pointer}.dcs-a-dcs-db-dcs-zd{margin:0 0}.dcs-a-dcs-db-dcs-zc{margin:8px 7px 0 0}.dcs-a-dcs-hi-dcs-fi-dcs-ue-dcs-l-dcs-we{padding:8px 0 0 0;position:relative}.dcs-a-dcs-w-dcs-bj .dcs-f-dcs-fb{-ms-high-contrast-adjust:none!important;background-color:white!important}.dcs-a-dcs-fd-dcs-bb{font-size:14px;min-width:38px;background-color:rgba(245,245,245,0.2);border-color:rgba(0,0,0,0.01880392);background-image:-moz-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:-ms-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:-o-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2));background-image:-webkit-linear-gradient(top,rgba(245,245,245,0.2),rgba(241,241,241,0.2))}.dcs-a-dcs-cb:hover .dcs-a-dcs-fd-dcs-bb,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-a-dcs-fd-dcs-bb,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-a-dcs-fd-dcs-bb{background-color:rgba(245,245,245,0.7);border-color:rgba(0,0,0,0.0686274);background-image:-webkit-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:-moz-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:-ms-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:-o-linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7));background-image:linear-gradient(top,rgba(245,245,245,0.7),rgba(241,241,241,0.7))}.dcs-a-dcs-fd-dcs-bb.dcs-f-dcs-bb-dcs-le{border:1px solid rgba(198,198,198,0.7)!important}.dcs-fd-dcs-bb-dcs-l{color:rgb(51,51,51);opacity:0.2}.dcs-a-dcs-cb:hover .dcs-fd-dcs-bb-dcs-l,.dcs-a-dcs-cb.dcs-a-dcs-q-dcs-gb .dcs-fd-dcs-bb-dcs-l,.dcs-a-dcs-cb.dcs-a-dcs-wg-dcs-qe .dcs-fd-dcs-bb-dcs-l{opacity:0.6}.dcs-zc-dcs-ad-dcs-bd-dcs-cd-dcs-dd-dcs-ed-dcs-fd,.dcs-f-dcs-bb-dcs-le .dcs-fd-dcs-bb-dcs-l,.dcs-dd-dcs-ed-dcs-ad-dcs-sj-dcs-fd{opacity:1!important}.dcs-fd-dcs-bb-dcs-l.dcs-dd-dcs-ed-dcs-ad-dcs-sj-dcs-fd{color:#0f9d58}
</style></head><body class="drive-viewer-fixed-frame" dir="ltr" role="application" itemscope="" itemtype="http://schema.org/CreativeWork/DocumentObject"><iframe aria-hidden="true" tabindex="-1" style="position: absolute; width: 9em; height: 9em; top: -99em;"></iframe>
       <script aria-hidden="true">
         document.addEventListener('DOMContentLoaded', function () {
           document.body.onload = _onProjectorLoad;
           document.body.onunload = _disposeProjector;
         });
       </script>
    <div aria-hidden="true" style="display:none"></div><meta aria-hidden="true" itemprop="name" content="jspdf.js"><meta aria-hidden="true" itemprop="faviconUrl" content="https://ssl.gstatic.com/docs/doclist/images/icon_14_text_favicon.ico"><meta aria-hidden="true" itemprop="url" content="https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view?usp=embed_googleplus"><meta aria-hidden="true" itemprop="embedURL" content="https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/preview?usp=embed_googleplus"><script aria-hidden="true" type="text/javascript" src="jspdf.js%20-%20Google%20Drive_files/2652796335-projector_viewer__es.js"></script>
<script aria-hidden="true">_initProjector({'id': '0BwHqLHKAfVJeUGVDRmw1aWZCQUk', 'title': 'jspdf.js','enableStandaloneSharing': true,'enableEmbedDialog': true,'projectorFeedbackId': '99950', 'projectorFeedbackBucket': 'viewer-web',},["0",1,"",1,1,1,1,"","",1,1,[1,"",0,"AIzaSyDVQw45DwoYh632gvsP5vPDqEKvb-Ywnb8",0,0,1,0,null,"AIzaSyC1eQ1xj69IdTMeii5r7brs3R90eck-m7k",0,"/drive/v2internal",1,1,1,[0,0,0,"",""]
,0,1,"/drive/v2internal"]
,1,5,1,"",0,1,"https://drive.google.com",0,1,1,1,1,null,1,"20",1,0,1,1,1,[["","0"]
,6,1,1,"ND",""]
,1,1,1,null,[0,"Jose Antonio Albalat","proyectojosealbalat@gmail.com","//ssl.gstatic.com/docs/common/profile/J.png","","","","",1]
,0,1,1,"600000",null,"https://docs.google.com",0,1,[0,0,0,1]
,["https://youtube.googleapis.com",1,2]
,1,1,"",0,1,1,1,1,[1,"",null,null,"lmjegmlicamnimmfhcmpkclmigmmcbeh",1,1,3000,"proyectojosealbalat@gmail.com",null,0,0,0]
,null,"000770F203FE0E1F4AF949F2AAF6F9F6AFA3D1D80CC2746532::1526215779010",null,[1,1,1,1]
,null,1,0,3,0,1,[1,"https://maps.googleapis.com/maps/api/js?key\u003dAIzaSyBCjpnguVjzi6vS67NdBtyYuvCYz3yBxCY\u0026sensor\u003dfalse"]
,0,1,["AIzaSyCMp6sr4oTC18AWkE2Ii4UBZHTHEpGZWZM","https://blobcomments-pa.clients6.google.com","/v1",1,1,1,1,1]
,null,1,1,0,1,null,0,0,0,null,1,[1,1,1]
,0,null,0,0,null,1,1,0,0,1,0,[0,0]
,0]
,[null,"jspdf.js","https://lh3.googleusercontent.com/ntMWUWQcMR4o8J0Lr-PW-SmzS0_c7BKsmo4iv_JHWBj69gXeWkB-2NLgtE58hrYjhHMZIsdWdVb987I\u003dw1600","","","","0BwHqLHKAfVJeUGVDRmw1aWZCQUk","","","https://drive.google.com/viewerng/upload?ds\u003dAPznzaYyAvfCMw3ZdEEpJM_I00NG2ELua_bQjo_3zWFfglc9G_UH4a0mzSpxij7ZcXqFXAhm6Qpf47T24IymaDnwvAGSosnxP8Q9AtuvBy11DXJgmlqs6x5VE6oq8hMnpFPWn-y-b0qKKsJpURN_YuBCSw3RD-qaSaVNCUWb7-Mp9DGz2PbgRACaFDEHyEW1A3niTpnqrYLuMymilWSW1OjvqoMfwL2iWQYABXzU8EqIDxgcNs4qyHA%3D\u0026ck\u003ddrive\u0026authuser\u003d0\u0026p\u003dproj","","application/javascript","","",6,"","https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view",1,"https://drive.google.com/uc?authuser\u003d0\u0026id\u003d0BwHqLHKAfVJeUGVDRmw1aWZCQUk\u0026export\u003ddownload",null,5,0,0,"","",[null,0,"321567"]
,"","",null,0,"",0,"js","",[["0BwHqLHKAfVJec3ppamhzS1FGNVhqREFCcEVPY0ZoVVZ6eEZ3PQ"]
]
,"",null,"",null,null,null,0]
);</script><div tabindex="0" class="drive-viewer drive-viewer-focus-outlines-disabled drive-viewer-quantum-spinner drive-viewer-v3 drive-viewer-shown" aria-label="Se está mostrando el lector."><div aria-label="Mostrando jspdf.js." class="drive-viewer-shadow drive-viewer-default" tabindex="0"></div><div style="bottom: 0px;" class="drive-viewer-carousel"><div data-tooltip-offset="-6" data-tooltip-align="r,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" aria-disabled="true" style="-moz-user-select: none; left: 11px; opacity: 1;" role="button" class="drive-viewer-prev-button drive-viewer-button-disabled drive-viewer-button"><div class="drive-viewer-nav-background"><div class="drive-viewer-icon drive-viewer-nav-icon"></div></div></div><div data-tooltip-offset="-6" data-tooltip-align="l,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" aria-disabled="true" style="-moz-user-select: none; right: 11px; opacity: 1;" role="button" class="drive-viewer-next-button drive-viewer-button-disabled drive-viewer-button"><div class="drive-viewer-nav-background"><div class="drive-viewer-icon drive-viewer-nav-icon"></div></div></div><div style="opacity: 1;" class="drive-viewer-toolchest"><div style="display: none;" class="drive-viewer-page-count-v3"></div><div style="display: none;" class="drive-viewer-zoom-controls-v3"><div data-tooltip="Reducir" aria-label="Reducir" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" tabindex="0" style="-moz-user-select: none;" role="button" class="drive-viewer-dark-button drive-viewer-zoom-out-button goog-inline-block drive-viewer-button"><div class="drive-viewer-icon"></div></div><div data-tooltip="Restablecer zoom" aria-label="Restablecer zoom" aria-disabled="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none;" role="button" class="drive-viewer-button drive-viewer-dark-button drive-viewer-zoom-fit-button goog-inline-block drive-viewer-button-disabled drive-viewer-zoom-reset"><div class="drive-viewer-icon"></div></div><div data-tooltip="Ampliar" aria-label="Ampliar" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" tabindex="0" style="-moz-user-select: none;" role="button" class="drive-viewer-button drive-viewer-dark-button drive-viewer-zoom-in-button goog-inline-block"><div class="drive-viewer-icon"></div></div></div><div style="display: none;" class="drive-viewer-licensebar"></div></div><div style="" class="drive-viewer-carousel-slide drive-viewer-close-enabled" role="main"><div style="display: none;" class="drive-viewer-msg-loading drive-viewer-carousel-loading-message" role="status" tabindex="-1" aria-label="Cargando"><div class="drive-viewer-msg-loading-img drive-viewer-focus-to-default"><div class="drive-spinner"><div class="drive-quantum-spinner active"><div class="spinner-layer spinner-blue"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-red"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-yellow"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-green"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div></div></div></div><span class="drive-viewer-msg-loading-text drive-viewer-focus-to-default" aria-hidden="true">Cargando…</span></div><div style="" class="drive-viewer-itemview "><div class="drive-viewer-text-container"><div class="drive-viewer-text-scrollable drive-viewer-scrollable"><div dir="ltr" style="left: 1298.9px; top: 56px; text-align: left;" class="drive-viewer-docos-stream"><div class="dcs-a-dcs-qc dcs-a dcs-a-dcs-mg-dcs-ng dcs-a-dcs-tf-dcs-hg dcs-a-dcs-tf-dcs-uf"></div></div><div class="drive-viewer-text"><div style="height: 131849px;" class="drive-viewer-text-area drive-viewer-close-enabled"><div style="left: 154.1px; top: 56px;" class="drive-viewer-text-panel drive-viewer-layout-transition"><div dir="ltr" style="width: 1107px; height: auto; text-align: left;" tabindex="0" class="drive-viewer-text-content" role="document" aria-label="Mostrando jspdf.js"><pre class="drive-viewer-text-page">/** @preserve
 * jsPDF - PDF Document creation from JavaScript
 * Version 1.0.272-git Built on 2014-09-29T15:09
 *                           CommitID d4770725ca
 *
 * Copyright (c) 2010-2014 James Hall, https://github.com/MrRio/jsPDF
 *               2010 Aaron Spike, https://github.com/acspike
 *               2012 Willow Systems Corporation, willow-systems.com
 *               2012 Pablo Hess, https://github.com/pablohess
 *               2012 Florian Jenett, https://github.com/fjenett
 *               2013 Warren Weckesser, https://github.com/warrenweckesser
 *               2013 Youssef Beddad, https://github.com/lifof
 *               2013 Lee Driscoll, https://github.com/lsdriscoll
 *               2013 Stefan Slonevskiy, https://github.com/stefslon
 *               2013 Jeremy Morel, https://github.com/jmorel
 *               2013 Christoph Hartmann, https://github.com/chris-rock
 *               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
 *               2014 James Makes, https://github.com/dollaruw
 *               2014 Diego Casorran, https://github.com/diegocr
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Contributor(s):
 *    siefkenj, ahwolf, rickygu, Midnith, saintclair, eaparango,
 *    kim3er, mfo, alnorth,
 */

/**
 * Creates new jsPDF document object instance.
 *
 * @class
 * @param orientation One of "portrait" or "landscape" (or shortcuts "p" (Default), "l")
 * @param unit        Measurement unit to be used when coordinates are specified.
 *                    One of "pt" (points), "mm" (Default), "cm", "in"
 * @param format      One of 'pageFormats' as shown below, default: a4
 * @returns {jsPDF}
 * @name jsPDF
 */
var jsPDF = (function(global) {
	'use strict';
	var pdfVersion = '1.3',
		pageFormats = { // Size in pt of various paper formats
			'a0'  : [2383.94, 3370.39], 'a1'  : [1683.78, 2383.94],
			'a2'  : [1190.55, 1683.78], 'a3'  : [ 841.89, 1190.55],
			'a4'  : [ 595.28,  841.89], 'a5'  : [ 419.53,  595.28],
			'a6'  : [ 297.64,  419.53], 'a7'  : [ 209.76,  297.64],
			'a8'  : [ 147.40,  209.76], 'a9'  : [ 104.88,  147.40],
			'a10' : [  73.70,  104.88], 'b0'  : [2834.65, 4008.19],
			'b1'  : [2004.09, 2834.65], 'b2'  : [1417.32, 2004.09],
			'b3'  : [1000.63, 1417.32], 'b4'  : [ 708.66, 1000.63],
			'b5'  : [ 498.90,  708.66], 'b6'  : [ 354.33,  498.90],
			'b7'  : [ 249.45,  354.33], 'b8'  : [ 175.75,  249.45],
			'b9'  : [ 124.72,  175.75], 'b10' : [  87.87,  124.72],
			'c0'  : [2599.37, 3676.54], 'c1'  : [1836.85, 2599.37],
			'c2'  : [1298.27, 1836.85], 'c3'  : [ 918.43, 1298.27],
			'c4'  : [ 649.13,  918.43], 'c5'  : [ 459.21,  649.13],
			'c6'  : [ 323.15,  459.21], 'c7'  : [ 229.61,  323.15],
			'c8'  : [ 161.57,  229.61], 'c9'  : [ 113.39,  161.57],
			'c10' : [  79.37,  113.39], 'dl'  : [ 311.81,  623.62],
			'letter'            : [612,   792],
			'government-letter' : [576,   756],
			'legal'             : [612,  1008],
			'junior-legal'      : [576,   360],
			'ledger'            : [1224,  792],
			'tabloid'           : [792,  1224],
			'credit-card'       : [153,   243]
		};

	/**
	 * jsPDF's Internal PubSub Implementation.
	 * See mrrio.github.io/jsPDF/doc/symbols/PubSub.html
	 * Backward compatible rewritten on 2014 by
	 * Diego Casorran, https://github.com/diegocr
	 *
	 * @class
	 * @name PubSub
	 */
	function PubSub(context) {
		var topics = {};

		this.subscribe = function(topic, callback, once) {
			if(typeof callback !== 'function') {
				return false;
			}

			if(!topics.hasOwnProperty(topic)) {
				topics[topic] = {};
			}

			var id = Math.random().toString(35);
			topics[topic][id] = [callback,!!once];

			return id;
		};

		this.unsubscribe = function(token) {
			for(var topic in topics) {
				if(topics[topic][token]) {
					delete topics[topic][token];
					return true;
				}
			}
			return false;
		};

		this.publish = function(topic) {
			if(topics.hasOwnProperty(topic)) {
				var args = Array.prototype.slice.call(arguments, 1), idr = [];

				for(var id in topics[topic]) {
					var sub = topics[topic][id];
					try {
						sub[0].apply(context, args);
					} catch(ex) {
						if(global.console) {
							console.error('jsPDF PubSub Error', ex.message, ex);
						}
					}
					if(sub[1]) idr.push(id);
				}
				if(idr.length) idr.forEach(this.unsubscribe);
			}
		};
	}

	/**
	 * @constructor
	 * @private
	 */
	function jsPDF(orientation, unit, format, compressPdf) {
		var options = {};

		if (typeof orientation === 'object') {
			options = orientation;

			orientation = options.orientation;
			unit = options.unit || unit;
			format = options.format || format;
			compressPdf = options.compress || options.compressPdf || compressPdf;
		}

		// Default options
		unit        = unit || 'mm';
		format      = format || 'a4';
		orientation = ('' + (orientation || 'P')).toLowerCase();

		var format_as_string = ('' + format).toLowerCase(),
			compress = !!compressPdf &amp;&amp; typeof Uint8Array === 'function',
			textColor            = options.textColor  || '0 g',
			drawColor            = options.drawColor  || '0 G',
			activeFontSize       = options.fontSize   || 16,
			lineHeightProportion = options.lineHeight || 1.15,
			lineWidth            = options.lineWidth  || 0.200025, // 2mm
			objectNumber =  2,  // 'n' Current object number
			outToPages   = !1,  // switches where out() prints. outToPages true = push to pages obj. outToPages false = doc builder content
			offsets      = [],  // List of offsets. Activated and reset by buildDocument(). Pupulated by various calls buildDocument makes.
			fonts        = {},  // collection of font objects, where key is fontKey - a dynamically created label for a given font.
			fontmap      = {},  // mapping structure fontName &gt; fontStyle &gt; font key - performance layer. See addFont()
			activeFontKey,      // will be string representing the KEY of the font as combination of fontName + fontStyle
			k,                  // Scale factor
			tmp,
			page = 0,
			currentPage,
			pages = [],
			pagedim = {},
			content = [],
			lineCapID = 0,
			lineJoinID = 0,
			content_length = 0,
			pageWidth,
			pageHeight,
			pageMode,
			zoomMode,
			layoutMode,
			documentProperties = {
				'title'    : '',
				'subject'  : '',
				'author'   : '',
				'keywords' : '',
				'creator'  : ''
			},
			API = {},
			events = new PubSub(API),

		/////////////////////
		// Private functions
		/////////////////////
		f2 = function(number) {
			return number.toFixed(2); // Ie, %.2f
		},
		f3 = function(number) {
			return number.toFixed(3); // Ie, %.3f
		},
		padd2 = function(number) {
			return ('0' + parseInt(number)).slice(-2);
		},
		out = function(string) {
			if (outToPages) {
				/* set by beginPage */
				pages[currentPage].push(string);
			} else {
				// +1 for '\n' that will be used to join 'content'
				content_length += string.length + 1;
				content.push(string);
			}
		},
		newObject = function() {
			// Begin a new object
			objectNumber++;
			offsets[objectNumber] = content_length;
			out(objectNumber + ' 0 obj');
			return objectNumber;
		},
		putStream = function(str) {
			out('stream');
			out(str);
			out('endstream');
		},
		putPages = function() {
			var n,p,arr,i,deflater,adler32,adler32cs,wPt,hPt;

			adler32cs = global.adler32cs || jsPDF.adler32cs;
			if (compress &amp;&amp; typeof adler32cs === 'undefined') {
				compress = false;
			}

			// outToPages = false as set in endDocument(). out() writes to content.

			for (n = 1; n &lt;= page; n++) {
				newObject();
				wPt = (pageWidth = pagedim[n].width) * k;
				hPt = (pageHeight = pagedim[n].height) * k;
				out('&lt;&lt;/Type /Page');
				out('/Parent 1 0 R');
				out('/Resources 2 0 R');
				out('/MediaBox [0 0 ' + f2(wPt) + ' ' + f2(hPt) + ']');
				out('/Contents ' + (objectNumber + 1) + ' 0 R&gt;&gt;');
				out('endobj');

				// Page content
				p = pages[n].join('\n');
				newObject();
				if (compress) {
					arr = [];
					i = p.length;
					while(i--) {
						arr[i] = p.charCodeAt(i);
					}
					adler32 = adler32cs.from(p);
					deflater = new Deflater(6);
					deflater.append(new Uint8Array(arr));
					p = deflater.flush();
					arr = new Uint8Array(p.length + 6);
					arr.set(new Uint8Array([120, 156])),
					arr.set(p, 2);
					arr.set(new Uint8Array([adler32 &amp; 0xFF, (adler32 &gt;&gt; 8) &amp; 0xFF, (adler32 &gt;&gt; 16) &amp; 0xFF, (adler32 &gt;&gt; 24) &amp; 0xFF]), p.length+2);
					p = String.fromCharCode.apply(null, arr);
					out('&lt;&lt;/Length ' + p.length + ' /Filter [/FlateDecode]&gt;&gt;');
				} else {
					out('&lt;&lt;/Length ' + p.length + '&gt;&gt;');
				}
				putStream(p);
				out('endobj');
			}
			offsets[1] = content_length;
			out('1 0 obj');
			out('&lt;&lt;/Type /Pages');
			var kids = '/Kids [';
			for (i = 0; i &lt; page; i++) {
				kids += (3 + 2 * i) + ' 0 R ';
			}
			out(kids + ']');
			out('/Count ' + page);
			out('&gt;&gt;');
			out('endobj');
		},
		putFont = function(font) {
			font.objectNumber = newObject();
			out('&lt;&lt;/BaseFont/' + font.PostScriptName + '/Type/Font');
			if (typeof font.encoding === 'string') {
				out('/Encoding/' + font.encoding);
			}
			out('/Subtype/Type1&gt;&gt;');
			out('endobj');
		},
		putFonts = function() {
			for (var fontKey in fonts) {
				if (fonts.hasOwnProperty(fontKey)) {
					putFont(fonts[fontKey]);
				}
			}
		},
		putXobjectDict = function() {
			// Loop through images, or other data objects
			events.publish('putXobjectDict');
		},
		putResourceDictionary = function() {
			out('/ProcSet [/PDF /Text /ImageB /ImageC /ImageI]');
			out('/Font &lt;&lt;');

			// Do this for each font, the '1' bit is the index of the font
			for (var fontKey in fonts) {
				if (fonts.hasOwnProperty(fontKey)) {
					out('/' + fontKey + ' ' + fonts[fontKey].objectNumber + ' 0 R');
				}
			}
			out('&gt;&gt;');
			out('/XObject &lt;&lt;');
			putXobjectDict();
			out('&gt;&gt;');
		},
		putResources = function() {
			putFonts();
			events.publish('putResources');
			// Resource dictionary
			offsets[2] = content_length;
			out('2 0 obj');
			out('&lt;&lt;');
			putResourceDictionary();
			out('&gt;&gt;');
			out('endobj');
			events.publish('postPutResources');
		},
		addToFontDictionary = function(fontKey, fontName, fontStyle) {
			// this is mapping structure for quick font key lookup.
			// returns the KEY of the font (ex: "F1") for a given
			// pair of font name and type (ex: "Arial". "Italic")
			if (!fontmap.hasOwnProperty(fontName)) {
				fontmap[fontName] = {};
			}
			fontmap[fontName][fontStyle] = fontKey;
		},
		/**
		 * FontObject describes a particular font as member of an instnace of jsPDF
		 *
		 * It's a collection of properties like 'id' (to be used in PDF stream),
		 * 'fontName' (font's family name), 'fontStyle' (font's style variant label)
		 *
		 * @class
		 * @public
		 * @property id {String} PDF-document-instance-specific label assinged to the font.
		 * @property PostScriptName {String} PDF specification full name for the font
		 * @property encoding {Object} Encoding_name-to-Font_metrics_object mapping.
		 * @name FontObject
		 */
		addFont = function(PostScriptName, fontName, fontStyle, encoding) {
			var fontKey = 'F' + (Object.keys(fonts).length + 1).toString(10),
			// This is FontObject
			font = fonts[fontKey] = {
				'id'             : fontKey,
				'PostScriptName' : PostScriptName,
				'fontName'       : fontName,
				'fontStyle'      : fontStyle,
				'encoding'       : encoding,
				'metadata'       : {}
			};
			addToFontDictionary(fontKey, fontName, fontStyle);
			events.publish('addFont', font);

			return fontKey;
		},
		addFonts = function() {

			var HELVETICA     = "helvetica",
				TIMES         = "times",
				COURIER       = "courier",
				NORMAL        = "normal",
				BOLD          = "bold",
				ITALIC        = "italic",
				BOLD_ITALIC   = "bolditalic",
				encoding      = 'StandardEncoding',
				standardFonts = [
					['Helvetica', HELVETICA, NORMAL],
					['Helvetica-Bold', HELVETICA, BOLD],
					['Helvetica-Oblique', HELVETICA, ITALIC],
					['Helvetica-BoldOblique', HELVETICA, BOLD_ITALIC],
					['Courier', COURIER, NORMAL],
					['Courier-Bold', COURIER, BOLD],
					['Courier-Oblique', COURIER, ITALIC],
					['Courier-BoldOblique', COURIER, BOLD_ITALIC],
					['Times-Roman', TIMES, NORMAL],
					['Times-Bold', TIMES, BOLD],
					['Times-Italic', TIMES, ITALIC],
					['Times-BoldItalic', TIMES, BOLD_ITALIC]
				];

			for (var i = 0, l = standardFonts.length; i &lt; l; i++) {
				var fontKey = addFont(
						standardFonts[i][0],
						standardFonts[i][1],
						standardFonts[i][2],
						encoding);

				// adding aliases for standard fonts, this time matching the capitalization
				var parts = standardFonts[i][0].split('-');
				addToFontDictionary(fontKey, parts[0], parts[1] || '');
			}
			events.publish('addFonts', { fonts : fonts, dictionary : fontmap });
		},
		SAFE = function __safeCall(fn) {
			fn.foo = function __safeCallWrapper() {
				try {
					return fn.apply(this, arguments);
				} catch (e) {
					var stack = e.stack || '';
					if(~stack.indexOf(' at ')) stack = stack.split(" at ")[1];
					var m = "Error in function " + stack.split("\n")[0].split('&lt;')[0] + ": " + e.message;
					if(global.console) {
						global.console.error(m, e);
						if(global.alert) alert(m);
					} else {
						throw new Error(m);
					}
				}
			};
			fn.foo.bar = fn;
			return fn.foo;
		},
		to8bitStream = function(text, flags) {
		/**
		 * PDF 1.3 spec:
		 * "For text strings encoded in Unicode, the first two bytes must be 254 followed by
		 * 255, representing the Unicode byte order marker, U+FEFF. (This sequence conflicts
		 * with the PDFDocEncoding character sequence thorn ydieresis, which is unlikely
		 * to be a meaningful beginning of a word or phrase.) The remainder of the
		 * string consists of Unicode character codes, according to the UTF-16 encoding
		 * specified in the Unicode standard, version 2.0. Commonly used Unicode values
		 * are represented as 2 bytes per character, with the high-order byte appearing first
		 * in the string."
		 *
		 * In other words, if there are chars in a string with char code above 255, we
		 * recode the string to UCS2 BE - string doubles in length and BOM is prepended.
		 *
		 * HOWEVER!
		 * Actual *content* (body) text (as opposed to strings used in document properties etc)
		 * does NOT expect BOM. There, it is treated as a literal GID (Glyph ID)
		 *
		 * Because of Adobe's focus on "you subset your fonts!" you are not supposed to have
		 * a font that maps directly Unicode (UCS2 / UTF16BE) code to font GID, but you could
		 * fudge it with "Identity-H" encoding and custom CIDtoGID map that mimics Unicode
		 * code page. There, however, all characters in the stream are treated as GIDs,
		 * including BOM, which is the reason we need to skip BOM in content text (i.e. that
		 * that is tied to a font).
		 *
		 * To signal this "special" PDFEscape / to8bitStream handling mode,
		 * API.text() function sets (unless you overwrite it with manual values
		 * given to API.text(.., flags) )
		 * flags.autoencode = true
		 * flags.noBOM = true
		 *
		 * ===================================================================================
		 * `flags` properties relied upon:
		 *   .sourceEncoding = string with encoding label.
		 *                     "Unicode" by default. = encoding of the incoming text.
		 *                     pass some non-existing encoding name
		 *                     (ex: 'Do not touch my strings! I know what I am doing.')
		 *                     to make encoding code skip the encoding step.
		 *   .outputEncoding = Either valid PDF encoding name
		 *                     (must be supported by jsPDF font metrics, otherwise no encoding)
		 *                     or a JS object, where key = sourceCharCode, value = outputCharCode
		 *                     missing keys will be treated as: sourceCharCode === outputCharCode
		 *   .noBOM
		 *       See comment higher above for explanation for why this is important
		 *   .autoencode
		 *       See comment higher above for explanation for why this is important
		 */

			var i,l,sourceEncoding,encodingBlock,outputEncoding,newtext,isUnicode,ch,bch;

			flags = flags || {};
			sourceEncoding = flags.sourceEncoding || 'Unicode';
			outputEncoding = flags.outputEncoding;

			// This 'encoding' section relies on font metrics format
			// attached to font objects by, among others,
			// "Willow Systems' standard_font_metrics plugin"
			// see jspdf.plugin.standard_font_metrics.js for format
			// of the font.metadata.encoding Object.
			// It should be something like
			//   .encoding = {'codePages':['WinANSI....'], 'WinANSI...':{code:code, ...}}
			//   .widths = {0:width, code:width, ..., 'fof':divisor}
			//   .kerning = {code:{previous_char_code:shift, ..., 'fof':-divisor},...}
			if ((flags.autoencode || outputEncoding) &amp;&amp;
				fonts[activeFontKey].metadata &amp;&amp;
				fonts[activeFontKey].metadata[sourceEncoding] &amp;&amp;
				fonts[activeFontKey].metadata[sourceEncoding].encoding) {
				encodingBlock = fonts[activeFontKey].metadata[sourceEncoding].encoding;

				// each font has default encoding. Some have it clearly defined.
				if (!outputEncoding &amp;&amp; fonts[activeFontKey].encoding) {
					outputEncoding = fonts[activeFontKey].encoding;
				}

				// Hmmm, the above did not work? Let's try again, in different place.
				if (!outputEncoding &amp;&amp; encodingBlock.codePages) {
					outputEncoding = encodingBlock.codePages[0]; // let's say, first one is the default
				}

				if (typeof outputEncoding === 'string') {
					outputEncoding = encodingBlock[outputEncoding];
				}
				// we want output encoding to be a JS Object, where
				// key = sourceEncoding's character code and
				// value = outputEncoding's character code.
				if (outputEncoding) {
					isUnicode = false;
					newtext = [];
					for (i = 0, l = text.length; i &lt; l; i++) {
						ch = outputEncoding[text.charCodeAt(i)];
						if (ch) {
							newtext.push(
								String.fromCharCode(ch));
						} else {
							newtext.push(
								text[i]);
						}

						// since we are looping over chars anyway, might as well
						// check for residual unicodeness
						if (newtext[i].charCodeAt(0) &gt;&gt; 8) {
							/* more than 255 */
							isUnicode = true;
						}
					}
					text = newtext.join('');
				}
			}

			i = text.length;
			// isUnicode may be set to false above. Hence the triple-equal to undefined
			while (isUnicode === undefined &amp;&amp; i !== 0) {
				if (text.charCodeAt(i - 1) &gt;&gt; 8) {
					/* more than 255 */
					isUnicode = true;
				}
				i--;
			}
			if (!isUnicode) {
				return text;
			}

			newtext = flags.noBOM ? [] : [254, 255];
			for (i = 0, l = text.length; i &lt; l; i++) {
				ch = text.charCodeAt(i);
				bch = ch &gt;&gt; 8; // divide by 256
				if (bch &gt;&gt; 8) {
					/* something left after dividing by 256 second time */
					throw new Error("Character at position " + i + " of string '"
						+ text + "' exceeds 16bits. Cannot be encoded into UCS-2 BE");
				}
				newtext.push(bch);
				newtext.push(ch - (bch &lt;&lt; 8));
			}
			return String.fromCharCode.apply(undefined, newtext);
		},
		pdfEscape = function(text, flags) {
			/**
			 * Replace '/', '(', and ')' with pdf-safe versions
			 *
			 * Doing to8bitStream does NOT make this PDF display unicode text. For that
			 * we also need to reference a unicode font and embed it - royal pain in the rear.
			 *
			 * There is still a benefit to to8bitStream - PDF simply cannot handle 16bit chars,
			 * which JavaScript Strings are happy to provide. So, while we still cannot display
			 * 2-byte characters property, at least CONDITIONALLY converting (entire string containing)
			 * 16bit chars to (USC-2-BE) 2-bytes per char + BOM streams we ensure that entire PDF
			 * is still parseable.
			 * This will allow immediate support for unicode in document properties strings.
			 */
			return to8bitStream(text, flags).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
		},
		putInfo = function() {
			out('/Producer (jsPDF ' + jsPDF.version + ')');
			for(var key in documentProperties) {
				if(documentProperties.hasOwnProperty(key) &amp;&amp; documentProperties[key]) {
					out('/'+key.substr(0,1).toUpperCase() + key.substr(1)
						+' (' + pdfEscape(documentProperties[key]) + ')');
				}
			}
			var created  = new Date(),
				tzoffset = created.getTimezoneOffset(),
				tzsign   = tzoffset &lt; 0 ? '+' : '-',
				tzhour   = Math.floor(Math.abs(tzoffset / 60)),
				tzmin    = Math.abs(tzoffset % 60),
				tzstr    = [tzsign, padd2(tzhour), "'", padd2(tzmin), "'"].join('');
			out(['/CreationDate (D:',
					created.getFullYear(),
					padd2(created.getMonth() + 1),
					padd2(created.getDate()),
					padd2(created.getHours()),
					padd2(created.getMinutes()),
					padd2(created.getSeconds()), tzstr, ')'].join(''));
		},
		putCatalog = function() {
			out('/Type /Catalog');
			out('/Pages 1 0 R');
			// PDF13ref Section 7.2.1
			if (!zoomMode) zoomMode = 'fullwidth';
			switch(zoomMode) {
				case 'fullwidth'  : out('/OpenAction [3 0 R /FitH null]');       break;
				case 'fullheight' : out('/OpenAction [3 0 R /FitV null]');       break;
				case 'fullpage'   : out('/OpenAction [3 0 R /Fit]');             break;
				case 'original'   : out('/OpenAction [3 0 R /XYZ null null 1]'); break;
				default:
					var pcn = '' + zoomMode;
					if (pcn.substr(pcn.length-1) === '%')
						zoomMode = parseInt(zoomMode) / 100;
					if (typeof zoomMode === 'number') {
						out('/OpenAction [3 0 R /XYZ null null '+f2(zoomMode)+']');
					}
			}
			if (!layoutMode) layoutMode = 'continuous';
			switch(layoutMode) {
				case 'continuous' : out('/PageLayout /OneColumn');      break;
				case 'single'     : out('/PageLayout /SinglePage');     break;
				case 'two':
				case 'twoleft'    : out('/PageLayout /TwoColumnLeft');  break;
				case 'tworight'   : out('/PageLayout /TwoColumnRight'); break;
			}
			if (pageMode) {
				/**
				 * A name object specifying how the document should be displayed when opened:
				 * UseNone      : Neither document outline nor thumbnail images visible -- DEFAULT
				 * UseOutlines  : Document outline visible
				 * UseThumbs    : Thumbnail images visible
				 * FullScreen   : Full-screen mode, with no menu bar, window controls, or any other window visible
				 */
				out('/PageMode /' + pageMode);
			}
			events.publish('putCatalog');
		},
		putTrailer = function() {
			out('/Size ' + (objectNumber + 1));
			out('/Root ' + objectNumber + ' 0 R');
			out('/Info ' + (objectNumber - 1) + ' 0 R');
		},
		beginPage = function(width,height) {
			// Dimensions are stored as user units and converted to points on output
			var orientation = typeof height === 'string' &amp;&amp; height.toLowerCase();
			if (typeof width === 'string') {
				var format = width.toLowerCase();
				if (pageFormats.hasOwnProperty(format)) {
					width  = pageFormats[format][0] / k;
					height = pageFormats[format][1] / k;
				}
			}
			if (Array.isArray(width)) {
				height = width[1];
				width = width[0];
			}
			if (orientation) {
				switch(orientation.substr(0,1)) {
					case 'l': if (height &gt; width ) orientation = 's'; break;
					case 'p': if (width &gt; height ) orientation = 's'; break;
				}
				if (orientation === 's') { tmp = width; width = height; height = tmp; }
			}
			outToPages = true;
			pages[++page] = [];
			pagedim[page] = {
				width  : Number(width)  || pageWidth,
				height : Number(height) || pageHeight
			};
			_setPage(page);
		},
		_addPage = function() {
			beginPage.apply(this, arguments);
			// Set line width
			out(f2(lineWidth * k) + ' w');
			// Set draw color
			out(drawColor);
			// resurrecting non-default line caps, joins
			if (lineCapID !== 0) {
				out(lineCapID + ' J');
			}
			if (lineJoinID !== 0) {
				out(lineJoinID + ' j');
			}
			events.publish('addPage', { pageNumber : page });
		},
		_setPage = function(n) {
			if (n &gt; 0 &amp;&amp; n &lt;= page) {
				currentPage = n;
				pageWidth = pagedim[n].width;
				pageHeight = pagedim[n].height;
			}
		},
		/**
		 * Returns a document-specific font key - a label assigned to a
		 * font name + font type combination at the time the font was added
		 * to the font inventory.
		 *
		 * Font key is used as label for the desired font for a block of text
		 * to be added to the PDF document stream.
		 * @private
		 * @function
		 * @param fontName {String} can be undefined on "falthy" to indicate "use current"
		 * @param fontStyle {String} can be undefined on "falthy" to indicate "use current"
		 * @returns {String} Font key.
		 */
		getFont = function(fontName, fontStyle) {
			var key;

			fontName  = fontName  !== undefined ? fontName  : fonts[activeFontKey].fontName;
			fontStyle = fontStyle !== undefined ? fontStyle : fonts[activeFontKey].fontStyle;

			try {
			 // get a string like 'F3' - the KEY corresponding tot he font + type combination.
				key = fontmap[fontName][fontStyle];
			} catch (e) {}

			if (!key) {
				throw new Error("Unable to look up font label for font '" + fontName + "', '"
					+ fontStyle + "'. Refer to getFontList() for available fonts.");
			}
			return key;
		},
		buildDocument = function() {

			outToPages = false; // switches out() to content
			objectNumber = 2;
			content = [];
			offsets = [];

			// putHeader()
			out('%PDF-' + pdfVersion);

			putPages();

			putResources();

			// Info
			newObject();
			out('&lt;&lt;');
			putInfo();
			out('&gt;&gt;');
			out('endobj');

			// Catalog
			newObject();
			out('&lt;&lt;');
			putCatalog();
			out('&gt;&gt;');
			out('endobj');

			// Cross-ref
			var o = content_length, i, p = "0000000000";
			out('xref');
			out('0 ' + (objectNumber + 1));
			out(p+' 65535 f ');
			for (i = 1; i &lt;= objectNumber; i++) {
				out((p + offsets[i]).slice(-10) + ' 00000 n ');
			}
			// Trailer
			out('trailer');
			out('&lt;&lt;');
			putTrailer();
			out('&gt;&gt;');
			out('startxref');
			out(o);
			out('%%EOF');

			outToPages = true;

			return content.join('\n');
		},
		getStyle = function(style) {
			// see path-painting operators in PDF spec
			var op = 'S'; // stroke
			if (style === 'F') {
				op = 'f'; // fill
			} else if (style === 'FD' || style === 'DF') {
				op = 'B'; // both
			} else if (style === 'f' || style === 'f*' || style === 'B' || style === 'B*') {
				/*
				Allow direct use of these PDF path-painting operators:
				- f	fill using nonzero winding number rule
				- f*	fill using even-odd rule
				- B	fill then stroke with fill using non-zero winding number rule
				- B*	fill then stroke with fill using even-odd rule
				*/
				op = style;
			}
			return op;
		},
		getArrayBuffer = function() {
			var data = buildDocument(), len = data.length,
				ab = new ArrayBuffer(len), u8 = new Uint8Array(ab);

			while(len--) u8[len] = data.charCodeAt(len);
			return ab;
		},
		getBlob = function() {
			return new Blob([getArrayBuffer()], { type : "application/pdf" });
		},
		/**
		 * Generates the PDF document.
		 *
		 * If `type` argument is undefined, output is raw body of resulting PDF returned as a string.
		 *
		 * @param {String} type A string identifying one of the possible output types.
		 * @param {Object} options An object providing some additional signalling to PDF generator.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name output
		 */
		output = SAFE(function(type, options) {
			var datauri = ('' + type).substr(0,6) === 'dataur'
				? 'data:application/pdf;base64,'+btoa(buildDocument()):0;

			switch (type) {
				case undefined:
					return buildDocument();
				case 'save':
					if (navigator.getUserMedia) {
						if (global.URL === undefined
						|| global.URL.createObjectURL === undefined) {
							return API.output('dataurlnewwindow');
						}
					}
					saveAs(getBlob(), options);
					if(typeof saveAs.unload === 'function') {
						if(global.setTimeout) {
							setTimeout(saveAs.unload,911);
						}
					}
					break;
				case 'arraybuffer':
					return getArrayBuffer();
				case 'blob':
					return getBlob();
				case 'bloburi':
				case 'bloburl':
					// User is responsible of calling revokeObjectURL
					return global.URL &amp;&amp; global.URL.createObjectURL(getBlob()) || void 0;
				case 'datauristring':
				case 'dataurlstring':
					return datauri;
				case 'dataurlnewwindow':
					var nW = global.open(datauri);
					if (nW || typeof safari === "undefined") return nW;
					/* pass through */
				case 'datauri':
				case 'dataurl':
					return global.document.location.href = datauri;
				default:
					throw new Error('Output type "' + type + '" is not supported.');
			}
			// @TODO: Add different output options
		});

		switch (unit) {
			case 'pt':  k = 1;          break;
			case 'mm':  k = 72 / 25.4;  break;
			case 'cm':  k = 72 / 2.54;  break;
			case 'in':  k = 72;         break;
			case 'px':  k = 96 / 72;    break;
			case 'pc':  k = 12;         break;
			case 'em':  k = 12;         break;
			case 'ex':  k = 6;          break;
			default:
				throw ('Invalid unit: ' + unit);
		}

		//---------------------------------------
		// Public API

		/**
		 * Object exposing internal API to plugins
		 * @public
		 */
		API.internal = {
			'pdfEscape' : pdfEscape,
			'getStyle' : getStyle,
			/**
			 * Returns {FontObject} describing a particular font.
			 * @public
			 * @function
			 * @param fontName {String} (Optional) Font's family name
			 * @param fontStyle {String} (Optional) Font's style variation name (Example:"Italic")
			 * @returns {FontObject}
			 */
			'getFont' : function() {
				return fonts[getFont.apply(API, arguments)];
			},
			'getFontSize' : function() {
				return activeFontSize;
			},
			'getLineHeight' : function() {
				return activeFontSize * lineHeightProportion;
			},
			'write' : function(string1 /*, string2, string3, etc */) {
				out(arguments.length === 1 ? string1 : Array.prototype.join.call(arguments, ' '));
			},
			'getCoordinateString' : function(value) {
				return f2(value * k);
			},
			'getVerticalCoordinateString' : function(value) {
				return f2((pageHeight - value) * k);
			},
			'collections' : {},
			'newObject' : newObject,
			'putStream' : putStream,
			'events' : events,
			// ratio that you use in multiplication of a given "size" number to arrive to 'point'
			// units of measurement.
			// scaleFactor is set at initialization of the document and calculated against the stated
			// default measurement units for the document.
			// If default is "mm", k is the number that will turn number in 'mm' into 'points' number.
			// through multiplication.
			'scaleFactor' : k,
			'pageSize' : {
				get width() {
					return pageWidth
				},
				get height() {
					return pageHeight
				}
			},
			'output' : function(type, options) {
				return output(type, options);
			},
			'getNumberOfPages' : function() {
				return pages.length - 1;
			},
			'pages' : pages
		};

		/**
		 * Adds (and transfers the focus to) new page to the PDF document.
		 * @function
		 * @returns {jsPDF}
		 *
		 * @methodOf jsPDF#
		 * @name addPage
		 */
		API.addPage = function() {
			_addPage.apply(this, arguments);
			return this;
		};
		API.setPage = function() {
			_setPage.apply(this, arguments);
			return this;
		};
		API.setDisplayMode = function(zoom, layout, pmode) {
			zoomMode   = zoom;
			layoutMode = layout;
			pageMode   = pmode;
			return this;
		},

		/**
		 * Adds text to page. Supports adding multiline text when 'text' argument is an Array of Strings.
		 *
		 * @function
		 * @param {String|Array} text String or array of strings to be added to the page. Each line is shifted one line down per font, spacing settings declared before this call.
		 * @param {Number} x Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Object} flags Collection of settings signalling how the text must be encoded. Defaults are sane. If you think you want to pass some flags, you likely can read the source.
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name text
		 */
		API.text = function(text, x, y, flags, angle) {
			/**
			 * Inserts something like this into PDF
			 *   BT
			 *    /F1 16 Tf  % Font name + size
			 *    16 TL % How many units down for next line in multiline text
			 *    0 g % color
			 *    28.35 813.54 Td % position
			 *    (line one) Tj
			 *    T* (line two) Tj
			 *    T* (line three) Tj
			 *   ET
			 */
			function ESC(s) {
				s = s.split("\t").join(Array(options.TabLen||9).join(" "));
				return pdfEscape(s, flags);
			}

			// Pre-August-2012 the order of arguments was function(x, y, text, flags)
			// in effort to make all calls have similar signature like
			//   function(data, coordinates... , miscellaneous)
			// this method had its args flipped.
			// code below allows backward compatibility with old arg order.
			if (typeof text === 'number') {
				tmp = y;
				y = x;
				x = text;
				text = tmp;
			}

			// If there are any newlines in text, we assume
			// the user wanted to print multiple lines, so break the
			// text up into an array.  If the text is already an array,
			// we assume the user knows what they are doing.
			if (typeof text === 'string' &amp;&amp; text.match(/[\n\r]/)) {
				text = text.split(/\r\n|\r|\n/g);
			}
			if (typeof flags === 'number') {
				angle = flags;
				flags = null;
			}
			var xtra = '',mode = 'Td', todo;
			if (angle) {
				angle *= (Math.PI / 180);
				var c = Math.cos(angle),
				s = Math.sin(angle);
				xtra = [f2(c), f2(s), f2(s * -1), f2(c), ''].join(" ");
				mode = 'Tm';
			}
			flags = flags || {};
			if (!('noBOM' in flags))
				flags.noBOM = true;
			if (!('autoencode' in flags))
				flags.autoencode = true;

			if (typeof text === 'string') {
				text = ESC(text);
			} else if (text instanceof Array) {
				// we don't want to destroy  original text array, so cloning it
				var sa = text.concat(), da = [], len = sa.length;
				// we do array.join('text that must not be PDFescaped")
				// thus, pdfEscape each component separately
				while (len--) {
					da.push(ESC(sa.shift()));
				}
				var linesLeft = Math.ceil((pageHeight - y) * k / (activeFontSize * lineHeightProportion));
				if (0 &lt;= linesLeft &amp;&amp; linesLeft &lt; da.length + 1) {
					todo = da.splice(linesLeft-1);
				}
				text = da.join(") Tj\nT* (");
			} else {
				throw new Error('Type of text must be string or Array. "' + text + '" is not recognized.');
			}
			// Using "'" ("go next line and render text" mark) would save space but would complicate our rendering code, templates

			// BT .. ET does NOT have default settings for Tf. You must state that explicitely every time for BT .. ET
			// if you want text transformation matrix (+ multiline) to work reliably (which reads sizes of things from font declarations)
			// Thus, there is NO useful, *reliable* concept of "default" font for a page.
			// The fact that "default" (reuse font used before) font worked before in basic cases is an accident
			// - readers dealing smartly with brokenness of jsPDF's markup.
			out(
				'BT\n/' +
				activeFontKey + ' ' + activeFontSize + ' Tf\n' +     // font face, style, size
				(activeFontSize * lineHeightProportion) + ' TL\n' +  // line spacing
				textColor +
				'\n' + xtra + f2(x * k) + ' ' + f2((pageHeight - y) * k) + ' ' + mode + '\n(' +
				text +
				') Tj\nET');

			if (todo) {
				this.addPage();
				this.text( todo, x, activeFontSize * 1.7 / k);
			}

			return this;
		};

		API.lstext = function(text, x, y, spacing) {
			for (var i = 0, len = text.length ; i &lt; len; i++, x += spacing) this.text(text[i], x, y);
		};

		API.line = function(x1, y1, x2, y2) {
			return this.lines([[x2 - x1, y2 - y1]], x1, y1);
		};

		API.clip = function() {
			// By patrick-roberts, github.com/MrRio/jsPDF/issues/328
			// Call .clip() after calling .rect() with a style argument of null
			out('W') // clip
			out('S') // stroke path; necessary for clip to work
		};

		/**
		 * Adds series of curves (straight lines or cubic bezier curves) to canvas, starting at `x`, `y` coordinates.
		 * All data points in `lines` are relative to last line origin.
		 * `x`, `y` become x1,y1 for first line / curve in the set.
		 * For lines you only need to specify [x2, y2] - (ending point) vector against x1, y1 starting point.
		 * For bezier curves you need to specify [x2,y2,x3,y3,x4,y4] - vectors to control points 1, 2, ending point. All vectors are against the start of the curve - x1,y1.
		 *
		 * @example .lines([[2,2],[-2,2],[1,1,2,2,3,3],[2,1]], 212,110, 10) // line, line, bezier curve, line
		 * @param {Array} lines Array of *vector* shifts as pairs (lines) or sextets (cubic bezier curves).
		 * @param {Number} x Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} scale (Defaults to [1.0,1.0]) x,y Scaling factor for all vectors. Elements can be any floating number Sub-one makes drawing smaller. Over-one grows the drawing. Negative flips the direction.
		 * @param {String} style A string specifying the painting style or null.  Valid styles include: 'S' [default] - stroke, 'F' - fill,  and 'DF' (or 'FD') -  fill then stroke. A null value postpones setting the style so that a shape may be composed using multiple method calls. The last drawing method call used to define the shape should not have a null style argument.
		 * @param {Boolean} closed If true, the path is closed with a straight line from the end of the last curve to the starting point.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name lines
		 */
		API.lines = function(lines, x, y, scale, style, closed) {
			var scalex,scaley,i,l,leg,x2,y2,x3,y3,x4,y4;

			// Pre-August-2012 the order of arguments was function(x, y, lines, scale, style)
			// in effort to make all calls have similar signature like
			//   function(content, coordinateX, coordinateY , miscellaneous)
			// this method had its args flipped.
			// code below allows backward compatibility with old arg order.
			if (typeof lines === 'number') {
				tmp = y;
				y = x;
				x = lines;
				lines = tmp;
			}

			scale = scale || [1, 1];

			// starting point
			out(f3(x * k) + ' ' + f3((pageHeight - y) * k) + ' m ');

			scalex = scale[0];
			scaley = scale[1];
			l = lines.length;
			//, x2, y2 // bezier only. In page default measurement "units", *after* scaling
			//, x3, y3 // bezier only. In page default measurement "units", *after* scaling
			// ending point for all, lines and bezier. . In page default measurement "units", *after* scaling
			x4 = x; // last / ending point = starting point for first item.
			y4 = y; // last / ending point = starting point for first item.

			for (i = 0; i &lt; l; i++) {
				leg = lines[i];
				if (leg.length === 2) {
					// simple line
					x4 = leg[0] * scalex + x4; // here last x4 was prior ending point
					y4 = leg[1] * scaley + y4; // here last y4 was prior ending point
					out(f3(x4 * k) + ' ' + f3((pageHeight - y4) * k) + ' l');
				} else {
					// bezier curve
					x2 = leg[0] * scalex + x4; // here last x4 is prior ending point
					y2 = leg[1] * scaley + y4; // here last y4 is prior ending point
					x3 = leg[2] * scalex + x4; // here last x4 is prior ending point
					y3 = leg[3] * scaley + y4; // here last y4 is prior ending point
					x4 = leg[4] * scalex + x4; // here last x4 was prior ending point
					y4 = leg[5] * scaley + y4; // here last y4 was prior ending point
					out(
						f3(x2 * k) + ' ' +
						f3((pageHeight - y2) * k) + ' ' +
						f3(x3 * k) + ' ' +
						f3((pageHeight - y3) * k) + ' ' +
						f3(x4 * k) + ' ' +
						f3((pageHeight - y4) * k) + ' c');
				}
			}

			if (closed) {
				out(' h');
			}

			// stroking / filling / both the path
			if (style !== null) {
				out(getStyle(style));
			}
			return this;
		};

		/**
		 * Adds a rectangle to PDF
		 *
		 * @param {Number} x Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} w Width (in units declared at inception of PDF document)
		 * @param {Number} h Height (in units declared at inception of PDF document)
		 * @param {String} style A string specifying the painting style or null.  Valid styles include: 'S' [default] - stroke, 'F' - fill,  and 'DF' (or 'FD') -  fill then stroke. A null value postpones setting the style so that a shape may be composed using multiple method calls. The last drawing method call used to define the shape should not have a null style argument.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name rect
		 */
		API.rect = function(x, y, w, h, style) {
			var op = getStyle(style);
			out([
					f2(x * k),
					f2((pageHeight - y) * k),
					f2(w * k),
					f2(-h * k),
					're'
				].join(' '));

			if (style !== null) {
				out(getStyle(style));
			}

			return this;
		};

		/**
		 * Adds a triangle to PDF
		 *
		 * @param {Number} x1 Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y1 Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} x2 Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y2 Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} x3 Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y3 Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {String} style A string specifying the painting style or null.  Valid styles include: 'S' [default] - stroke, 'F' - fill,  and 'DF' (or 'FD') -  fill then stroke. A null value postpones setting the style so that a shape may be composed using multiple method calls. The last drawing method call used to define the shape should not have a null style argument.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name triangle
		 */
		API.triangle = function(x1, y1, x2, y2, x3, y3, style) {
			this.lines(
				[
					[x2 - x1, y2 - y1], // vector to point 2
					[x3 - x2, y3 - y2], // vector to point 3
					[x1 - x3, y1 - y3]// closing vector back to point 1
				],
				x1,
				y1, // start of path
				[1, 1],
				style,
				true);
			return this;
		};

		/**
		 * Adds a rectangle with rounded corners to PDF
		 *
		 * @param {Number} x Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} w Width (in units declared at inception of PDF document)
		 * @param {Number} h Height (in units declared at inception of PDF document)
		 * @param {Number} rx Radius along x axis (in units declared at inception of PDF document)
		 * @param {Number} rx Radius along y axis (in units declared at inception of PDF document)
		 * @param {String} style A string specifying the painting style or null.  Valid styles include: 'S' [default] - stroke, 'F' - fill,  and 'DF' (or 'FD') -  fill then stroke. A null value postpones setting the style so that a shape may be composed using multiple method calls. The last drawing method call used to define the shape should not have a null style argument.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name roundedRect
		 */
		API.roundedRect = function(x, y, w, h, rx, ry, style) {
			var MyArc = 4 / 3 * (Math.SQRT2 - 1);
			this.lines(
				[
					[(w - 2 * rx), 0],
					[(rx * MyArc), 0, rx, ry - (ry * MyArc), rx, ry],
					[0, (h - 2 * ry)],
					[0, (ry * MyArc),  - (rx * MyArc), ry, -rx, ry],
					[(-w + 2 * rx), 0],
					[ - (rx * MyArc), 0, -rx,  - (ry * MyArc), -rx, -ry],
					[0, (-h + 2 * ry)],
					[0,  - (ry * MyArc), (rx * MyArc), -ry, rx, -ry]
				],
				x + rx,
				y, // start of path
				[1, 1],
				style);
			return this;
		};

		/**
		 * Adds an ellipse to PDF
		 *
		 * @param {Number} x Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} rx Radius along x axis (in units declared at inception of PDF document)
		 * @param {Number} rx Radius along y axis (in units declared at inception of PDF document)
		 * @param {String} style A string specifying the painting style or null.  Valid styles include: 'S' [default] - stroke, 'F' - fill,  and 'DF' (or 'FD') -  fill then stroke. A null value postpones setting the style so that a shape may be composed using multiple method calls. The last drawing method call used to define the shape should not have a null style argument.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name ellipse
		 */
		API.ellipse = function(x, y, rx, ry, style) {
			var lx = 4 / 3 * (Math.SQRT2 - 1) * rx,
				ly = 4 / 3 * (Math.SQRT2 - 1) * ry;

			out([
					f2((x + rx) * k),
					f2((pageHeight - y) * k),
					'm',
					f2((x + rx) * k),
					f2((pageHeight - (y - ly)) * k),
					f2((x + lx) * k),
					f2((pageHeight - (y - ry)) * k),
					f2(x * k),
					f2((pageHeight - (y - ry)) * k),
					'c'
				].join(' '));
			out([
					f2((x - lx) * k),
					f2((pageHeight - (y - ry)) * k),
					f2((x - rx) * k),
					f2((pageHeight - (y - ly)) * k),
					f2((x - rx) * k),
					f2((pageHeight - y) * k),
					'c'
				].join(' '));
			out([
					f2((x - rx) * k),
					f2((pageHeight - (y + ly)) * k),
					f2((x - lx) * k),
					f2((pageHeight - (y + ry)) * k),
					f2(x * k),
					f2((pageHeight - (y + ry)) * k),
					'c'
				].join(' '));
			out([
					f2((x + lx) * k),
					f2((pageHeight - (y + ry)) * k),
					f2((x + rx) * k),
					f2((pageHeight - (y + ly)) * k),
					f2((x + rx) * k),
					f2((pageHeight - y) * k),
					'c'
				].join(' '));

			if (style !== null) {
				out(getStyle(style));
			}

			return this;
		};

		/**
		 * Adds an circle to PDF
		 *
		 * @param {Number} x Coordinate (in units declared at inception of PDF document) against left edge of the page
		 * @param {Number} y Coordinate (in units declared at inception of PDF document) against upper edge of the page
		 * @param {Number} r Radius (in units declared at inception of PDF document)
		 * @param {String} style A string specifying the painting style or null.  Valid styles include: 'S' [default] - stroke, 'F' - fill,  and 'DF' (or 'FD') -  fill then stroke. A null value postpones setting the style so that a shape may be composed using multiple method calls. The last drawing method call used to define the shape should not have a null style argument.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name circle
		 */
		API.circle = function(x, y, r, style) {
			return this.ellipse(x, y, r, r, style);
		};

		/**
		 * Adds a properties to the PDF document
		 *
		 * @param {Object} A property_name-to-property_value object structure.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setProperties
		 */
		API.setProperties = function(properties) {
			// copying only those properties we can render.
			for (var property in documentProperties) {
				if (documentProperties.hasOwnProperty(property) &amp;&amp; properties[property]) {
					documentProperties[property] = properties[property];
				}
			}
			return this;
		};

		/**
		 * Sets font size for upcoming text elements.
		 *
		 * @param {Number} size Font size in points.
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setFontSize
		 */
		API.setFontSize = function(size) {
			activeFontSize = size;
			return this;
		};

		/**
		 * Sets text font face, variant for upcoming text elements.
		 * See output of jsPDF.getFontList() for possible font names, styles.
		 *
		 * @param {String} fontName Font name or family. Example: "times"
		 * @param {String} fontStyle Font style or variant. Example: "italic"
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setFont
		 */
		API.setFont = function(fontName, fontStyle) {
			activeFontKey = getFont(fontName, fontStyle);
			// if font is not found, the above line blows up and we never go further
			return this;
		};

		/**
		 * Switches font style or variant for upcoming text elements,
		 * while keeping the font face or family same.
		 * See output of jsPDF.getFontList() for possible font names, styles.
		 *
		 * @param {String} style Font style or variant. Example: "italic"
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setFontStyle
		 */
		API.setFontStyle = API.setFontType = function(style) {
			activeFontKey = getFont(undefined, style);
			// if font is not found, the above line blows up and we never go further
			return this;
		};

		/**
		 * Returns an object - a tree of fontName to fontStyle relationships available to
		 * active PDF document.
		 *
		 * @public
		 * @function
		 * @returns {Object} Like {'times':['normal', 'italic', ... ], 'arial':['normal', 'bold', ... ], ... }
		 * @methodOf jsPDF#
		 * @name getFontList
		 */
		API.getFontList = function() {
			// TODO: iterate over fonts array or return copy of fontmap instead in case more are ever added.
			var list = {},fontName,fontStyle,tmp;

			for (fontName in fontmap) {
				if (fontmap.hasOwnProperty(fontName)) {
					list[fontName] = tmp = [];
					for (fontStyle in fontmap[fontName]) {
						if (fontmap[fontName].hasOwnProperty(fontStyle)) {
							tmp.push(fontStyle);
						}
					}
				}
			}

			return list;
		};

		/**
		 * Sets line width for upcoming lines.
		 *
		 * @param {Number} width Line width (in units declared at inception of PDF document)
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setLineWidth
		 */
		API.setLineWidth = function(width) {
			out((width * k).toFixed(2) + ' w');
			return this;
		};

		/**
		 * Sets the stroke color for upcoming elements.
		 *
		 * Depending on the number of arguments given, Gray, RGB, or CMYK
		 * color space is implied.
		 *
		 * When only ch1 is given, "Gray" color space is implied and it
		 * must be a value in the range from 0.00 (solid black) to to 1.00 (white)
		 * if values are communicated as String types, or in range from 0 (black)
		 * to 255 (white) if communicated as Number type.
		 * The RGB-like 0-255 range is provided for backward compatibility.
		 *
		 * When only ch1,ch2,ch3 are given, "RGB" color space is implied and each
		 * value must be in the range from 0.00 (minimum intensity) to to 1.00
		 * (max intensity) if values are communicated as String types, or
		 * from 0 (min intensity) to to 255 (max intensity) if values are communicated
		 * as Number types.
		 * The RGB-like 0-255 range is provided for backward compatibility.
		 *
		 * When ch1,ch2,ch3,ch4 are given, "CMYK" color space is implied and each
		 * value must be a in the range from 0.00 (0% concentration) to to
		 * 1.00 (100% concentration)
		 *
		 * Because JavaScript treats fixed point numbers badly (rounds to
		 * floating point nearest to binary representation) it is highly advised to
		 * communicate the fractional numbers as String types, not JavaScript Number type.
		 *
		 * @param {Number|String} ch1 Color channel value
		 * @param {Number|String} ch2 Color channel value
		 * @param {Number|String} ch3 Color channel value
		 * @param {Number|String} ch4 Color channel value
		 *
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setDrawColor
		 */
		API.setDrawColor = function(ch1, ch2, ch3, ch4) {
			var color;
			if (ch2 === undefined || (ch4 === undefined &amp;&amp; ch1 === ch2 === ch3)) {
				// Gray color space.
				if (typeof ch1 === 'string') {
					color = ch1 + ' G';
				} else {
					color = f2(ch1 / 255) + ' G';
				}
			} else if (ch4 === undefined) {
				// RGB
				if (typeof ch1 === 'string') {
					color = [ch1, ch2, ch3, 'RG'].join(' ');
				} else {
					color = [f2(ch1 / 255), f2(ch2 / 255), f2(ch3 / 255), 'RG'].join(' ');
				}
			} else {
				// CMYK
				if (typeof ch1 === 'string') {
					color = [ch1, ch2, ch3, ch4, 'K'].join(' ');
				} else {
					color = [f2(ch1), f2(ch2), f2(ch3), f2(ch4), 'K'].join(' ');
				}
			}

			out(color);
			return this;
		};

		/**
		 * Sets the fill color for upcoming elements.
		 *
		 * Depending on the number of arguments given, Gray, RGB, or CMYK
		 * color space is implied.
		 *
		 * When only ch1 is given, "Gray" color space is implied and it
		 * must be a value in the range from 0.00 (solid black) to to 1.00 (white)
		 * if values are communicated as String types, or in range from 0 (black)
		 * to 255 (white) if communicated as Number type.
		 * The RGB-like 0-255 range is provided for backward compatibility.
		 *
		 * When only ch1,ch2,ch3 are given, "RGB" color space is implied and each
		 * value must be in the range from 0.00 (minimum intensity) to to 1.00
		 * (max intensity) if values are communicated as String types, or
		 * from 0 (min intensity) to to 255 (max intensity) if values are communicated
		 * as Number types.
		 * The RGB-like 0-255 range is provided for backward compatibility.
		 *
		 * When ch1,ch2,ch3,ch4 are given, "CMYK" color space is implied and each
		 * value must be a in the range from 0.00 (0% concentration) to to
		 * 1.00 (100% concentration)
		 *
		 * Because JavaScript treats fixed point numbers badly (rounds to
		 * floating point nearest to binary representation) it is highly advised to
		 * communicate the fractional numbers as String types, not JavaScript Number type.
		 *
		 * @param {Number|String} ch1 Color channel value
		 * @param {Number|String} ch2 Color channel value
		 * @param {Number|String} ch3 Color channel value
		 * @param {Number|String} ch4 Color channel value
		 *
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setFillColor
		 */
		API.setFillColor = function(ch1, ch2, ch3, ch4) {
			var color;

			if (ch2 === undefined || (ch4 === undefined &amp;&amp; ch1 === ch2 === ch3)) {
				// Gray color space.
				if (typeof ch1 === 'string') {
					color = ch1 + ' g';
				} else {
					color = f2(ch1 / 255) + ' g';
				}
			} else if (ch4 === undefined) {
				// RGB
				if (typeof ch1 === 'string') {
					color = [ch1, ch2, ch3, 'rg'].join(' ');
				} else {
					color = [f2(ch1 / 255), f2(ch2 / 255), f2(ch3 / 255), 'rg'].join(' ');
				}
			} else {
				// CMYK
				if (typeof ch1 === 'string') {
					color = [ch1, ch2, ch3, ch4, 'k'].join(' ');
				} else {
					color = [f2(ch1), f2(ch2), f2(ch3), f2(ch4), 'k'].join(' ');
				}
			}

			out(color);
			return this;
		};

		/**
		 * Sets the text color for upcoming elements.
		 * If only one, first argument is given,
		 * treats the value as gray-scale color value.
		 *
		 * @param {Number} r Red channel color value in range 0-255 or {String} r color value in hexadecimal, example: '#FFFFFF'
		 * @param {Number} g Green channel color value in range 0-255
		 * @param {Number} b Blue channel color value in range 0-255
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setTextColor
		 */
		API.setTextColor = function(r, g, b) {
			if ((typeof r === 'string') &amp;&amp; /^#[0-9A-Fa-f]{6}$/.test(r)) {
				var hex = parseInt(r.substr(1), 16);
				r = (hex &gt;&gt; 16) &amp; 255;
				g = (hex &gt;&gt; 8) &amp; 255;
				b = (hex &amp; 255);
			}

			if ((r === 0 &amp;&amp; g === 0 &amp;&amp; b === 0) || (typeof g === 'undefined')) {
				textColor = f3(r / 255) + ' g';
			} else {
				textColor = [f3(r / 255), f3(g / 255), f3(b / 255), 'rg'].join(' ');
			}
			return this;
		};

		/**
		 * Is an Object providing a mapping from human-readable to
		 * integer flag values designating the varieties of line cap
		 * and join styles.
		 *
		 * @returns {Object}
		 * @fieldOf jsPDF#
		 * @name CapJoinStyles
		 */
		API.CapJoinStyles = {
			0 : 0,
			'butt' : 0,
			'but' : 0,
			'miter' : 0,
			1 : 1,
			'round' : 1,
			'rounded' : 1,
			'circle' : 1,
			2 : 2,
			'projecting' : 2,
			'project' : 2,
			'square' : 2,
			'bevel' : 2
		};

		/**
		 * Sets the line cap styles
		 * See {jsPDF.CapJoinStyles} for variants
		 *
		 * @param {String|Number} style A string or number identifying the type of line cap
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setLineCap
		 */
		API.setLineCap = function(style) {
			var id = this.CapJoinStyles[style];
			if (id === undefined) {
				throw new Error("Line cap style of '" + style + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
			}
			lineCapID = id;
			out(id + ' J');

			return this;
		};

		/**
		 * Sets the line join styles
		 * See {jsPDF.CapJoinStyles} for variants
		 *
		 * @param {String|Number} style A string or number identifying the type of line join
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name setLineJoin
		 */
		API.setLineJoin = function(style) {
			var id = this.CapJoinStyles[style];
			if (id === undefined) {
				throw new Error("Line join style of '" + style + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
			}
			lineJoinID = id;
			out(id + ' j');

			return this;
		};

		// Output is both an internal (for plugins) and external function
		API.output = output;

		/**
		 * Saves as PDF document. An alias of jsPDF.output('save', 'filename.pdf')
		 * @param  {String} filename The filename including extension.
		 *
		 * @function
		 * @returns {jsPDF}
		 * @methodOf jsPDF#
		 * @name save
		 */
		API.save = function(filename) {
			API.output('save', filename);
		};

		// applying plugins (more methods) ON TOP of built-in API.
		// this is intentional as we allow plugins to override
		// built-ins
		for (var plugin in jsPDF.API) {
			if (jsPDF.API.hasOwnProperty(plugin)) {
				if (plugin === 'events' &amp;&amp; jsPDF.API.events.length) {
					(function(events, newEvents) {

						// jsPDF.API.events is a JS Array of Arrays
						// where each Array is a pair of event name, handler
						// Events were added by plugins to the jsPDF instantiator.
						// These are always added to the new instance and some ran
						// during instantiation.
						var eventname,handler_and_args,i;

						for (i = newEvents.length - 1; i !== -1; i--) {
							// subscribe takes 3 args: 'topic', function, runonce_flag
							// if undefined, runonce is false.
							// users can attach callback directly,
							// or they can attach an array with [callback, runonce_flag]
							// that's what the "apply" magic is for below.
							eventname = newEvents[i][0];
							handler_and_args = newEvents[i][1];
							events.subscribe.apply(
								events,
								[eventname].concat(
									typeof handler_and_args === 'function' ?
										[handler_and_args] : handler_and_args));
						}
					}(events, jsPDF.API.events));
				} else {
					API[plugin] = jsPDF.API[plugin];
				}
			}
		}

		//////////////////////////////////////////////////////
		// continuing initialization of jsPDF Document object
		//////////////////////////////////////////////////////
		// Add the first page automatically
		addFonts();
		activeFontKey = 'F1';
		_addPage(format, orientation);

		events.publish('initialized');
		return API;
	}

	/**
	 * jsPDF.API is a STATIC property of jsPDF class.
	 * jsPDF.API is an object you can add methods and properties to.
	 * The methods / properties you add will show up in new jsPDF objects.
	 *
	 * One property is prepopulated. It is the 'events' Object. Plugin authors can add topics,
	 * callbacks to this object. These will be reassigned to all new instances of jsPDF.
	 * Examples:
	 * jsPDF.API.events['initialized'] = function(){ 'this' is API object }
	 * jsPDF.API.events['addFont'] = function(added_font_object){ 'this' is API object }
	 *
	 * @static
	 * @public
	 * @memberOf jsPDF
	 * @name API
	 *
	 * @example
	 * jsPDF.API.mymethod = function(){
	 *   // 'this' will be ref to internal API object. see jsPDF source
	 *   // , so you can refer to built-in methods like so:
	 *   //     this.line(....)
	 *   //     this.text(....)
	 * }
	 * var pdfdoc = new jsPDF()
	 * pdfdoc.mymethod() // &lt;- !!!!!!
	 */
	jsPDF.API = {events:[]};
	jsPDF.version = "1.0.272-debug 2014-09-29T15:09:diegocr";

	if (typeof define === 'function' &amp;&amp; define.amd) {
		define('jsPDF', function() {
			return jsPDF;
		});
	} else {
		global.jsPDF = jsPDF;
	}
	return jsPDF;
}(typeof self !== "undefined" &amp;&amp; self || typeof window !== "undefined" &amp;&amp; window || this));
/**
 * jsPDF addHTML PlugIn
 * Copyright (c) 2014 Diego Casorran
 *
 * Licensed under the MIT License.
 * http://opensource.org/licenses/mit-license
 */

(function (jsPDFAPI) {
	'use strict';

	/**
	 * Renders an HTML element to canvas object which added as an image to the PDF
	 *
	 * This PlugIn requires html2canvas: https://github.com/niklasvh/html2canvas
	 *            OR rasterizeHTML: https://github.com/cburgmer/rasterizeHTML.js
	 *
	 * @public
	 * @function
	 * @param element {Mixed} HTML Element, or anything supported by html2canvas.
	 * @param x {Number} starting X coordinate in jsPDF instance's declared units.
	 * @param y {Number} starting Y coordinate in jsPDF instance's declared units.
	 * @param options {Object} Additional options, check the code below.
	 * @param callback {Function} to call when the rendering has finished.
	 *
	 * NOTE: Every parameter is optional except 'element' and 'callback', in such
	 *       case the image is positioned at 0x0 covering the whole PDF document
	 *       size. Ie, to easily take screenshoots of webpages saving them to PDF.
	 */
	jsPDFAPI.addHTML = function (element, x, y, options, callback) {
		'use strict';

		if(typeof html2canvas === 'undefined' &amp;&amp; typeof rasterizeHTML === 'undefined')
			throw new Error('You need either '
				+'https://github.com/niklasvh/html2canvas'
				+' or https://github.com/cburgmer/rasterizeHTML.js');

		if(typeof x !== 'number') {
			options = x;
			callback = y;
		}

		if(typeof options === 'function') {
			callback = options;
			options = null;
		}

		var I = this.internal, K = I.scaleFactor, W = I.pageSize.width, H = I.pageSize.height;

		options = options || {};
		options.onrendered = function(obj) {
			x = parseInt(x) || 0;
			y = parseInt(y) || 0;
			var dim = options.dim || {};
			var h = dim.h || 0;
			var w = dim.w || Math.min(W,obj.width/K) - x;

			var format = 'JPEG';
			if(options.format)
				format = options.format;

			if(obj.height &gt; H &amp;&amp; options.pagesplit) {
				var crop = function() {
					var cy = 0;
					while(1) {
						var canvas = document.createElement('canvas');
						canvas.width = Math.min(W*K,obj.width);
						canvas.height = Math.min(H*K,obj.height-cy);
						var ctx = canvas.getContext('2d');
						ctx.drawImage(obj,0,cy,obj.width,canvas.height,0,0,canvas.width,canvas.height);
						var args = [canvas, x,cy?0:y,canvas.width/K,canvas.height/K, format,null,'SLOW'];
						this.addImage.apply(this, args);
						cy += canvas.height;
						if(cy &gt;= obj.height) break;
						this.addPage();
					}
					callback(w,cy,null,args);
				}.bind(this);
				if(obj.nodeName === 'CANVAS') {
					var img = new Image();
					img.onload = crop;
					img.src = obj.toDataURL("image/png");
					obj = img;
				} else {
					crop();
				}
			} else {
				var alias = Math.random().toString(35);
				var args = [obj, x,y,w,h, format,alias,'SLOW'];

				this.addImage.apply(this, args);

				callback(w,h,alias,args);
			}
		}.bind(this);

		if(typeof html2canvas !== 'undefined' &amp;&amp; !options.rstz) {
			return html2canvas(element, options);
		}

		if(typeof rasterizeHTML !== 'undefined') {
			var meth = 'drawDocument';
			if(typeof element === 'string') {
				meth = /^http/.test(element) ? 'drawURL' : 'drawHTML';
			}
			options.width = options.width || (W*K);
			return rasterizeHTML[meth](element, void 0, options).then(function(r) {
				options.onrendered(r.image);
			}, function(e) {
				callback(null,e);
			});
		}

		return null;
	};
})(jsPDF.API);
/** @preserve
 * jsPDF addImage plugin
 * Copyright (c) 2012 Jason Siefken, https://github.com/siefkenj/
 *               2013 Chris Dowling, https://github.com/gingerchris
 *               2013 Trinh Ho, https://github.com/ineedfat
 *               2013 Edwin Alejandro Perez, https://github.com/eaparango
 *               2013 Norah Smith, https://github.com/burnburnrocket
 *               2014 Diego Casorran, https://github.com/diegocr
 *               2014 James Robb, https://github.com/jamesbrobb
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

;(function(jsPDFAPI) {
	'use strict'

	var namespace = 'addImage_',
		supported_image_types = ['jpeg', 'jpg', 'png'];

	// Image functionality ported from pdf.js
	var putImage = function(img) {

		var objectNumber = this.internal.newObject()
		, out = this.internal.write
		, putStream = this.internal.putStream

		img['n'] = objectNumber

		out('&lt;&lt;/Type /XObject')
		out('/Subtype /Image')
		out('/Width ' + img['w'])
		out('/Height ' + img['h'])
		if (img['cs'] === this.color_spaces.INDEXED) {
			out('/ColorSpace [/Indexed /DeviceRGB '
					// if an indexed png defines more than one colour with transparency, we've created a smask
					+ (img['pal'].length / 3 - 1) + ' ' + ('smask' in img ? objectNumber + 2 : objectNumber + 1)
					+ ' 0 R]');
		} else {
			out('/ColorSpace /' + img['cs']);
			if (img['cs'] === this.color_spaces.DEVICE_CMYK) {
				out('/Decode [1 0 1 0 1 0 1 0]');
			}
		}
		out('/BitsPerComponent ' + img['bpc']);
		if ('f' in img) {
			out('/Filter /' + img['f']);
		}
		if ('dp' in img) {
			out('/DecodeParms &lt;&lt;' + img['dp'] + '&gt;&gt;');
		}
		if ('trns' in img &amp;&amp; img['trns'].constructor == Array) {
			var trns = '',
				i = 0,
				len = img['trns'].length;
			for (; i &lt; len; i++)
				trns += (img['trns'][i] + ' ' + img['trns'][i] + ' ');
			out('/Mask [' + trns + ']');
		}
		if ('smask' in img) {
			out('/SMask ' + (objectNumber + 1) + ' 0 R');
		}
		out('/Length ' + img['data'].length + '&gt;&gt;');

		putStream(img['data']);

		out('endobj');

		// Soft mask
		if ('smask' in img) {
			var dp = '/Predictor 15 /Colors 1 /BitsPerComponent ' + img['bpc'] + ' /Columns ' + img['w'];
			var smask = {'w': img['w'], 'h': img['h'], 'cs': 'DeviceGray', 'bpc': img['bpc'], 'dp': dp, 'data': img['smask']};
			if ('f' in img)
				smask.f = img['f'];
			putImage.call(this, smask);
		}

	    //Palette
		if (img['cs'] === this.color_spaces.INDEXED) {

			this.internal.newObject();
			//out('&lt;&lt; /Filter / ' + img['f'] +' /Length ' + img['pal'].length + '&gt;&gt;');
			//putStream(zlib.compress(img['pal']));
			out('&lt;&lt; /Length ' + img['pal'].length + '&gt;&gt;');
			putStream(this.arrayBufferToBinaryString(new Uint8Array(img['pal'])));
			out('endobj');
		}
	}
	, putResourcesCallback = function() {
		var images = this.internal.collections[namespace + 'images']
		for ( var i in images ) {
			putImage.call(this, images[i])
		}
	}
	, putXObjectsDictCallback = function(){
		var images = this.internal.collections[namespace + 'images']
		, out = this.internal.write
		, image
		for (var i in images) {
			image = images[i]
			out(
				'/I' + image['i']
				, image['n']
				, '0'
				, 'R'
			)
		}
	}
	, checkCompressValue = function(value) {
		if(value &amp;&amp; typeof value === 'string')
			value = value.toUpperCase();
		return value in jsPDFAPI.image_compression ? value : jsPDFAPI.image_compression.NONE;
	}
	, getImages = function() {
		var images = this.internal.collections[namespace + 'images'];
		//first run, so initialise stuff
		if(!images) {
			this.internal.collections[namespace + 'images'] = images = {};
			this.internal.events.subscribe('putResources', putResourcesCallback);
			this.internal.events.subscribe('putXobjectDict', putXObjectsDictCallback);
		}

		return images;
	}
	, getImageIndex = function(images) {
		var imageIndex = 0;

		if (images){
			// this is NOT the first time this method is ran on this instance of jsPDF object.
			imageIndex = Object.keys ?
			Object.keys(images).length :
			(function(o){
				var i = 0
				for (var e in o){if(o.hasOwnProperty(e)){ i++ }}
				return i
			})(images)
		}

		return imageIndex;
	}
	, notDefined = function(value) {
		return typeof value === 'undefined' || value === null;
	}
	, generateAliasFromData = function(data) {
		return typeof data === 'string' &amp;&amp; jsPDFAPI.sHashCode(data);
	}
	, doesNotSupportImageType = function(type) {
		return supported_image_types.indexOf(type) === -1;
	}
	, processMethodNotEnabled = function(type) {
		return typeof jsPDFAPI['process' + type.toUpperCase()] !== 'function';
	}
	, isDOMElement = function(object) {
		return typeof object === 'object' &amp;&amp; object.nodeType === 1;
	}
	, createDataURIFromElement = function(element, format, angle) {

		//if element is an image which uses data url defintion, just return the dataurl
		if (element.nodeName === 'IMG' &amp;&amp; element.hasAttribute('src')) {
			var src = ''+element.getAttribute('src');
			if (!angle &amp;&amp; src.indexOf('data:image/') === 0) return src;

			// only if the user doesn't care about a format
			if (!format &amp;&amp; /\.png(?:[?#].*)?$/i.test(src)) format = 'png';
		}

		if(element.nodeName === 'CANVAS') {
			var canvas = element;
		} else {
			var canvas = document.createElement('canvas');
			canvas.width = element.clientWidth || element.width;
			canvas.height = element.clientHeight || element.height;

			var ctx = canvas.getContext('2d');
			if (!ctx) {
				throw ('addImage requires canvas to be supported by browser.');
			}
			if (angle) {
				var x, y, b, c, s, w, h, to_radians = Math.PI/180, angleInRadians;

				if (typeof angle === 'object') {
					x = angle.x;
					y = angle.y;
					b = angle.bg;
					angle = angle.angle;
				}
				angleInRadians = angle*to_radians;
				c = Math.abs(Math.cos(angleInRadians));
				s = Math.abs(Math.sin(angleInRadians));
				w = canvas.width;
				h = canvas.height;
				canvas.width = h * s + w * c;
				canvas.height = h * c + w * s;

				if (isNaN(x)) x = canvas.width / 2;
				if (isNaN(y)) y = canvas.height / 2;

				ctx.clearRect(0,0,canvas.width, canvas.height);
				ctx.fillStyle = b || 'white';
				ctx.fillRect(0, 0, canvas.width, canvas.height);
				ctx.save();
				ctx.translate(x, y);
				ctx.rotate(angleInRadians);
				ctx.drawImage(element, -(w/2), -(h/2));
				ctx.rotate(-angleInRadians);
				ctx.translate(-x, -y);
				ctx.restore();
			} else {
				ctx.drawImage(element, 0, 0, canvas.width, canvas.height);
			}
		}
		return canvas.toDataURL((''+format).toLowerCase() == 'png' ? 'image/png' : 'image/jpeg');
	}
	,checkImagesForAlias = function(alias, images) {
		var cached_info;
		if(images) {
			for(var e in images) {
				if(alias === images[e].alias) {
					cached_info = images[e];
					break;
				}
			}
		}
		return cached_info;
	}
	,determineWidthAndHeight = function(w, h, info) {
		if (!w &amp;&amp; !h) {
			w = -96;
			h = -96;
		}
		if (w &lt; 0) {
			w = (-1) * info['w'] * 72 / w / this.internal.scaleFactor;
		}
		if (h &lt; 0) {
			h = (-1) * info['h'] * 72 / h / this.internal.scaleFactor;
		}
		if (w === 0) {
			w = h * info['w'] / info['h'];
		}
		if (h === 0) {
			h = w * info['h'] / info['w'];
		}

		return [w, h];
	}
	, writeImageToPDF = function(x, y, w, h, info, index, images) {
		var dims = determineWidthAndHeight.call(this, w, h, info),
			coord = this.internal.getCoordinateString,
			vcoord = this.internal.getVerticalCoordinateString;

		w = dims[0];
		h = dims[1];

		images[index] = info;

		this.internal.write(
			'q'
			, coord(w)
			, '0 0'
			, coord(h) // TODO: check if this should be shifted by vcoord
			, coord(x)
			, vcoord(y + h)
			, 'cm /I'+info['i']
			, 'Do Q'
		)
	};

	/**
	 * COLOR SPACES
	 */
	jsPDFAPI.color_spaces = {
		DEVICE_RGB:'DeviceRGB',
		DEVICE_GRAY:'DeviceGray',
		DEVICE_CMYK:'DeviceCMYK',
		CAL_GREY:'CalGray',
		CAL_RGB:'CalRGB',
		LAB:'Lab',
		ICC_BASED:'ICCBased',
		INDEXED:'Indexed',
		PATTERN:'Pattern',
		SEPERATION:'Seperation',
		DEVICE_N:'DeviceN'
	};

	/**
	 * DECODE METHODS
	 */
	jsPDFAPI.decode = {
		DCT_DECODE:'DCTDecode',
		FLATE_DECODE:'FlateDecode',
		LZW_DECODE:'LZWDecode',
		JPX_DECODE:'JPXDecode',
		JBIG2_DECODE:'JBIG2Decode',
		ASCII85_DECODE:'ASCII85Decode',
		ASCII_HEX_DECODE:'ASCIIHexDecode',
		RUN_LENGTH_DECODE:'RunLengthDecode',
		CCITT_FAX_DECODE:'CCITTFaxDecode'
	};

	/**
	 * IMAGE COMPRESSION TYPES
	 */
	jsPDFAPI.image_compression = {
		NONE: 'NONE',
		FAST: 'FAST',
		MEDIUM: 'MEDIUM',
		SLOW: 'SLOW'
	};

	jsPDFAPI.sHashCode = function(str) {
		return Array.prototype.reduce &amp;&amp; str.split("").reduce(function(a,b){a=((a&lt;&lt;5)-a)+b.charCodeAt(0);return a&amp;a},0);
	};

	jsPDFAPI.isString = function(object) {
		return typeof object === 'string';
	};

	/**
	 * Strips out and returns info from a valid base64 data URI
	 * @param {String[dataURI]} a valid data URI of format 'data:[&lt;MIME-type&gt;][;base64],&lt;data&gt;'
	 * @returns an Array containing the following
	 * [0] the complete data URI
	 * [1] &lt;MIME-type&gt;
	 * [2] format - the second part of the mime-type i.e 'png' in 'image/png'
	 * [4] &lt;data&gt;
	 */
	jsPDFAPI.extractInfoFromBase64DataURI = function(dataURI) {
		return /^data:([\w]+?\/([\w]+?));base64,(.+?)$/g.exec(dataURI);
	};

	/**
	 * Check to see if ArrayBuffer is supported
	 */
	jsPDFAPI.supportsArrayBuffer = function() {
		return typeof ArrayBuffer !== 'undefined' &amp;&amp; typeof Uint8Array !== 'undefined';
	};

	/**
	 * Tests supplied object to determine if ArrayBuffer
	 * @param {Object[object]}
	 */
	jsPDFAPI.isArrayBuffer = function(object) {
		if(!this.supportsArrayBuffer())
	        return false;
		return object instanceof ArrayBuffer;
	};

	/**
	 * Tests supplied object to determine if it implements the ArrayBufferView (TypedArray) interface
	 * @param {Object[object]}
	 */
	jsPDFAPI.isArrayBufferView = function(object) {
		if(!this.supportsArrayBuffer())
	        return false;
		if(typeof Uint32Array === 'undefined')
			return false;
		return (object instanceof Int8Array ||
				object instanceof Uint8Array ||
				(typeof Uint8ClampedArray !== 'undefined' &amp;&amp; object instanceof Uint8ClampedArray) ||
				object instanceof Int16Array ||
				object instanceof Uint16Array ||
				object instanceof Int32Array ||
				object instanceof Uint32Array ||
				object instanceof Float32Array ||
				object instanceof Float64Array );
	};

	/**
	 * Exactly what it says on the tin
	 */
	jsPDFAPI.binaryStringToUint8Array = function(binary_string) {
		/*
		 * not sure how efficient this will be will bigger files. Is there a native method?
		 */
		var len = binary_string.length;
	    var bytes = new Uint8Array( len );
	    for (var i = 0; i &lt; len; i++) {
	        bytes[i] = binary_string.charCodeAt(i);
	    }
	    return bytes;
	};

	/**
	 * @see this discussion
	 * http://stackoverflow.com/questions/6965107/converting-between-strings-and-arraybuffers
	 *
	 * As stated, i imagine the method below is highly inefficent for large files.
	 *
	 * Also of note from Mozilla,
	 *
	 * "However, this is slow and error-prone, due to the need for multiple conversions (especially if the binary data is not actually byte-format data, but, for example, 32-bit integers or floats)."
	 *
	 * https://developer.mozilla.org/en-US/Add-ons/Code_snippets/StringView
	 *
	 * Although i'm strugglig to see how StringView solves this issue? Doesn't appear to be a direct method for conversion?
	 *
	 * Async method using Blob and FileReader could be best, but i'm not sure how to fit it into the flow?
	 */
	jsPDFAPI.arrayBufferToBinaryString = function(buffer) {
		if(this.isArrayBuffer(buffer))
			buffer = new Uint8Array(buffer);

	    var binary_string = '';
	    var len = buffer.byteLength;
	    for (var i = 0; i &lt; len; i++) {
	        binary_string += String.fromCharCode(buffer[i]);
	    }
	    return binary_string;
	    /*
	     * Another solution is the method below - convert array buffer straight to base64 and then use atob
	     */
		//return atob(this.arrayBufferToBase64(buffer));
	};

	/**
	 * Converts an ArrayBuffer directly to base64
	 *
	 * Taken from here
	 *
	 * http://jsperf.com/encoding-xhr-image-data/31
	 *
	 * Need to test if this is a better solution for larger files
	 *
	 */
	jsPDFAPI.arrayBufferToBase64 = function(arrayBuffer) {
		var base64    = ''
		var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

		var bytes         = new Uint8Array(arrayBuffer)
		var byteLength    = bytes.byteLength
		var byteRemainder = byteLength % 3
		var mainLength    = byteLength - byteRemainder

		var a, b, c, d
		var chunk

		// Main loop deals with bytes in chunks of 3
		for (var i = 0; i &lt; mainLength; i = i + 3) {
			// Combine the three bytes into a single integer
			chunk = (bytes[i] &lt;&lt; 16) | (bytes[i + 1] &lt;&lt; 8) | bytes[i + 2]

			// Use bitmasks to extract 6-bit segments from the triplet
			a = (chunk &amp; 16515072) &gt;&gt; 18 // 16515072 = (2^6 - 1) &lt;&lt; 18
			b = (chunk &amp; 258048)   &gt;&gt; 12 // 258048   = (2^6 - 1) &lt;&lt; 12
			c = (chunk &amp; 4032)     &gt;&gt;  6 // 4032     = (2^6 - 1) &lt;&lt; 6
			d = chunk &amp; 63               // 63       = 2^6 - 1

			// Convert the raw binary segments to the appropriate ASCII encoding
			base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d]
		}

		// Deal with the remaining bytes and padding
		if (byteRemainder == 1) {
			chunk = bytes[mainLength]

			a = (chunk &amp; 252) &gt;&gt; 2 // 252 = (2^6 - 1) &lt;&lt; 2

			// Set the 4 least significant bits to zero
			b = (chunk &amp; 3)   &lt;&lt; 4 // 3   = 2^2 - 1

			base64 += encodings[a] + encodings[b] + '=='
		} else if (byteRemainder == 2) {
			chunk = (bytes[mainLength] &lt;&lt; 8) | bytes[mainLength + 1]

			a = (chunk &amp; 64512) &gt;&gt; 10 // 64512 = (2^6 - 1) &lt;&lt; 10
			b = (chunk &amp; 1008)  &gt;&gt;  4 // 1008  = (2^6 - 1) &lt;&lt; 4

			// Set the 2 least significant bits to zero
			c = (chunk &amp; 15)    &lt;&lt;  2 // 15    = 2^4 - 1

			base64 += encodings[a] + encodings[b] + encodings[c] + '='
		}

		return base64
	};

	jsPDFAPI.createImageInfo = function(data, wd, ht, cs, bpc, f, imageIndex, alias, dp, trns, pal, smask) {
		var info = {
				alias:alias,
				w : wd,
				h : ht,
				cs : cs,
				bpc : bpc,
				i : imageIndex,
				data : data
				// n: objectNumber will be added by putImage code
			};

		if(f) info.f = f;
		if(dp) info.dp = dp;
		if(trns) info.trns = trns;
		if(pal) info.pal = pal;
		if(smask) info.smask = smask;

		return info;
	};

	jsPDFAPI.addImage = function(imageData, format, x, y, w, h, alias, compression, rotation) {
		'use strict'

		if(typeof format !== 'string') {
			var tmp = h;
			h = w;
			w = y;
			y = x;
			x = format;
			format = tmp;
		}

		if (typeof imageData === 'object' &amp;&amp; !isDOMElement(imageData) &amp;&amp; "imageData" in imageData) {
			var options = imageData;

			imageData = options.imageData;
			format = options.format || format;
			x = options.x || x || 0;
			y = options.y || y || 0;
			w = options.w || w;
			h = options.h || h;
			alias = options.alias || alias;
			compression = options.compression || compression;
			rotation = options.rotation || options.angle || rotation;
		}

		if (isNaN(x) || isNaN(y))
		{
			console.error('jsPDF.addImage: Invalid coordinates', arguments);
			throw new Error('Invalid coordinates passed to jsPDF.addImage');
		}

		var images = getImages.call(this), info;

		if (!(info = checkImagesForAlias(imageData, images))) {
			var dataAsBinaryString;

			if(isDOMElement(imageData))
				imageData = createDataURIFromElement(imageData, format, rotation);

			if(notDefined(alias))
				alias = generateAliasFromData(imageData);

			if (!(info = checkImagesForAlias(alias, images))) {

				if(this.isString(imageData)) {

					var base64Info = this.extractInfoFromBase64DataURI(imageData);

					if(base64Info) {

						format = base64Info[2];
						imageData = atob(base64Info[3]);//convert to binary string

					} else {

						if (imageData.charCodeAt(0) === 0x89 &amp;&amp;
							imageData.charCodeAt(1) === 0x50 &amp;&amp;
							imageData.charCodeAt(2) === 0x4e &amp;&amp;
							imageData.charCodeAt(3) === 0x47  )  format = 'png';
					}
				}
				format = (format || 'JPEG').toLowerCase();

				if(doesNotSupportImageType(format))
					throw new Error('addImage currently only supports formats ' + supported_image_types + ', not \''+format+'\'');

				if(processMethodNotEnabled(format))
					throw new Error('please ensure that the plugin for \''+format+'\' support is added');

				/**
				 * need to test if it's more efficent to convert all binary strings
				 * to TypedArray - or should we just leave and process as string?
				 */
				if(this.supportsArrayBuffer()) {
					dataAsBinaryString = imageData;
					imageData = this.binaryStringToUint8Array(imageData);
				}

				info = this['process' + format.toUpperCase()](
					imageData,
					getImageIndex(images),
					alias,
					checkCompressValue(compression),
					dataAsBinaryString
				);

				if(!info)
					throw new Error('An unkwown error occurred whilst processing the image');
			}
		}

		writeImageToPDF.call(this, x, y, w, h, info, info.i, images);

		return this
	};

	/**
	 * JPEG SUPPORT
	 **/

	//takes a string imgData containing the raw bytes of
	//a jpeg image and returns [width, height]
	//Algorithm from: http://www.64lines.com/jpeg-width-height
	var getJpegSize = function(imgData) {
		'use strict'
		var width, height, numcomponents;
		// Verify we have a valid jpeg header 0xff,0xd8,0xff,0xe0,?,?,'J','F','I','F',0x00
		if (!imgData.charCodeAt(0) === 0xff ||
			!imgData.charCodeAt(1) === 0xd8 ||
			!imgData.charCodeAt(2) === 0xff ||
			!imgData.charCodeAt(3) === 0xe0 ||
			!imgData.charCodeAt(6) === 'J'.charCodeAt(0) ||
			!imgData.charCodeAt(7) === 'F'.charCodeAt(0) ||
			!imgData.charCodeAt(8) === 'I'.charCodeAt(0) ||
			!imgData.charCodeAt(9) === 'F'.charCodeAt(0) ||
			!imgData.charCodeAt(10) === 0x00) {
				throw new Error('getJpegSize requires a binary string jpeg file')
		}
		var blockLength = imgData.charCodeAt(4)*256 + imgData.charCodeAt(5);
		var i = 4, len = imgData.length;
		while ( i &lt; len ) {
			i += blockLength;
			if (imgData.charCodeAt(i) !== 0xff) {
				throw new Error('getJpegSize could not find the size of the image');
			}
			if (imgData.charCodeAt(i+1) === 0xc0 || //(SOF) Huffman  - Baseline DCT
			    imgData.charCodeAt(i+1) === 0xc1 || //(SOF) Huffman  - Extended sequential DCT
			    imgData.charCodeAt(i+1) === 0xc2 || // Progressive DCT (SOF2)
			    imgData.charCodeAt(i+1) === 0xc3 || // Spatial (sequential) lossless (SOF3)
			    imgData.charCodeAt(i+1) === 0xc4 || // Differential sequential DCT (SOF5)
			    imgData.charCodeAt(i+1) === 0xc5 || // Differential progressive DCT (SOF6)
			    imgData.charCodeAt(i+1) === 0xc6 || // Differential spatial (SOF7)
			    imgData.charCodeAt(i+1) === 0xc7) {
				height = imgData.charCodeAt(i+5)*256 + imgData.charCodeAt(i+6);
				width = imgData.charCodeAt(i+7)*256 + imgData.charCodeAt(i+8);
                numcomponents = imgData.charCodeAt(i+9);
				return [width, height, numcomponents];
			} else {
				i += 2;
				blockLength = imgData.charCodeAt(i)*256 + imgData.charCodeAt(i+1)
			}
		}
	}
	, getJpegSizeFromBytes = function(data) {

		var hdr = (data[0] &lt;&lt; 8) | data[1];

		if(hdr !== 0xFFD8)
			throw new Error('Supplied data is not a JPEG');

		var len = data.length,
			block = (data[4] &lt;&lt; 8) + data[5],
			pos = 4,
			bytes, width, height, numcomponents;

		while(pos &lt; len) {
			pos += block;
			bytes = readBytes(data, pos);
			block = (bytes[2] &lt;&lt; 8) + bytes[3];
			if((bytes[1] === 0xC0 || bytes[1] === 0xC2) &amp;&amp; bytes[0] === 0xFF &amp;&amp; block &gt; 7) {
				bytes = readBytes(data, pos + 5);
				width = (bytes[2] &lt;&lt; 8) + bytes[3];
				height = (bytes[0] &lt;&lt; 8) + bytes[1];
                numcomponents = bytes[4];
				return {width:width, height:height, numcomponents: numcomponents};
			}

			pos+=2;
		}

		throw new Error('getJpegSizeFromBytes could not find the size of the image');
	}
	, readBytes = function(data, offset) {
		return data.subarray(offset, offset+ 5);
	};

	jsPDFAPI.processJPEG = function(data, index, alias, compression, dataAsBinaryString) {
		'use strict'
		var colorSpace = this.color_spaces.DEVICE_RGB,
			filter = this.decode.DCT_DECODE,
			bpc = 8,
			dims;

		if(this.isString(data)) {
			dims = getJpegSize(data);
			return this.createImageInfo(data, dims[0], dims[1], dims[3] == 1 ? this.color_spaces.DEVICE_GRAY:colorSpace, bpc, filter, index, alias);
		}

		if(this.isArrayBuffer(data))
			data = new Uint8Array(data);

		if(this.isArrayBufferView(data)) {

			dims = getJpegSizeFromBytes(data);

			// if we already have a stored binary string rep use that
			data = dataAsBinaryString || this.arrayBufferToBinaryString(data);

			return this.createImageInfo(data, dims.width, dims.height, dims.numcomponents == 1 ? this.color_spaces.DEVICE_GRAY:colorSpace, bpc, filter, index, alias);
		}

		return null;
	};

	jsPDFAPI.processJPG = function(/*data, index, alias, compression, dataAsBinaryString*/) {
		return this.processJPEG.apply(this, arguments);
	}

})(jsPDF.API);
(function (jsPDFAPI) {
	'use strict';

	jsPDFAPI.autoPrint = function () {
		'use strict'
		var refAutoPrintTag;

		this.internal.events.subscribe('postPutResources', function () {
			refAutoPrintTag = this.internal.newObject()
				this.internal.write("&lt;&lt; /S/Named /Type/Action /N/Print &gt;&gt;", "endobj");
		});

		this.internal.events.subscribe("putCatalog", function () {
			this.internal.write("/OpenAction " + refAutoPrintTag + " 0" + " R");
		});
		return this;
	};
})(jsPDF.API);
/** ====================================================================
 * jsPDF Cell plugin
 * Copyright (c) 2013 Youssef Beddad, youssef.beddad@gmail.com
 *               2013 Eduardo Menezes de Morais, eduardo.morais@usp.br
 *               2013 Lee Driscoll, https://github.com/lsdriscoll
 *               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
 *               2014 James Hall, james@parall.ax
 *               2014 Diego Casorran, https://github.com/diegocr
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

(function (jsPDFAPI) {
    'use strict';
    /*jslint browser:true */
    /*global document: false, jsPDF */

    var fontName,
        fontSize,
        fontStyle,
        padding = 3,
        margin = 13,
        headerFunction,
        lastCellPos = { x: undefined, y: undefined, w: undefined, h: undefined, ln: undefined },
        pages = 1,
        setLastCellPosition = function (x, y, w, h, ln) {
            lastCellPos = { 'x': x, 'y': y, 'w': w, 'h': h, 'ln': ln };
        },
        getLastCellPosition = function () {
            return lastCellPos;
        },
        NO_MARGINS = {left:0, top:0, bottom: 0};

    jsPDFAPI.setHeaderFunction = function (func) {
        headerFunction = func;
    };

    jsPDFAPI.getTextDimensions = function (txt) {
        fontName = this.internal.getFont().fontName;
        fontSize = this.table_font_size || this.internal.getFontSize();
        fontStyle = this.internal.getFont().fontStyle;
        // 1 pixel = 0.264583 mm and 1 mm = 72/25.4 point
        var px2pt = 0.264583 * 72 / 25.4,
            dimensions,
            text;

        text = document.createElement('font');
        text.id = "jsPDFCell";
        text.style.fontStyle = fontStyle;
        text.style.fontName = fontName;
        text.style.fontSize = fontSize + 'pt';
        text.textContent = txt;

        document.body.appendChild(text);

        dimensions = { w: (text.offsetWidth + 1) * px2pt, h: (text.offsetHeight + 1) * px2pt};

        document.body.removeChild(text);

        return dimensions;
    };

    jsPDFAPI.cellAddPage = function () {
        var margins = this.margins || NO_MARGINS;

        this.addPage();

        setLastCellPosition(margins.left, margins.top, undefined, undefined);
        //setLastCellPosition(undefined, undefined, undefined, undefined, undefined);
        pages += 1;
    };

    jsPDFAPI.cellInitialize = function () {
        lastCellPos = { x: undefined, y: undefined, w: undefined, h: undefined, ln: undefined };
        pages = 1;
    };

    jsPDFAPI.cell = function (x, y, w, h, txt, ln, align) {
        var curCell = getLastCellPosition();

        // If this is not the first cell, we must change its position
        if (curCell.ln !== undefined) {
            if (curCell.ln === ln) {
                //Same line
                x = curCell.x + curCell.w;
                y = curCell.y;
            } else {
                //New line
                var margins = this.margins || NO_MARGINS;
                if ((curCell.y + curCell.h + h + margin) &gt;= this.internal.pageSize.height - margins.bottom) {
                    this.cellAddPage();
                    if (this.printHeaders &amp;&amp; this.tableHeaderRow) {
                        this.printHeaderRow(ln, true);
                    }
                }
                //We ignore the passed y: the lines may have diferent heights
                y = (getLastCellPosition().y + getLastCellPosition().h);

            }
        }

        if (txt[0] !== undefined) {
            if (this.printingHeaderRow) {
                this.rect(x, y, w, h, 'FD');
            } else {
                this.rect(x, y, w, h);
            }
            if (align === 'right') {
                if (txt instanceof Array) {
                    for(var i = 0; i&lt;txt.length; i++) {
                        var currentLine = txt[i];
                        var textSize = this.getStringUnitWidth(currentLine) * this.internal.getFontSize();
                        this.text(currentLine, x + w - textSize - padding, y + this.internal.getLineHeight()*(i+1));
                    }
                }
            } else {
                this.text(txt, x + padding, y + this.internal.getLineHeight());
            }
        }
        setLastCellPosition(x, y, w, h, ln);
        return this;
    };

    /**
     * Return the maximum value from an array
     * @param array
     * @param comparisonFn
     * @returns {*}
     */
    jsPDFAPI.arrayMax = function (array, comparisonFn) {
        var max = array[0],
            i,
            ln,
            item;

        for (i = 0, ln = array.length; i &lt; ln; i += 1) {
            item = array[i];

            if (comparisonFn) {
                if (comparisonFn(max, item) === -1) {
                    max = item;
                }
            } else {
                if (item &gt; max) {
                    max = item;
                }
            }
        }

        return max;
    };

    /**
     * Create a table from a set of data.
     * @param {Integer} [x] : left-position for top-left corner of table
     * @param {Integer} [y] top-position for top-left corner of table
     * @param {Object[]} [data] As array of objects containing key-value pairs corresponding to a row of data.
     * @param {String[]} [headers] Omit or null to auto-generate headers at a performance cost

     * @param {Object} [config.printHeaders] True to print column headers at the top of every page
     * @param {Object} [config.autoSize] True to dynamically set the column widths to match the widest cell value
     * @param {Object} [config.margins] margin values for left, top, bottom, and width
     * @param {Object} [config.fontSize] Integer fontSize to use (optional)
     */

    jsPDFAPI.table = function (x,y, data, headers, config) {
        if (!data) {
            throw 'No data for PDF table';
        }

        var headerNames = [],
            headerPrompts = [],
            header,
            i,
            ln,
            cln,
            columnMatrix = {},
            columnWidths = {},
            columnData,
            column,
            columnMinWidths = [],
            j,
            tableHeaderConfigs = [],
            model,
            jln,
            func,

        //set up defaults. If a value is provided in config, defaults will be overwritten:
           autoSize        = false,
           printHeaders    = true,
           fontSize        = 12,
           margins         = NO_MARGINS;

           margins.width = this.internal.pageSize.width;

        if (config) {
        //override config defaults if the user has specified non-default behavior:
            if(config.autoSize === true) {
                autoSize = true;
            }
            if(config.printHeaders === false) {
                printHeaders = false;
            }
            if(config.fontSize){
                fontSize = config.fontSize;
            }
            if(config.margins){
                margins = config.margins;
            }
        }

        /**
         * @property {Number} lnMod
         * Keep track of the current line number modifier used when creating cells
         */
        this.lnMod = 0;
        lastCellPos = { x: undefined, y: undefined, w: undefined, h: undefined, ln: undefined },
        pages = 1;

        this.printHeaders = printHeaders;
        this.margins = margins;
        this.setFontSize(fontSize);
        this.table_font_size = fontSize;

        // Set header values
        if (headers === undefined || (headers === null)) {
            // No headers defined so we derive from data
            headerNames = Object.keys(data[0]);

        } else if (headers[0] &amp;&amp; (typeof headers[0] !== 'string')) {
            var px2pt = 0.264583 * 72 / 25.4;

            // Split header configs into names and prompts
            for (i = 0, ln = headers.length; i &lt; ln; i += 1) {
                header = headers[i];
                headerNames.push(header.name);
                headerPrompts.push(header.prompt);
                columnWidths[header.name] = header.width *px2pt;
            }

        } else {
            headerNames = headers;
        }

        if (autoSize) {
            // Create a matrix of columns e.g., {column_title: [row1_Record, row2_Record]}
            func = function (rec) {
                return rec[header];
            };

            for (i = 0, ln = headerNames.length; i &lt; ln; i += 1) {
                header = headerNames[i];

                columnMatrix[header] = data.map(
                    func
                );

                // get header width
                columnMinWidths.push(this.getTextDimensions(headerPrompts[i] || header).w);
                column = columnMatrix[header];

                // get cell widths
                for (j = 0, cln = column.length; j &lt; cln; j += 1) {
                    columnData = column[j];
                    columnMinWidths.push(this.getTextDimensions(columnData).w);
                }

                // get final column width
                columnWidths[header] = jsPDFAPI.arrayMax(columnMinWidths);
            }
        }

        // -- Construct the table

        if (printHeaders) {
            var lineHeight = this.calculateLineHeight(headerNames, columnWidths, headerPrompts.length?headerPrompts:headerNames);

            // Construct the header row
            for (i = 0, ln = headerNames.length; i &lt; ln; i += 1) {
                header = headerNames[i];
                tableHeaderConfigs.push([x, y, columnWidths[header], lineHeight, String(headerPrompts.length ? headerPrompts[i] : header)]);
            }

            // Store the table header config
            this.setTableHeaderRow(tableHeaderConfigs);

            // Print the header for the start of the table
            this.printHeaderRow(1, false);
        }

        // Construct the data rows
        for (i = 0, ln = data.length; i &lt; ln; i += 1) {
            var lineHeight;
            model = data[i];
            lineHeight = this.calculateLineHeight(headerNames, columnWidths, model);

            for (j = 0, jln = headerNames.length; j &lt; jln; j += 1) {
                header = headerNames[j];
                this.cell(x, y, columnWidths[header], lineHeight, model[header], i + 2, header.align);
            }
        }
        this.lastCellPos = lastCellPos;
        this.table_x = x;
        this.table_y = y;
        return this;
    };
    /**
     * Calculate the height for containing the highest column
     * @param {String[]} headerNames is the header, used as keys to the data
     * @param {Integer[]} columnWidths is size of each column
     * @param {Object[]} model is the line of data we want to calculate the height of
     */
    jsPDFAPI.calculateLineHeight = function (headerNames, columnWidths, model) {
        var header, lineHeight = 0;
        for (var j = 0; j &lt; headerNames.length; j++) {
            header = headerNames[j];
            model[header] = this.splitTextToSize(String(model[header]), columnWidths[header] - padding);
            var h = this.internal.getLineHeight() * model[header].length + padding;
            if (h &gt; lineHeight)
                lineHeight = h;
        }
        return lineHeight;
    };

    /**
     * Store the config for outputting a table header
     * @param {Object[]} config
     * An array of cell configs that would define a header row: Each config matches the config used by jsPDFAPI.cell
     * except the ln parameter is excluded
     */
    jsPDFAPI.setTableHeaderRow = function (config) {
        this.tableHeaderRow = config;
    };

    /**
     * Output the store header row
     * @param lineNumber The line number to output the header at
     */
    jsPDFAPI.printHeaderRow = function (lineNumber, new_page) {
        if (!this.tableHeaderRow) {
            throw 'Property tableHeaderRow does not exist.';
        }

        var tableHeaderCell,
            tmpArray,
            i,
            ln;

        this.printingHeaderRow = true;
        if (headerFunction !== undefined) {
            var position = headerFunction(this, pages);
            setLastCellPosition(position[0], position[1], position[2], position[3], -1);
        }
        this.setFontStyle('bold');
        var tempHeaderConf = [];
        for (i = 0, ln = this.tableHeaderRow.length; i &lt; ln; i += 1) {
            this.setFillColor(200,200,200);

            tableHeaderCell = this.tableHeaderRow[i];
            if (new_page) {
                tableHeaderCell[1] = this.margins &amp;&amp; this.margins.top || 0;
                tempHeaderConf.push(tableHeaderCell);
            }
            tmpArray = [].concat(tableHeaderCell);
            this.cell.apply(this, tmpArray.concat(lineNumber));
        }
        if (tempHeaderConf.length &gt; 0){
            this.setTableHeaderRow(tempHeaderConf);
        }
        this.setFontStyle('normal');
        this.printingHeaderRow = false;
    };

})(jsPDF.API);
/** @preserve
 * jsPDF fromHTML plugin. BETA stage. API subject to change. Needs browser
 * Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
 *               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
 *               2014 Diego Casorran, https://github.com/diegocr
 *               2014 Daniel Husar, https://github.com/danielhusar
 *               2014 Wolfgang Gassler, https://github.com/woolfg
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

(function (jsPDFAPI) {
	var clone,
	DrillForContent,
	FontNameDB,
	FontStyleMap,
	FontWeightMap,
	FloatMap,
	ClearMap,
	GetCSS,
	PurgeWhiteSpace,
	Renderer,
	ResolveFont,
	ResolveUnitedNumber,
	UnitedNumberMap,
	elementHandledElsewhere,
	images,
	loadImgs,
	checkForFooter,
	process,
	tableToJson;
	clone = (function () {
		return function (obj) {
			Clone.prototype = obj;
			return new Clone()
		};
		function Clone() {}
	})();
	PurgeWhiteSpace = function (array) {
		var fragment,
		i,
		l,
		lTrimmed,
		r,
		rTrimmed,
		trailingSpace;
		i = 0;
		l = array.length;
		fragment = void 0;
		lTrimmed = false;
		rTrimmed = false;
		while (!lTrimmed &amp;&amp; i !== l) {
			fragment = array[i] = array[i].trimLeft();
			if (fragment) {
				lTrimmed = true;
			}
			i++;
		}
		i = l - 1;
		while (l &amp;&amp; !rTrimmed &amp;&amp; i !== -1) {
			fragment = array[i] = array[i].trimRight();
			if (fragment) {
				rTrimmed = true;
			}
			i--;
		}
		r = /\s+$/g;
		trailingSpace = true;
		i = 0;
		while (i !== l) {
			fragment = array[i].replace(/\s+/g, " ");
			if (trailingSpace) {
				fragment = fragment.trimLeft();
			}
			if (fragment) {
				trailingSpace = r.test(fragment);
			}
			array[i] = fragment;
			i++;
		}
		return array;
	};
	Renderer = function (pdf, x, y, settings) {
		this.pdf = pdf;
		this.x = x;
		this.y = y;
		this.settings = settings;
		//list of functions which are called after each element-rendering process
		this.watchFunctions = [];
		this.init();
		return this;
	};
	ResolveFont = function (css_font_family_string) {
		var name,
		part,
		parts;
		name = void 0;
		parts = css_font_family_string.split(",");
		part = parts.shift();
		while (!name &amp;&amp; part) {
			name = FontNameDB[part.trim().toLowerCase()];
			part = parts.shift();
		}
		return name;
	};
	ResolveUnitedNumber = function (css_line_height_string) {

		//IE8 issues
		css_line_height_string = css_line_height_string === "auto" ? "0px" : css_line_height_string;
		if (css_line_height_string.indexOf("em") &gt; -1 &amp;&amp; !isNaN(Number(css_line_height_string.replace("em", "")))) {
			css_line_height_string = Number(css_line_height_string.replace("em", "")) * 18.719 + "px";
		}
		if (css_line_height_string.indexOf("pt") &gt; -1 &amp;&amp; !isNaN(Number(css_line_height_string.replace("pt", "")))) {
			css_line_height_string = Number(css_line_height_string.replace("pt", "")) * 1.333 + "px";
		}

		var normal,
		undef,
		value;
		undef = void 0;
		normal = 16.00;
		value = UnitedNumberMap[css_line_height_string];
		if (value) {
			return value;
		}
		value = {
			"xx-small"  :  9,
			"x-small"   : 11,
			small       : 13,
			medium      : 16,
			large       : 19,
			"x-large"   : 23,
			"xx-large"  : 28,
			auto        :  0
		}[{ css_line_height_string : css_line_height_string }];

		if (value !== undef) {
			return UnitedNumberMap[css_line_height_string] = value / normal;
		}
		if (value = parseFloat(css_line_height_string)) {
			return UnitedNumberMap[css_line_height_string] = value / normal;
		}
		value = css_line_height_string.match(/([\d\.]+)(px)/);
		if (value.length === 3) {
			return UnitedNumberMap[css_line_height_string] = parseFloat(value[1]) / normal;
		}
		return UnitedNumberMap[css_line_height_string] = 1;
	};
	GetCSS = function (element) {
		var css,tmp,computedCSSElement;
		computedCSSElement = (function (el) {
			var compCSS;
			compCSS = (function (el) {
				if (document.defaultView &amp;&amp; document.defaultView.getComputedStyle) {
					return document.defaultView.getComputedStyle(el, null);
				} else if (el.currentStyle) {
					return el.currentStyle;
				} else {
					return el.style;
				}
			})(el);
			return function (prop) {
				prop = prop.replace(/-\D/g, function (match) {
					return match.charAt(1).toUpperCase();
				});
				return compCSS[prop];
			};
		})(element);
		css = {};
		tmp = void 0;
		css["font-family"] = ResolveFont(computedCSSElement("font-family")) || "times";
		css["font-style"] = FontStyleMap[computedCSSElement("font-style")] || "normal";
		css["text-align"] = TextAlignMap[computedCSSElement("text-align")] || "left";
		tmp = FontWeightMap[computedCSSElement("font-weight")] || "normal";
		if (tmp === "bold") {
			if (css["font-style"] === "normal") {
				css["font-style"] = tmp;
			} else {
				css["font-style"] = tmp + css["font-style"];
			}
		}
		css["font-size"] = ResolveUnitedNumber(computedCSSElement("font-size")) || 1;
		css["line-height"] = ResolveUnitedNumber(computedCSSElement("line-height")) || 1;
		css["display"] = (computedCSSElement("display") === "inline" ? "inline" : "block");

		tmp = (css["display"] === "block");
		css["margin-top"]     = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("margin-top"))     || 0;
		css["margin-bottom"]  = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("margin-bottom"))  || 0;
		css["padding-top"]    = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("padding-top"))    || 0;
		css["padding-bottom"] = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("padding-bottom")) || 0;
		css["margin-left"]    = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("margin-left"))    || 0;
		css["margin-right"]   = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("margin-right"))   || 0;
		css["padding-left"]   = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("padding-left"))   || 0;
		css["padding-right"]  = tmp &amp;&amp; ResolveUnitedNumber(computedCSSElement("padding-right"))  || 0;

		//float and clearing of floats
		css["float"] = FloatMap[computedCSSElement("cssFloat")] || "none";
		css["clear"] = ClearMap[computedCSSElement("clear")] || "none";
		return css;
	};
	elementHandledElsewhere = function (element, renderer, elementHandlers) {
		var handlers,
		i,
		isHandledElsewhere,
		l,
		t;
		isHandledElsewhere = false;
		i = void 0;
		l = void 0;
		t = void 0;
		handlers = elementHandlers["#" + element.id];
		if (handlers) {
			if (typeof handlers === "function") {
				isHandledElsewhere = handlers(element, renderer);
			} else {
				i = 0;
				l = handlers.length;
				while (!isHandledElsewhere &amp;&amp; i !== l) {
					isHandledElsewhere = handlers[i](element, renderer);
					i++;
				}
			}
		}
		handlers = elementHandlers[element.nodeName];
		if (!isHandledElsewhere &amp;&amp; handlers) {
			if (typeof handlers === "function") {
				isHandledElsewhere = handlers(element, renderer);
			} else {
				i = 0;
				l = handlers.length;
				while (!isHandledElsewhere &amp;&amp; i !== l) {
					isHandledElsewhere = handlers[i](element, renderer);
					i++;
				}
			}
		}
		return isHandledElsewhere;
	};
	tableToJson = function (table, renderer) {
		var data,
		headers,
		i,
		j,
		rowData,
		tableRow,
		table_obj,
		table_with,
		cell,
		l;
		data = [];
		headers = [];
		i = 0;
		l = table.rows[0].cells.length;
		table_with = table.clientWidth;
		while (i &lt; l) {
			cell = table.rows[0].cells[i];
			headers[i] = {
				name : cell.textContent.toLowerCase().replace(/\s+/g, ''),
				prompt : cell.textContent.replace(/\r?\n/g, ''),
				width : (cell.clientWidth / table_with) * renderer.pdf.internal.pageSize.width
			};
			i++;
		}
		i = 1;
		while (i &lt; table.rows.length) {
			tableRow = table.rows[i];
			rowData = {};
			j = 0;
			while (j &lt; tableRow.cells.length) {
				rowData[headers[j].name] = tableRow.cells[j].textContent.replace(/\r?\n/g, '');
				j++;
			}
			data.push(rowData);
			i++;
		}
		return table_obj = {
			rows : data,
			headers : headers
		};
	};
	var SkipNode = {
		SCRIPT   : 1,
		STYLE    : 1,
		NOSCRIPT : 1,
		OBJECT   : 1,
		EMBED    : 1,
		SELECT   : 1
	};
	var listCount = 1;
	DrillForContent = function (element, renderer, elementHandlers) {
		var cn,
		cns,
		fragmentCSS,
		i,
		isBlock,
		l,
		px2pt,
		table2json,
		cb;
		cns = element.childNodes;
		cn = void 0;
		fragmentCSS = GetCSS(element);
		isBlock = fragmentCSS.display === "block";
		if (isBlock) {
			renderer.setBlockBoundary();
			renderer.setBlockStyle(fragmentCSS);
		}
		px2pt = 0.264583 * 72 / 25.4;
		i = 0;
		l = cns.length;
		while (i &lt; l) {
			cn = cns[i];
			if (typeof cn === "object") {

				//execute all watcher functions to e.g. reset floating
				renderer.executeWatchFunctions(cn);

				/*** HEADER rendering **/
				if (cn.nodeType === 1 &amp;&amp; cn.nodeName === 'HEADER') {
					var header = cn;
					//store old top margin
					var oldMarginTop = renderer.pdf.margins_doc.top;
					//subscribe for new page event and render header first on every page
					renderer.pdf.internal.events.subscribe('addPage', function (pageInfo) {
						//set current y position to old margin
						renderer.y = oldMarginTop;
						//render all child nodes of the header element
						DrillForContent(header, renderer, elementHandlers);
						//set margin to old margin + rendered header + 10 space to prevent overlapping
						//important for other plugins (e.g. table) to start rendering at correct position after header
						renderer.pdf.margins_doc.top = renderer.y + 10;
						renderer.y += 10;
					}, false);
				}

				if (cn.nodeType === 8 &amp;&amp; cn.nodeName === "#comment") {
					if (~cn.textContent.indexOf("ADD_PAGE")) {
						renderer.pdf.addPage();
						renderer.y = renderer.pdf.margins_doc.top;
					}

				} else if (cn.nodeType === 1 &amp;&amp; !SkipNode[cn.nodeName]) {
					/*** IMAGE RENDERING ***/
					var cached_image;
					if (cn.nodeName === "IMG") {
						var url = cn.getAttribute("src");
						cached_image = images[renderer.pdf.sHashCode(url) || url];
					}
					if (cached_image) {
						if ((renderer.pdf.internal.pageSize.height - renderer.pdf.margins_doc.bottom &lt; renderer.y + cn.height) &amp;&amp; (renderer.y &gt; renderer.pdf.margins_doc.top)) {
							renderer.pdf.addPage();
							renderer.y = renderer.pdf.margins_doc.top;
							//check if we have to set back some values due to e.g. header rendering for new page
							renderer.executeWatchFunctions(cn);
						}

						var imagesCSS = GetCSS(cn);
						var imageX = renderer.x;
						var fontToUnitRatio = 12 / renderer.pdf.internal.scaleFactor;

						//define additional paddings, margins which have to be taken into account for margin calculations
						var additionalSpaceLeft = (imagesCSS["margin-left"] + imagesCSS["padding-left"])*fontToUnitRatio;
						var additionalSpaceRight = (imagesCSS["margin-right"] + imagesCSS["padding-right"])*fontToUnitRatio;
						var additionalSpaceTop = (imagesCSS["margin-top"] + imagesCSS["padding-top"])*fontToUnitRatio;
						var additionalSpaceBottom = (imagesCSS["margin-bottom"] + imagesCSS["padding-bottom"])*fontToUnitRatio;

						//if float is set to right, move the image to the right border
						//add space if margin is set
						if (imagesCSS['float'] !== undefined &amp;&amp; imagesCSS['float'] === 'right') {
							imageX += renderer.settings.width - cn.width - additionalSpaceRight;
						} else {
							imageX +=  additionalSpaceLeft;
						}

						renderer.pdf.addImage(cached_image, imageX, renderer.y + additionalSpaceTop, cn.width, cn.height);
						cached_image = undefined;
						//if the float prop is specified we have to float the text around the image
						if (imagesCSS['float'] === 'right' || imagesCSS['float'] === 'left') {
							//add functiont to set back coordinates after image rendering
							renderer.watchFunctions.push((function(diffX , thresholdY, diffWidth, el) {
								//undo drawing box adaptions which were set by floating
								if (renderer.y &gt;= thresholdY) {
									renderer.x += diffX;
									renderer.settings.width += diffWidth;
									return true;
								} else if(el &amp;&amp; el.nodeType === 1 &amp;&amp; !SkipNode[el.nodeName] &amp;&amp; renderer.x+el.width &gt; (renderer.pdf.margins_doc.left + renderer.pdf.margins_doc.width)) {
									renderer.x += diffX;
									renderer.y = thresholdY;
									renderer.settings.width += diffWidth;
									return true;
								} else {
									return false;
								}
							}).bind(this, (imagesCSS['float'] === 'left') ? -cn.width-additionalSpaceLeft-additionalSpaceRight : 0, renderer.y+cn.height+additionalSpaceTop+additionalSpaceBottom, cn.width));
							//reset floating by clear:both divs
							//just set cursorY after the floating element
							renderer.watchFunctions.push((function(yPositionAfterFloating, pages, el) {
								if (renderer.y &lt; yPositionAfterFloating &amp;&amp; pages === renderer.pdf.internal.getNumberOfPages()) {
									if (el.nodeType === 1 &amp;&amp; GetCSS(el).clear === 'both') {
										renderer.y = yPositionAfterFloating;
										return true;
									} else {
										return false;
									}
								} else {
									return true;
								}
							}).bind(this, renderer.y+cn.height, renderer.pdf.internal.getNumberOfPages()));

							//if floating is set we decrease the available width by the image width
							renderer.settings.width -= cn.width+additionalSpaceLeft+additionalSpaceRight;
							//if left just add the image width to the X coordinate
							if (imagesCSS['float'] === 'left') {
								renderer.x += cn.width+additionalSpaceLeft+additionalSpaceRight;
							}
						} else {
						//if no floating is set, move the rendering cursor after the image height
							renderer.y += cn.height + additionalSpaceBottom;
						}

					/*** TABLE RENDERING ***/
					} else if (cn.nodeName === "TABLE") {
						table2json = tableToJson(cn, renderer);
						renderer.y += 10;
						renderer.pdf.table(renderer.x, renderer.y, table2json.rows, table2json.headers, {
							autoSize : false,
							printHeaders : true,
							margins : renderer.pdf.margins_doc
						});
						renderer.y = renderer.pdf.lastCellPos.y + renderer.pdf.lastCellPos.h + 20;
					} else if (cn.nodeName === "OL" || cn.nodeName === "UL") {
						listCount = 1;
						if (!elementHandledElsewhere(cn, renderer, elementHandlers)) {
							DrillForContent(cn, renderer, elementHandlers);
						}
						renderer.y += 10;
					} else if (cn.nodeName === "LI") {
						var temp = renderer.x;
						renderer.x += cn.parentNode.nodeName === "UL" ? 22 : 10;
						renderer.y += 3;
						if (!elementHandledElsewhere(cn, renderer, elementHandlers)) {
							DrillForContent(cn, renderer, elementHandlers);
						}
						renderer.x = temp;
					} else if (cn.nodeName === "BR") {
						renderer.y += fragmentCSS["font-size"] * renderer.pdf.internal.scaleFactor;
					} else {
						if (!elementHandledElsewhere(cn, renderer, elementHandlers)) {
							DrillForContent(cn, renderer, elementHandlers);
						}
					}
				} else if (cn.nodeType === 3) {
					var value = cn.nodeValue;
					if (cn.nodeValue &amp;&amp; cn.parentNode.nodeName === "LI") {
						if (cn.parentNode.parentNode.nodeName === "OL") {
							value = listCount++ + '. ' + value;
						} else {
							var fontPx = fragmentCSS["font-size"] * 16;
							var radius = 2;
							if (fontPx &gt; 20) {
								radius = 3;
							}
							cb = function (x, y) {
								this.pdf.circle(x, y, radius, 'FD');
							};
						}
					}
					renderer.addText(value, fragmentCSS);
				} else if (typeof cn === "string") {
					renderer.addText(cn, fragmentCSS);
				}
			}
			i++;
		}

		if (isBlock) {
			return renderer.setBlockBoundary(cb);
		}
	};
	images = {};
	loadImgs = function (element, renderer, elementHandlers, cb) {
		var imgs = element.getElementsByTagName('img'),
		l = imgs.length, found_images,
		x = 0;
		function done() {
			renderer.pdf.internal.events.publish('imagesLoaded');
			cb(found_images);
		}
		function loadImage(url, width, height) {
			if (!url)
				return;
			var img = new Image();
			found_images = ++x;
			img.crossOrigin = '';
			img.onerror = img.onload = function () {
				if(img.complete) {
					//to support data urls in images, set width and height
					//as those values are not recognized automatically
					if (img.src.indexOf('data:image/') === 0) {
						img.width = width || img.width || 0;
						img.height = height || img.height || 0;
					}
					//if valid image add to known images array
					if (img.width + img.height) {
						var hash = renderer.pdf.sHashCode(url) || url;
						images[hash] = images[hash] || img;
					}
				}
				if(!--x) {
					done();
				}
			};
			img.src = url;
		}
		while (l--)
			loadImage(imgs[l].getAttribute("src"),imgs[l].width,imgs[l].height);
		return x || done();
	};
	checkForFooter = function (elem, renderer, elementHandlers) {
		//check if we can found a &lt;footer&gt; element
		var footer = elem.getElementsByTagName("footer");
		if (footer.length &gt; 0) {

			footer = footer[0];

			//bad hack to get height of footer
			//creat dummy out and check new y after fake rendering
			var oldOut = renderer.pdf.internal.write;
			var oldY = renderer.y;
			renderer.pdf.internal.write = function () {};
			DrillForContent(footer, renderer, elementHandlers);
			var footerHeight = Math.ceil(renderer.y - oldY) + 5;
			renderer.y = oldY;
			renderer.pdf.internal.write = oldOut;

			//add 20% to prevent overlapping
			renderer.pdf.margins_doc.bottom += footerHeight;

			//Create function render header on every page
			var renderFooter = function (pageInfo) {
				var pageNumber = pageInfo !== undefined ? pageInfo.pageNumber : 1;
				//set current y position to old margin
				var oldPosition = renderer.y;
				//render all child nodes of the header element
				renderer.y = renderer.pdf.internal.pageSize.height - renderer.pdf.margins_doc.bottom;
				renderer.pdf.margins_doc.bottom -= footerHeight;

				//check if we have to add page numbers
				var spans = footer.getElementsByTagName('span');
				for (var i = 0; i &lt; spans.length; ++i) {
					//if we find some span element with class pageCounter, set the page
					if ((" " + spans[i].className + " ").replace(/[\n\t]/g, " ").indexOf(" pageCounter ") &gt; -1) {
						spans[i].innerHTML = pageNumber;
					}
					//if we find some span element with class totalPages, set a variable which is replaced after rendering of all pages
					if ((" " + spans[i].className + " ").replace(/[\n\t]/g, " ").indexOf(" totalPages ") &gt; -1) {
						spans[i].innerHTML = '###jsPDFVarTotalPages###';
					}
				}

				//render footer content
				DrillForContent(footer, renderer, elementHandlers);
				//set bottom margin to previous height including the footer height
				renderer.pdf.margins_doc.bottom += footerHeight;
				//important for other plugins (e.g. table) to start rendering at correct position after header
				renderer.y = oldPosition;
			};

			//check if footer contains totalPages which shoudl be replace at the disoposal of the document
			var spans = footer.getElementsByTagName('span');
			for (var i = 0; i &lt; spans.length; ++i) {
				if ((" " + spans[i].className + " ").replace(/[\n\t]/g, " ").indexOf(" totalPages ") &gt; -1) {
					renderer.pdf.internal.events.subscribe('htmlRenderingFinished', renderer.pdf.putTotalPages.bind(renderer.pdf, '###jsPDFVarTotalPages###'), true);
				}
			}

			//register event to render footer on every new page
			renderer.pdf.internal.events.subscribe('addPage', renderFooter, false);
			//render footer on first page
			renderFooter();

			//prevent footer rendering
			SkipNode['FOOTER'] = 1;
		}
	};
	process = function (pdf, element, x, y, settings, callback) {
		if (!element)
			return false;
		if (typeof element !== "string" &amp;&amp; !element.parentNode)
			element = '' + element.innerHTML;
		if (typeof element === "string") {
			element = (function (element) {
				var $frame,
				$hiddendiv,
				framename,
				visuallyhidden;
				framename = "jsPDFhtmlText" + Date.now().toString() + (Math.random() * 1000).toFixed(0);
				visuallyhidden = "position: absolute !important;" + "clip: rect(1px 1px 1px 1px); /* IE6, IE7 */" + "clip: rect(1px, 1px, 1px, 1px);" + "padding:0 !important;" + "border:0 !important;" + "height: 1px !important;" + "width: 1px !important; " + "top:auto;" + "left:-100px;" + "overflow: hidden;";
				$hiddendiv = document.createElement('div');
				$hiddendiv.style.cssText = visuallyhidden;
				$hiddendiv.innerHTML = "&lt;iframe style=\"height:1px;width:1px\" name=\"" + framename + "\" /&gt;";
				document.body.appendChild($hiddendiv);
				$frame = window.frames[framename];
				$frame.document.body.innerHTML = element;
				return $frame.document.body;
			})(element.replace(/&lt;\/?script[^&gt;]*?&gt;/gi, ''));
		}
		var r = new Renderer(pdf, x, y, settings), out;

		// 1. load images
		// 2. prepare optional footer elements
		// 3. render content
		loadImgs.call(this, element, r, settings.elementHandlers, function (found_images) {
			checkForFooter( element, r, settings.elementHandlers);
			DrillForContent(element, r, settings.elementHandlers);
			//send event dispose for final taks (e.g. footer totalpage replacement)
			r.pdf.internal.events.publish('htmlRenderingFinished');
			out = r.dispose();
			if (typeof callback === 'function') callback(out);
			else if (found_images) console.error('jsPDF Warning: rendering issues? provide a callback to fromHTML!');
		});
		return out || {x: r.x, y:r.y};
	};
	Renderer.prototype.init = function () {
		this.paragraph = {
			text : [],
			style : []
		};
		return this.pdf.internal.write("q");
	};
	Renderer.prototype.dispose = function () {
		this.pdf.internal.write("Q");
		return {
			x : this.x,
			y : this.y,
			ready:true
		};
	};

	//Checks if we have to execute some watcher functions
	//e.g. to end text floating around an image
	Renderer.prototype.executeWatchFunctions = function(el) {
		var ret = false;
		var narray = [];
		if (this.watchFunctions.length &gt; 0) {
			for(var i=0; i&lt; this.watchFunctions.length; ++i) {
				if (this.watchFunctions[i](el) === true) {
					ret = true;
				} else {
					narray.push(this.watchFunctions[i]);
				}
			}
			this.watchFunctions = narray;
		}
		return ret;
	};

	Renderer.prototype.splitFragmentsIntoLines = function (fragments, styles) {
		var currentLineLength,
		defaultFontSize,
		ff,
		fontMetrics,
		fontMetricsCache,
		fragment,
		fragmentChopped,
		fragmentLength,
		fragmentSpecificMetrics,
		fs,
		k,
		line,
		lines,
		maxLineLength,
		style;
		defaultFontSize = 12;
		k = this.pdf.internal.scaleFactor;
		fontMetricsCache = {};
		ff = void 0;
		fs = void 0;
		fontMetrics = void 0;
		fragment = void 0;
		style = void 0;
		fragmentSpecificMetrics = void 0;
		fragmentLength = void 0;
		fragmentChopped = void 0;
		line = [];
		lines = [line];
		currentLineLength = 0;
		maxLineLength = this.settings.width;
		while (fragments.length) {
			fragment = fragments.shift();
			style = styles.shift();
			if (fragment) {
				ff = style["font-family"];
				fs = style["font-style"];
				fontMetrics = fontMetricsCache[ff + fs];
				if (!fontMetrics) {
					fontMetrics = this.pdf.internal.getFont(ff, fs).metadata.Unicode;
					fontMetricsCache[ff + fs] = fontMetrics;
				}
				fragmentSpecificMetrics = {
					widths : fontMetrics.widths,
					kerning : fontMetrics.kerning,
					fontSize : style["font-size"] * defaultFontSize,
					textIndent : currentLineLength
				};
				fragmentLength = this.pdf.getStringUnitWidth(fragment, fragmentSpecificMetrics) * fragmentSpecificMetrics.fontSize / k;
				if (currentLineLength + fragmentLength &gt; maxLineLength) {
					fragmentChopped = this.pdf.splitTextToSize(fragment, maxLineLength, fragmentSpecificMetrics);
					line.push([fragmentChopped.shift(), style]);
					while (fragmentChopped.length) {
						line = [[fragmentChopped.shift(), style]];
						lines.push(line);
					}
					currentLineLength = this.pdf.getStringUnitWidth(line[0][0], fragmentSpecificMetrics) * fragmentSpecificMetrics.fontSize / k;
				} else {
					line.push([fragment, style]);
					currentLineLength += fragmentLength;
				}
			}
		}

		//if text alignment was set, set margin/indent of each line
		if (style['text-align'] !== undefined &amp;&amp; (style['text-align'] === 'center' || style['text-align'] === 'right' || style['text-align'] === 'justify')) {
			for (var i = 0; i &lt; lines.length; ++i) {
				var length = this.pdf.getStringUnitWidth(lines[i][0][0], fragmentSpecificMetrics) * fragmentSpecificMetrics.fontSize / k;
				//if there is more than on line we have to clone the style object as all lines hold a reference on this object
				if (i &gt; 0) {
					lines[i][0][1] = clone(lines[i][0][1]);
				}
				var space = (maxLineLength - length);

				if (style['text-align'] === 'right') {
					lines[i][0][1]['margin-left'] = space;
					//if alignment is not right, it has to be center so split the space to the left and the right
				} else if (style['text-align'] === 'center') {
					lines[i][0][1]['margin-left'] = space / 2;
					//if justify was set, calculate the word spacing and define in by using the css property
				} else if (style['text-align'] === 'justify') {
					var countSpaces = lines[i][0][0].split(' ').length - 1;
					lines[i][0][1]['word-spacing'] = space / countSpaces;
					//ignore the last line in justify mode
					if (i === (lines.length - 1)) {
						lines[i][0][1]['word-spacing'] = 0;
					}
				}
			}
		}

		return lines;
	};
	Renderer.prototype.RenderTextFragment = function (text, style) {
		var defaultFontSize,
		font,
		maxLineHeight;

		maxLineHeight = 0;
		defaultFontSize = 12;

		if (this.pdf.internal.pageSize.height - this.pdf.margins_doc.bottom &lt; this.y + this.pdf.internal.getFontSize()) {
			this.pdf.internal.write("ET", "Q");
			this.pdf.addPage();
			this.y = this.pdf.margins_doc.top;
			this.pdf.internal.write("q", "BT 0 g", this.pdf.internal.getCoordinateString(this.x), this.pdf.internal.getVerticalCoordinateString(this.y), "Td");
			//move cursor by one line on new page
			maxLineHeight = Math.max(maxLineHeight, style["line-height"], style["font-size"]);
			this.pdf.internal.write(0, (-1 * defaultFontSize * maxLineHeight).toFixed(2), "Td");
		}

		font = this.pdf.internal.getFont(style["font-family"], style["font-style"]);

		//set the word spacing for e.g. justify style
		if (style['word-spacing'] !== undefined &amp;&amp; style['word-spacing'] &gt; 0) {
			this.pdf.internal.write(style['word-spacing'].toFixed(2), "Tw");
		}

		this.pdf.internal.write("/" + font.id, (defaultFontSize * style["font-size"]).toFixed(2), "Tf", "(" + this.pdf.internal.pdfEscape(text) + ") Tj");

		//set the word spacing back to neutral =&gt; 0
		if (style['word-spacing'] !== undefined) {
			this.pdf.internal.write(0, "Tw");
		}
	};
	Renderer.prototype.renderParagraph = function (cb) {
		var blockstyle,
		defaultFontSize,
		fontToUnitRatio,
		fragments,
		i,
		l,
		line,
		lines,
		maxLineHeight,
		out,
		paragraphspacing_after,
		paragraphspacing_before,
		priorblockstype,
		styles,
		fontSize;
		fragments = PurgeWhiteSpace(this.paragraph.text);
		styles = this.paragraph.style;
		blockstyle = this.paragraph.blockstyle;
		priorblockstype = this.paragraph.blockstyle || {};
		this.paragraph = {
			text : [],
			style : [],
			blockstyle : {},
			priorblockstyle : blockstyle
		};
		if (!fragments.join("").trim()) {
			return;
		}
		lines = this.splitFragmentsIntoLines(fragments, styles);
		line = void 0;
		maxLineHeight = void 0;
		defaultFontSize = 12;
		fontToUnitRatio = defaultFontSize / this.pdf.internal.scaleFactor;
		paragraphspacing_before = (Math.max((blockstyle["margin-top"] || 0) - (priorblockstype["margin-bottom"] || 0), 0) + (blockstyle["padding-top"] || 0)) * fontToUnitRatio;
		paragraphspacing_after = ((blockstyle["margin-bottom"] || 0) + (blockstyle["padding-bottom"] || 0)) * fontToUnitRatio;
		out = this.pdf.internal.write;
		i = void 0;
		l = void 0;
		this.y += paragraphspacing_before;
		out("q", "BT 0 g", this.pdf.internal.getCoordinateString(this.x), this.pdf.internal.getVerticalCoordinateString(this.y), "Td");

		//stores the current indent of cursor position
		var currentIndent = 0;

		while (lines.length) {
			line = lines.shift();
			maxLineHeight = 0;
			i = 0;
			l = line.length;
			while (i !== l) {
				if (line[i][0].trim()) {
					maxLineHeight = Math.max(maxLineHeight, line[i][1]["line-height"], line[i][1]["font-size"]);
					fontSize = line[i][1]["font-size"] * 7;
				}
				i++;
			}
			//if we have to move the cursor to adapt the indent
			var indentMove = 0;
			//if a margin was added (by e.g. a text-alignment), move the cursor
			if (line[0][1]["margin-left"] !== undefined &amp;&amp; line[0][1]["margin-left"] &gt; 0) {
				wantedIndent = this.pdf.internal.getCoordinateString(line[0][1]["margin-left"]);
				indentMove = wantedIndent - currentIndent;
				currentIndent = wantedIndent;
			}
			//move the cursor
			out(indentMove, (-1 * defaultFontSize * maxLineHeight).toFixed(2), "Td");
			i = 0;
			l = line.length;
			while (i !== l) {
				if (line[i][0]) {
					this.RenderTextFragment(line[i][0], line[i][1]);
				}
				i++;
			}
			this.y += maxLineHeight * fontToUnitRatio;

			//if some watcher function was executed sucessful, so e.g. margin and widths were changed,
			//reset line drawing and calculate position and lines again
			//e.g. to stop text floating around an image
			if (this.executeWatchFunctions(line[0][1]) &amp;&amp; lines.length &gt; 0) {
				var localFragments = [];
				var localStyles = [];
				//create fragement array of
				lines.forEach(function(localLine) {
					var i = 0;
					var l = localLine.length;
					while (i !== l) {
						if (localLine[i][0]) {
							localFragments.push(localLine[i][0]+' ');
							localStyles.push(localLine[i][1]);
						}
						++i;
					}
				});
				//split lines again due to possible coordinate changes
				lines = this.splitFragmentsIntoLines(PurgeWhiteSpace(localFragments), localStyles);
				//reposition the current cursor
				out("ET", "Q");
				out("q", "BT 0 g", this.pdf.internal.getCoordinateString(this.x), this.pdf.internal.getVerticalCoordinateString(this.y), "Td");
			}

		}
		if (cb &amp;&amp; typeof cb === "function") {
			cb.call(this, this.x - 9, this.y - fontSize / 2);
		}
		out("ET", "Q");
		return this.y += paragraphspacing_after;
	};
	Renderer.prototype.setBlockBoundary = function (cb) {
		return this.renderParagraph(cb);
	};
	Renderer.prototype.setBlockStyle = function (css) {
		return this.paragraph.blockstyle = css;
	};
	Renderer.prototype.addText = function (text, css) {
		this.paragraph.text.push(text);
		return this.paragraph.style.push(css);
	};
	FontNameDB = {
		helvetica         : "helvetica",
		"sans-serif"      : "helvetica",
		"times new roman" : "times",
		serif             : "times",
		times             : "times",
		monospace         : "courier",
		courier           : "courier"
	};
	FontWeightMap = {
		100 : "normal",
		200 : "normal",
		300 : "normal",
		400 : "normal",
		500 : "bold",
		600 : "bold",
		700 : "bold",
		800 : "bold",
		900 : "bold",
		normal  : "normal",
		bold    : "bold",
		bolder  : "bold",
		lighter : "normal"
	};
	FontStyleMap = {
		normal  : "normal",
		italic  : "italic",
		oblique : "italic"
	};
	TextAlignMap = {
		left    : "left",
		right   : "right",
		center  : "center",
		justify : "justify"
	};
	FloatMap = {
		none : 'none',
		right: 'right',
		left: 'left'
	};
	ClearMap = {
	  none : 'none',
	  both : 'both'
	};
	UnitedNumberMap = {
		normal : 1
	};
	/**
	 * Converts HTML-formatted text into formatted PDF text.
	 *
	 * Notes:
	 * 2012-07-18
	 * Plugin relies on having browser, DOM around. The HTML is pushed into dom and traversed.
	 * Plugin relies on jQuery for CSS extraction.
	 * Targeting HTML output from Markdown templating, which is a very simple
	 * markup - div, span, em, strong, p. No br-based paragraph separation supported explicitly (but still may work.)
	 * Images, tables are NOT supported.
	 *
	 * @public
	 * @function
	 * @param HTML {String or DOM Element} HTML-formatted text, or pointer to DOM element that is to be rendered into PDF.
	 * @param x {Number} starting X coordinate in jsPDF instance's declared units.
	 * @param y {Number} starting Y coordinate in jsPDF instance's declared units.
	 * @param settings {Object} Additional / optional variables controlling parsing, rendering.
	 * @returns {Object} jsPDF instance
	 */
	jsPDFAPI.fromHTML = function (HTML, x, y, settings, callback, margins) {
		"use strict";

		this.margins_doc = margins || {
			top : 0,
			bottom : 0
		};
		if (!settings)
			settings = {};
		if (!settings.elementHandlers)
			settings.elementHandlers = {};

		return process(this, HTML, isNaN(x) ? 4 : x, isNaN(y) ? 4 : y, settings, callback);
	};
})(jsPDF.API);
/** ==================================================================== 
 * jsPDF JavaScript plugin
 * Copyright (c) 2013 Youssef Beddad, youssef.beddad@gmail.com
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

/*global jsPDF */

(function (jsPDFAPI) {
    'use strict';
    var jsNamesObj, jsJsObj, text;
    jsPDFAPI.addJS = function (txt) {
        text = txt;
        this.internal.events.subscribe(
            'postPutResources',
            function (txt) {
                jsNamesObj = this.internal.newObject();
                this.internal.write('&lt;&lt; /Names [(EmbeddedJS) ' + (jsNamesObj + 1) + ' 0 R] &gt;&gt;', 'endobj');
                jsJsObj = this.internal.newObject();
                this.internal.write('&lt;&lt; /S /JavaScript /JS (', text, ') &gt;&gt;', 'endobj');
            }
        );
        this.internal.events.subscribe(
            'putCatalog',
            function () {
                if (jsNamesObj !== undefined &amp;&amp; jsJsObj !== undefined) {
                    this.internal.write('/Names &lt;&lt;/JavaScript ' + jsNamesObj + ' 0 R&gt;&gt;');
                }
            }
        );
        return this;
    };
}(jsPDF.API));
/**@preserve
 *  ==================================================================== 
 * jsPDF PNG PlugIn
 * Copyright (c) 2014 James Robb, https://github.com/jamesbrobb
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

(function(jsPDFAPI) {
'use strict'
	
	/*
	 * @see http://www.w3.org/TR/PNG-Chunks.html
	 * 
	 Color    Allowed      Interpretation
	 Type     Bit Depths
	   
	   0       1,2,4,8,16  Each pixel is a grayscale sample.
	   
	   2       8,16        Each pixel is an R,G,B triple.
	   
	   3       1,2,4,8     Each pixel is a palette index;
	                       a PLTE chunk must appear.
	   
	   4       8,16        Each pixel is a grayscale sample,
	                       followed by an alpha sample.
	   
	   6       8,16        Each pixel is an R,G,B triple,
	                       followed by an alpha sample.
	*/
	
	/*
	 * PNG filter method types
	 * 
	 * @see http://www.w3.org/TR/PNG-Filters.html
	 * @see http://www.libpng.org/pub/png/book/chapter09.html
	 * 
	 * This is what the value 'Predictor' in decode params relates to
	 * 
	 * 15 is "optimal prediction", which means the prediction algorithm can change from line to line.
	 * In that case, you actually have to read the first byte off each line for the prediction algorthim (which should be 0-4, corresponding to PDF 10-14) and select the appropriate unprediction algorithm based on that byte.
	 *
	   0       None
	   1       Sub
	   2       Up
	   3       Average
	   4       Paeth
	 */
	
	var doesNotHavePngJS = function() {
		return typeof PNG !== 'function' || typeof FlateStream !== 'function';
	}
	, canCompress = function(value) {
		return value !== jsPDFAPI.image_compression.NONE &amp;&amp; hasCompressionJS();
	}
	, hasCompressionJS = function() {
		var inst = typeof Deflater === 'function';
		if(!inst)
			throw new Error("requires deflate.js for compression")
		return inst;
	}
	, compressBytes = function(bytes, lineLength, colorsPerPixel, compression) {
		
		var level = 5,
			filter_method = filterUp;
		
		switch(compression) {
		
			case jsPDFAPI.image_compression.FAST:
				
				level = 3;
				filter_method = filterSub;
				break;
				
			case jsPDFAPI.image_compression.MEDIUM:
				
				level = 6;
				filter_method = filterAverage;
				break;
				
			case jsPDFAPI.image_compression.SLOW:
				
				level = 9;
				filter_method = filterPaeth;//uses to sum to choose best filter for each line
				break;
		}
		
		bytes = applyPngFilterMethod(bytes, lineLength, colorsPerPixel, filter_method);
		
		var header = new Uint8Array(createZlibHeader(level));
		var checksum = adler32(bytes);
		
		var deflate = new Deflater(level);
		var a = deflate.append(bytes);
		var cBytes = deflate.flush();
		
		var len = header.length + a.length + cBytes.length;
		
		var cmpd = new Uint8Array(len + 4);
		cmpd.set(header);
		cmpd.set(a, header.length);
		cmpd.set(cBytes, header.length + a.length);
		
		cmpd[len++] = (checksum &gt;&gt;&gt; 24) &amp; 0xff;
		cmpd[len++] = (checksum &gt;&gt;&gt; 16) &amp; 0xff;
		cmpd[len++] = (checksum &gt;&gt;&gt; 8) &amp; 0xff;
		cmpd[len++] = checksum &amp; 0xff;
		
		return jsPDFAPI.arrayBufferToBinaryString(cmpd);
	}
	, createZlibHeader = function(bytes, level){
		/*
		 * @see http://www.ietf.org/rfc/rfc1950.txt for zlib header 
		 */
		var cm = 8;
        var cinfo = Math.LOG2E * Math.log(0x8000) - 8;
        var cmf = (cinfo &lt;&lt; 4) | cm;
        
        var hdr = cmf &lt;&lt; 8;
        var flevel = Math.min(3, ((level - 1) &amp; 0xff) &gt;&gt; 1);
        
        hdr |= (flevel &lt;&lt; 6);
        hdr |= 0;//FDICT
        hdr += 31 - (hdr % 31);
        
        return [cmf, (hdr &amp; 0xff) &amp; 0xff];
	}
	, adler32 = function(array, param) {
		var adler = 1;
	    var s1 = adler &amp; 0xffff,
	        s2 = (adler &gt;&gt;&gt; 16) &amp; 0xffff;
	    var len = array.length;
	    var tlen;
	    var i = 0;

	    while (len &gt; 0) {
	      tlen = len &gt; param ? param : len;
	      len -= tlen;
	      do {
	        s1 += array[i++];
	        s2 += s1;
	      } while (--tlen);

	      s1 %= 65521;
	      s2 %= 65521;
	    }

	    return ((s2 &lt;&lt; 16) | s1) &gt;&gt;&gt; 0;
	}
	, applyPngFilterMethod = function(bytes, lineLength, colorsPerPixel, filter_method) {
		var lines = bytes.length / lineLength,
			result = new Uint8Array(bytes.length + lines),
			filter_methods = getFilterMethods(),
			i = 0, line, prevLine, offset;
		
		for(; i &lt; lines; i++) {
			offset = i * lineLength;
			line = bytes.subarray(offset, offset + lineLength);
			
			if(filter_method) {
				result.set(filter_method(line, colorsPerPixel, prevLine), offset + i);
				
			}else{
			
				var j = 0,
					len = filter_methods.length,
					results = [];
				
				for(; j &lt; len; j++)
					results[j] = filter_methods[j](line, colorsPerPixel, prevLine);
				
				var ind = getIndexOfSmallestSum(results.concat());
				
				result.set(results[ind], offset + i);
			}
			
			prevLine = line;
		}
		
		return result;
	}
	, filterNone = function(line, colorsPerPixel, prevLine) {
		/*var result = new Uint8Array(line.length + 1);
		result[0] = 0;
		result.set(line, 1);*/
		
		var result = Array.apply([], line);
		result.unshift(0);

		return result;
	}
	, filterSub = function(line, colorsPerPixel, prevLine) {
		var result = [],
			i = 0,
			len = line.length,
			left;
		
		result[0] = 1;
		
		for(; i &lt; len; i++) {
			left = line[i - colorsPerPixel] || 0;
			result[i + 1] = (line[i] - left + 0x0100) &amp; 0xff;
		}
		
		return result;
	}
	, filterUp = function(line, colorsPerPixel, prevLine) {
		var result = [],
			i = 0,
			len = line.length,
			up;
		
		result[0] = 2;
		
		for(; i &lt; len; i++) {
			up = prevLine &amp;&amp; prevLine[i] || 0;
			result[i + 1] = (line[i] - up + 0x0100) &amp; 0xff;
		}
		
		return result;
	}
	, filterAverage = function(line, colorsPerPixel, prevLine) {
		var result = [],
			i = 0,
			len = line.length,
			left,
			up;
	
		result[0] = 3;
		
		for(; i &lt; len; i++) {
			left = line[i - colorsPerPixel] || 0;
			up = prevLine &amp;&amp; prevLine[i] || 0;
			result[i + 1] = (line[i] + 0x0100 - ((left + up) &gt;&gt;&gt; 1)) &amp; 0xff;
		}
		
		return result;
	}
	, filterPaeth = function(line, colorsPerPixel, prevLine) {
		var result = [],
			i = 0,
			len = line.length,
			left,
			up,
			upLeft,
			paeth;
		
		result[0] = 4;
		
		for(; i &lt; len; i++) {
			left = line[i - colorsPerPixel] || 0;
			up = prevLine &amp;&amp; prevLine[i] || 0;
			upLeft = prevLine &amp;&amp; prevLine[i - colorsPerPixel] || 0;
			paeth = paethPredictor(left, up, upLeft);
			result[i + 1] = (line[i] - paeth + 0x0100) &amp; 0xff;
		}
		
		return result;
	}
	,paethPredictor = function(left, up, upLeft) {

		var p = left + up - upLeft,
	        pLeft = Math.abs(p - left),
	        pUp = Math.abs(p - up),
	        pUpLeft = Math.abs(p - upLeft);
		
		return (pLeft &lt;= pUp &amp;&amp; pLeft &lt;= pUpLeft) ? left : (pUp &lt;= pUpLeft) ? up : upLeft;
	}
	, getFilterMethods = function() {
		return [filterNone, filterSub, filterUp, filterAverage, filterPaeth];
	}
	,getIndexOfSmallestSum = function(arrays) {
		var i = 0,
			len = arrays.length,
			sum, min, ind;
		
		while(i &lt; len) {
			sum = absSum(arrays[i].slice(1));
			
			if(sum &lt; min || !min) {
				min = sum;
				ind = i;
			}
			
			i++;
		}
		
		return ind;
	}
	, absSum = function(array) {
		var i = 0,
			len = array.length,
			sum = 0;
	
		while(i &lt; len)
			sum += Math.abs(array[i++]);
			
		return sum;
	}
	, logImg = function(img) {
		console.log("width: " + img.width);
		console.log("height: " + img.height);
		console.log("bits: " + img.bits);
		console.log("colorType: " + img.colorType);
		console.log("transparency:");
		console.log(img.transparency);
		console.log("text:");
		console.log(img.text);
		console.log("compressionMethod: " + img.compressionMethod);
		console.log("filterMethod: " + img.filterMethod);
		console.log("interlaceMethod: " + img.interlaceMethod);
		console.log("imgData:");
		console.log(img.imgData);
		console.log("palette:");
		console.log(img.palette);
		console.log("colors: " + img.colors);
		console.log("colorSpace: " + img.colorSpace);
		console.log("pixelBitlength: " + img.pixelBitlength);
		console.log("hasAlphaChannel: " + img.hasAlphaChannel);
	};
	
	
	
	
	jsPDFAPI.processPNG = function(imageData, imageIndex, alias, compression, dataAsBinaryString) {
		'use strict'
		
		var colorSpace = this.color_spaces.DEVICE_RGB,
			decode = this.decode.FLATE_DECODE,
			bpc = 8,
			img, dp, trns,
			colors, pal, smask;
		
	/*	if(this.isString(imageData)) {
			
		}*/
		
		if(this.isArrayBuffer(imageData))
			imageData = new Uint8Array(imageData);
		
		if(this.isArrayBufferView(imageData)) {
			
			if(doesNotHavePngJS())
				throw new Error("PNG support requires png.js and zlib.js");
				
			img = new PNG(imageData);
			imageData = img.imgData;
			bpc = img.bits;
			colorSpace = img.colorSpace;
			colors = img.colors;
			
			//logImg(img);
			
			/*
			 * colorType 6 - Each pixel is an R,G,B triple, followed by an alpha sample.
			 * 
			 * colorType 4 - Each pixel is a grayscale sample, followed by an alpha sample.
			 * 
			 * Extract alpha to create two separate images, using the alpha as a sMask
			 */
			if([4,6].indexOf(img.colorType) !== -1) {
				
				/*
				 * processes 8 bit RGBA and grayscale + alpha images
				 */
				if(img.bits === 8) {
				
					var pixelsArrayType = window['Uint' + img.pixelBitlength + 'Array'],
						pixels = new pixelsArrayType(img.decodePixels().buffer),
						len = pixels.length,
						imgData = new Uint8Array(len * img.colors),
						alphaData = new Uint8Array(len),
						pDiff = img.pixelBitlength - img.bits,
						i = 0, n = 0, pixel, pbl;
				
					for(; i &lt; len; i++) {
						pixel = pixels[i];
						pbl = 0;
						
						while(pbl &lt; pDiff) {
							
							imgData[n++] = ( pixel &gt;&gt;&gt; pbl ) &amp; 0xff;
							pbl = pbl + img.bits;
						}
						
						alphaData[i] = ( pixel &gt;&gt;&gt; pbl ) &amp; 0xff;
					}
				}
				
				/*
				 * processes 16 bit RGBA and grayscale + alpha images
				 */
				if(img.bits === 16) {
					
					var pixels = new Uint32Array(img.decodePixels().buffer),
						len = pixels.length,
						imgData = new Uint8Array((len * (32 / img.pixelBitlength) ) * img.colors),
						alphaData = new Uint8Array(len * (32 / img.pixelBitlength) ),
						hasColors = img.colors &gt; 1,
						i = 0, n = 0, a = 0, pixel;
					
					while(i &lt; len) {
						pixel = pixels[i++];
						
						imgData[n++] = (pixel &gt;&gt;&gt; 0) &amp; 0xFF;
						
						if(hasColors) {
							imgData[n++] = (pixel &gt;&gt;&gt; 16) &amp; 0xFF;
							
							pixel = pixels[i++];
							imgData[n++] = (pixel &gt;&gt;&gt; 0) &amp; 0xFF;
						}
						
						alphaData[a++] = (pixel &gt;&gt;&gt; 16) &amp; 0xFF;
					}
					
					bpc = 8;
				}
				
				if(canCompress(compression)) {
										
					imageData = compressBytes(imgData, img.width * img.colors, img.colors, compression);
					smask = compressBytes(alphaData, img.width, 1, compression);
					
				}else{
					
					imageData = imgData;
					smask = alphaData;
					decode = null;
				}
			}
			
			/*
			 * Indexed png. Each pixel is a palette index.
			 */
			if(img.colorType === 3) {
				
				colorSpace = this.color_spaces.INDEXED;
				pal = img.palette;
				
				if(img.transparency.indexed) {
					
					var trans = img.transparency.indexed;
					
					var total = 0,
						i = 0,
						len = trans.length;

					for(; i&lt;len; ++i)
					    total += trans[i];
					
					total = total / 255;
					
					/*
					 * a single color is specified as 100% transparent (0),
					 * so we set trns to use a /Mask with that index
					 */
					if(total === len - 1 &amp;&amp; trans.indexOf(0) !== -1) {
						trns = [trans.indexOf(0)];
					
					/*
					 * there's more than one colour within the palette that specifies
					 * a transparency value less than 255, so we unroll the pixels to create an image sMask
					 */
					}else if(total !== len){
						
						var pixels = img.decodePixels(),
							alphaData = new Uint8Array(pixels.length),
							i = 0,
							len = pixels.length;
						
						for(; i &lt; len; i++)
							alphaData[i] = trans[pixels[i]];
						
						smask = compressBytes(alphaData, img.width, 1);
					}
				}
			}
			
			if(decode === this.decode.FLATE_DECODE)
				dp = '/Predictor 15 /Colors '+ colors +' /BitsPerComponent '+ bpc +' /Columns '+ img.width;
			else
				//remove 'Predictor' as it applies to the type of png filter applied to its IDAT - we only apply with compression
				dp = '/Colors '+ colors +' /BitsPerComponent '+ bpc +' /Columns '+ img.width;
			
			if(this.isArrayBuffer(imageData) || this.isArrayBufferView(imageData))
				imageData = this.arrayBufferToBinaryString(imageData);
			
			if(smask &amp;&amp; this.isArrayBuffer(smask) || this.isArrayBufferView(smask))
				smask = this.arrayBufferToBinaryString(smask);
			
			return this.createImageInfo(imageData, img.width, img.height, colorSpace,
										bpc, decode, imageIndex, alias, dp, trns, pal, smask);
		}
		
		throw new Error("Unsupported PNG image data, try using JPEG instead.");
	}

})(jsPDF.API)
/** @preserve
jsPDF Silly SVG plugin
Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
*/
/**
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

;(function(jsPDFAPI) {
'use strict'

/**
Parses SVG XML and converts only some of the SVG elements into
PDF elements.

Supports:
 paths

@public
@function
@param
@returns {Type}
*/
jsPDFAPI.addSVG = function(svgtext, x, y, w, h) {
	// 'this' is _jsPDF object returned when jsPDF is inited (new jsPDF())

	var undef

	if (x === undef || y === undef) {
		throw new Error("addSVG needs values for 'x' and 'y'");
	}

    function InjectCSS(cssbody, document) {
        var styletag = document.createElement('style');
        styletag.type = 'text/css';
        if (styletag.styleSheet) {
        	// ie
            styletag.styleSheet.cssText = cssbody;
        } else {
        	// others
            styletag.appendChild(document.createTextNode(cssbody));
        }
        document.getElementsByTagName("head")[0].appendChild(styletag);
    }

	function createWorkerNode(document){

		var frameID = 'childframe' // Date.now().toString() + '_' + (Math.random() * 100).toString()
		, frame = document.createElement('iframe')

		InjectCSS(
			'.jsPDF_sillysvg_iframe {display:none;position:absolute;}'
			, document
		)

		frame.name = frameID
		frame.setAttribute("width", 0)
		frame.setAttribute("height", 0)
		frame.setAttribute("frameborder", "0")
		frame.setAttribute("scrolling", "no")
		frame.setAttribute("seamless", "seamless")
		frame.setAttribute("class", "jsPDF_sillysvg_iframe")
		
		document.body.appendChild(frame)

		return frame
	}

	function attachSVGToWorkerNode(svgtext, frame){
		var framedoc = ( frame.contentWindow || frame.contentDocument ).document
		framedoc.write(svgtext)
		framedoc.close()
		return framedoc.getElementsByTagName('svg')[0]
	}

	function convertPathToPDFLinesArgs(path){
		'use strict'
		// we will use 'lines' method call. it needs:
		// - starting coordinate pair
		// - array of arrays of vector shifts (2-len for line, 6 len for bezier)
		// - scale array [horizontal, vertical] ratios
		// - style (stroke, fill, both)

		var x = parseFloat(path[1])
		, y = parseFloat(path[2])
		, vectors = []
		, position = 3
		, len = path.length

		while (position &lt; len){
			if (path[position] === 'c'){
				vectors.push([
					parseFloat(path[position + 1])
					, parseFloat(path[position + 2])
					, parseFloat(path[position + 3])
					, parseFloat(path[position + 4])
					, parseFloat(path[position + 5])
					, parseFloat(path[position + 6])
				])
				position += 7
			} else if (path[position] === 'l') {
				vectors.push([
					parseFloat(path[position + 1])
					, parseFloat(path[position + 2])
				])
				position += 3
			} else {
				position += 1
			}
		}
		return [x,y,vectors]
	}

	var workernode = createWorkerNode(document)
	, svgnode = attachSVGToWorkerNode(svgtext, workernode)
	, scale = [1,1]
	, svgw = parseFloat(svgnode.getAttribute('width'))
	, svgh = parseFloat(svgnode.getAttribute('height'))

	if (svgw &amp;&amp; svgh) {
		// setting both w and h makes image stretch to size.
		// this may distort the image, but fits your demanded size
		if (w &amp;&amp; h) {
			scale = [w / svgw, h / svgh]
		} 
		// if only one is set, that value is set as max and SVG 
		// is scaled proportionately.
		else if (w) {
			scale = [w / svgw, w / svgw]
		} else if (h) {
			scale = [h / svgh, h / svgh]
		}
	}

	var i, l, tmp
	, linesargs
	, items = svgnode.childNodes
	for (i = 0, l = items.length; i &lt; l; i++) {
		tmp = items[i]
		if (tmp.tagName &amp;&amp; tmp.tagName.toUpperCase() === 'PATH') {
			linesargs = convertPathToPDFLinesArgs( tmp.getAttribute("d").split(' ') )
			// path start x coordinate
			linesargs[0] = linesargs[0] * scale[0] + x // where x is upper left X of image
			// path start y coordinate
			linesargs[1] = linesargs[1] * scale[1] + y // where y is upper left Y of image
			// the rest of lines are vectors. these will adjust with scale value auto.
			this.lines.call(
				this
				, linesargs[2] // lines
				, linesargs[0] // starting x
				, linesargs[1] // starting y
				, scale
			)
		}
	}

	// clean up
	// workernode.parentNode.removeChild(workernode)

	return this
}

})(jsPDF.API);
/** @preserve
 * jsPDF split_text_to_size plugin - MIT license.
 * Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
 *               2014 Diego Casorran, https://github.com/diegocr
 */
/**
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

;(function(API) {
'use strict'

/**
Returns an array of length matching length of the 'word' string, with each
cell ocupied by the width of the char in that position.

@function
@param word {String}
@param widths {Object}
@param kerning {Object}
@returns {Array}
*/
var getCharWidthsArray = API.getCharWidthsArray = function(text, options){

	if (!options) {
		options = {}
	}

	var widths = options.widths ? options.widths : this.internal.getFont().metadata.Unicode.widths
	, widthsFractionOf = widths.fof ? widths.fof : 1
	, kerning = options.kerning ? options.kerning : this.internal.getFont().metadata.Unicode.kerning
	, kerningFractionOf = kerning.fof ? kerning.fof : 1

	// console.log("widths, kergnings", widths, kerning)

	var i, l
	, char_code
	, prior_char_code = 0 // for kerning
	, default_char_width = widths[0] || widthsFractionOf
	, output = []

	for (i = 0, l = text.length; i &lt; l; i++) {
		char_code = text.charCodeAt(i)
		output.push(
			( widths[char_code] || default_char_width ) / widthsFractionOf +
			( kerning[char_code] &amp;&amp; kerning[char_code][prior_char_code] || 0 ) / kerningFractionOf
		)
		prior_char_code = char_code
	}

	return output
}
var getArraySum = function(array){
	var i = array.length
	, output = 0
	while(i){
		;i--;
		output += array[i]
	}
	return output
}
/**
Returns a widths of string in a given font, if the font size is set as 1 point.

In other words, this is "proportional" value. For 1 unit of font size, the length
of the string will be that much.

Multiply by font size to get actual width in *points*
Then divide by 72 to get inches or divide by (72/25.6) to get 'mm' etc.

@public
@function
@param
@returns {Type}
*/
var getStringUnitWidth = API.getStringUnitWidth = function(text, options) {
	return getArraySum(getCharWidthsArray.call(this, text, options))
}

/**
returns array of lines
*/
var splitLongWord = function(word, widths_array, firstLineMaxLen, maxLen){
	var answer = []

	// 1st, chop off the piece that can fit on the hanging line.
	var i = 0
	, l = word.length
	, workingLen = 0
	while (i !== l &amp;&amp; workingLen + widths_array[i] &lt; firstLineMaxLen){
		workingLen += widths_array[i]
		;i++;
	}
	// this is first line.
	answer.push(word.slice(0, i))

	// 2nd. Split the rest into maxLen pieces.
	var startOfLine = i
	workingLen = 0
	while (i !== l){
		if (workingLen + widths_array[i] &gt; maxLen) {
			answer.push(word.slice(startOfLine, i))
			workingLen = 0
			startOfLine = i
		}
		workingLen += widths_array[i]
		;i++;
	}
	if (startOfLine !== i) {
		answer.push(word.slice(startOfLine, i))
	}

	return answer
}

// Note, all sizing inputs for this function must be in "font measurement units"
// By default, for PDF, it's "point".
var splitParagraphIntoLines = function(text, maxlen, options){
	// at this time works only on Western scripts, ones with space char
	// separating the words. Feel free to expand.

	if (!options) {
		options = {}
	}

	var line = []
	, lines = [line]
	, line_length = options.textIndent || 0
	, separator_length = 0
	, current_word_length = 0
	, word
	, widths_array
	, words = text.split(' ')
	, spaceCharWidth = getCharWidthsArray(' ', options)[0]
	, i, l, tmp, lineIndent

	if(options.lineIndent === -1) {
		lineIndent = words[0].length +2;
	} else {
		lineIndent = options.lineIndent || 0;
	}
	if(lineIndent) {
		var pad = Array(lineIndent).join(" "), wrds = [];
		words.map(function(wrd) {
			wrd = wrd.split(/\s*\n/);
			if(wrd.length &gt; 1) {
				wrds = wrds.concat(wrd.map(function(wrd, idx) {
					return (idx &amp;&amp; wrd.length ? "\n":"") + wrd;
				}));
			} else {
				wrds.push(wrd[0]);
			}
		});
		words = wrds;
		lineIndent = getStringUnitWidth(pad, options);
	}

	for (i = 0, l = words.length; i &lt; l; i++) {
		var force = 0;

		word = words[i]
		if(lineIndent &amp;&amp; word[0] == "\n") {
			word = word.substr(1);
			force = 1;
		}
		widths_array = getCharWidthsArray(word, options)
		current_word_length = getArraySum(widths_array)

		if (line_length + separator_length + current_word_length &gt; maxlen || force) {
			if (current_word_length &gt; maxlen) {
				// this happens when you have space-less long URLs for example.
				// we just chop these to size. We do NOT insert hiphens
				tmp = splitLongWord(word, widths_array, maxlen - (line_length + separator_length), maxlen)
				// first line we add to existing line object
				line.push(tmp.shift()) // it's ok to have extra space indicator there
				// last line we make into new line object
				line = [tmp.pop()]
				// lines in the middle we apped to lines object as whole lines
				while(tmp.length){
					lines.push([tmp.shift()]) // single fragment occupies whole line
				}
				current_word_length = getArraySum( widths_array.slice(word.length - line[0].length) )
			} else {
				// just put it on a new line
				line = [word]
			}

			// now we attach new line to lines
			lines.push(line)
			line_length = current_word_length + lineIndent
			separator_length = spaceCharWidth

		} else {
			line.push(word)

			line_length += separator_length + current_word_length
			separator_length = spaceCharWidth
		}
	}

	if(lineIndent) {
		var postProcess = function(ln, idx) {
			return (idx ? pad : '') + ln.join(" ");
		};
	} else {
		var postProcess = function(ln) { return ln.join(" ")};
	}

	return lines.map(postProcess);
}

/**
Splits a given string into an array of strings. Uses 'size' value
(in measurement units declared as default for the jsPDF instance)
and the font's "widths" and "Kerning" tables, where availabe, to
determine display length of a given string for a given font.

We use character's 100% of unit size (height) as width when Width
table or other default width is not available.

@public
@function
@param text {String} Unencoded, regular JavaScript (Unicode, UTF-16 / UCS-2) string.
@param size {Number} Nominal number, measured in units default to this instance of jsPDF.
@param options {Object} Optional flags needed for chopper to do the right thing.
@returns {Array} with strings chopped to size.
*/
API.splitTextToSize = function(text, maxlen, options) {
	'use strict'

	if (!options) {
		options = {}
	}

	var fsize = options.fontSize || this.internal.getFontSize()
	, newOptions = (function(options){
		var widths = {0:1}
		, kerning = {}

		if (!options.widths || !options.kerning) {
			var f = this.internal.getFont(options.fontName, options.fontStyle)
			, encoding = 'Unicode'
			// NOT UTF8, NOT UTF16BE/LE, NOT UCS2BE/LE
			// Actual JavaScript-native String's 16bit char codes used.
			// no multi-byte logic here

			if (f.metadata[encoding]) {
				return {
					widths: f.metadata[encoding].widths || widths
					, kerning: f.metadata[encoding].kerning || kerning
				}
			}
		} else {
			return 	{
				widths: options.widths
				, kerning: options.kerning
			}
		}

		// then use default values
		return 	{
			widths: widths
			, kerning: kerning
		}
	}).call(this, options)

	// first we split on end-of-line chars
	var paragraphs
	if(Array.isArray(text)) {
		paragraphs = text;
	} else {
		paragraphs = text.split(/\r?\n/);
	}

	// now we convert size (max length of line) into "font size units"
	// at present time, the "font size unit" is always 'point'
	// 'proportional' means, "in proportion to font size"
	var fontUnit_maxLen = 1.0 * this.internal.scaleFactor * maxlen / fsize
	// at this time, fsize is always in "points" regardless of the default measurement unit of the doc.
	// this may change in the future?
	// until then, proportional_maxlen is likely to be in 'points'

	// If first line is to be indented (shorter or longer) than maxLen
	// we indicate that by using CSS-style "text-indent" option.
	// here it's in font units too (which is likely 'points')
	// it can be negative (which makes the first line longer than maxLen)
	newOptions.textIndent = options.textIndent ?
		options.textIndent * 1.0 * this.internal.scaleFactor / fsize :
		0
	newOptions.lineIndent = options.lineIndent;

	var i, l
	, output = []
	for (i = 0, l = paragraphs.length; i &lt; l; i++) {
		output = output.concat(
			splitParagraphIntoLines(
				paragraphs[i]
				, fontUnit_maxLen
				, newOptions
			)
		)
	}

	return output
}

})(jsPDF.API);
/** @preserve 
jsPDF standard_fonts_metrics plugin
Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
MIT license.
*/
/**
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

;(function(API) {
'use strict'

/*
# reference (Python) versions of 'compress' and 'uncompress'
# only 'uncompress' function is featured lower as JavaScript
# if you want to unit test "roundtrip", just transcribe the reference
# 'compress' function from Python into JavaScript

def compress(data):

	keys =   '0123456789abcdef'
	values = 'klmnopqrstuvwxyz'
	mapping = dict(zip(keys, values))
	vals = []
	for key in data.keys():
		value = data[key]
		try:
			keystring = hex(key)[2:]
			keystring = keystring[:-1] + mapping[keystring[-1:]]
		except:
			keystring = key.join(["'","'"])
			#print('Keystring is %s' % keystring)

		try:
			if value &lt; 0:
				valuestring = hex(value)[3:]
				numberprefix = '-'
			else:
				valuestring = hex(value)[2:]
				numberprefix = ''
			valuestring = numberprefix + valuestring[:-1] + mapping[valuestring[-1:]]
		except:
			if type(value) == dict:
				valuestring = compress(value)
			else:
				raise Exception("Don't know what to do with value type %s" % type(value))

		vals.append(keystring+valuestring)
	
	return '{' + ''.join(vals) + '}'

def uncompress(data):

	decoded = '0123456789abcdef'
	encoded = 'klmnopqrstuvwxyz'
	mapping = dict(zip(encoded, decoded))

	sign = +1
	stringmode = False
	stringparts = []

	output = {}

	activeobject = output
	parentchain = []

	keyparts = ''
	valueparts = ''

	key = None

	ending = set(encoded)

	i = 1
	l = len(data) - 1 # stripping starting, ending {}
	while i != l: # stripping {}
		# -, {, }, ' are special.

		ch = data[i]
		i += 1

		if ch == "'":
			if stringmode:
				# end of string mode
				stringmode = False
				key = ''.join(stringparts)
			else:
				# start of string mode
				stringmode = True
				stringparts = []
		elif stringmode == True:
			#print("Adding %s to stringpart" % ch)
			stringparts.append(ch)

		elif ch == '{':
			# start of object
			parentchain.append( [activeobject, key] )
			activeobject = {}
			key = None
			#DEBUG = True
		elif ch == '}':
			# end of object
			parent, key = parentchain.pop()
			parent[key] = activeobject
			key = None
			activeobject = parent
			#DEBUG = False

		elif ch == '-':
			sign = -1
		else:
			# must be number
			if key == None:
				#debug("In Key. It is '%s', ch is '%s'" % (keyparts, ch))
				if ch in ending:
					#debug("End of key")
					keyparts += mapping[ch]
					key = int(keyparts, 16) * sign
					sign = +1
					keyparts = ''
				else:
					keyparts += ch
			else:
				#debug("In value. It is '%s', ch is '%s'" % (valueparts, ch))
				if ch in ending:
					#debug("End of value")
					valueparts += mapping[ch]
					activeobject[key] = int(valueparts, 16) * sign
					sign = +1
					key = None
					valueparts = ''
				else:
					valueparts += ch

			#debug(activeobject)

	return output

*/

/**
Uncompresses data compressed into custom, base16-like format. 
@public
@function
@param
@returns {Type}
*/
var uncompress = function(data){

	var decoded = '0123456789abcdef'
	, encoded = 'klmnopqrstuvwxyz'
	, mapping = {}

	for (var i = 0; i &lt; encoded.length; i++){
		mapping[encoded[i]] = decoded[i]
	}

	var undef
	, output = {}
	, sign = 1
	, stringparts // undef. will be [] in string mode
	
	, activeobject = output
	, parentchain = []
	, parent_key_pair
	, keyparts = ''
	, valueparts = ''
	, key // undef. will be Truthy when Key is resolved.
	, datalen = data.length - 1 // stripping ending }
	, ch

	i = 1 // stripping starting {
	
	while (i != datalen){
		// - { } ' are special.

		ch = data[i]
		i += 1

		if (ch == "'"){
			if (stringparts){
				// end of string mode
				key = stringparts.join('')
				stringparts = undef				
			} else {
				// start of string mode
				stringparts = []				
			}
		} else if (stringparts){
			stringparts.push(ch)
		} else if (ch == '{'){
			// start of object
			parentchain.push( [activeobject, key] )
			activeobject = {}
			key = undef
		} else if (ch == '}'){
			// end of object
			parent_key_pair = parentchain.pop()
			parent_key_pair[0][parent_key_pair[1]] = activeobject
			key = undef
			activeobject = parent_key_pair[0]
		} else if (ch == '-'){
			sign = -1
		} else {
			// must be number
			if (key === undef) {
				if (mapping.hasOwnProperty(ch)){
					keyparts += mapping[ch]
					key = parseInt(keyparts, 16) * sign
					sign = +1
					keyparts = ''
				} else {
					keyparts += ch
				}
			} else {
				if (mapping.hasOwnProperty(ch)){
					valueparts += mapping[ch]
					activeobject[key] = parseInt(valueparts, 16) * sign
					sign = +1
					key = undef
					valueparts = ''
				} else {
					valueparts += ch					
				}
			}
		}
	} // end while

	return output
}

// encoding = 'Unicode' 
// NOT UTF8, NOT UTF16BE/LE, NOT UCS2BE/LE. NO clever BOM behavior
// Actual 16bit char codes used.
// no multi-byte logic here

// Unicode characters to WinAnsiEncoding:
// {402: 131, 8211: 150, 8212: 151, 8216: 145, 8217: 146, 8218: 130, 8220: 147, 8221: 148, 8222: 132, 8224: 134, 8225: 135, 8226: 149, 8230: 133, 8364: 128, 8240:137, 8249: 139, 8250: 155, 710: 136, 8482: 153, 338: 140, 339: 156, 732: 152, 352: 138, 353: 154, 376: 159, 381: 142, 382: 158}
// as you can see, all Unicode chars are outside of 0-255 range. No char code conflicts.
// this means that you can give Win cp1252 encoded strings to jsPDF for rendering directly
// as well as give strings with some (supported by these fonts) Unicode characters and 
// these will be mapped to win cp1252 
// for example, you can send char code (cp1252) 0x80 or (unicode) 0x20AC, getting "Euro" glyph displayed in both cases.

var encodingBlock = {
	'codePages': ['WinAnsiEncoding']
	, 'WinAnsiEncoding': uncompress("{19m8n201n9q201o9r201s9l201t9m201u8m201w9n201x9o201y8o202k8q202l8r202m9p202q8p20aw8k203k8t203t8v203u9v2cq8s212m9t15m8w15n9w2dw9s16k8u16l9u17s9z17x8y17y9y}")
}
, encodings = {'Unicode':{
	'Courier': encodingBlock
	, 'Courier-Bold': encodingBlock
	, 'Courier-BoldOblique': encodingBlock
	, 'Courier-Oblique': encodingBlock
	, 'Helvetica': encodingBlock
	, 'Helvetica-Bold': encodingBlock
	, 'Helvetica-BoldOblique': encodingBlock
	, 'Helvetica-Oblique': encodingBlock
	, 'Times-Roman': encodingBlock
	, 'Times-Bold': encodingBlock
	, 'Times-BoldItalic': encodingBlock
	, 'Times-Italic': encodingBlock
//	, 'Symbol'
//	, 'ZapfDingbats'
}}
/** 
Resources:
Font metrics data is reprocessed derivative of contents of
"Font Metrics for PDF Core 14 Fonts" package, which exhibits the following copyright and license:

Copyright (c) 1989, 1990, 1991, 1992, 1993, 1997 Adobe Systems Incorporated. All Rights Reserved.

This file and the 14 PostScript(R) AFM files it accompanies may be used,
copied, and distributed for any purpose and without charge, with or without
modification, provided that all copyright notices are retained; that the AFM
files are not distributed without this file; that all modifications to this
file or any of the AFM files are prominently noted in the modified file(s);
and that this paragraph is not modified. Adobe Systems has no responsibility
or obligation to support the use of the AFM files.

*/
, fontMetrics = {'Unicode':{
	// all sizing numbers are n/fontMetricsFractionOf = one font size unit
	// this means that if fontMetricsFractionOf = 1000, and letter A's width is 476, it's
	// width is 476/1000 or 47.6% of its height (regardless of font size)
	// At this time this value applies to "widths" and "kerning" numbers.

	// char code 0 represents "default" (average) width - use it for chars missing in this table.
	// key 'fof' represents the "fontMetricsFractionOf" value

	'Courier-Oblique': uncompress("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}")
	, 'Times-BoldItalic': uncompress("{'widths'{k3o2q4ycx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2r202m2n2n3m2o3m2p5n202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5n4l4m4m4m4n4m4o4s4p4m4q4m4r4s4s4y4t2r4u3m4v4m4w3x4x5t4y4s4z4s5k3x5l4s5m4m5n3r5o3x5p4s5q4m5r5t5s4m5t3x5u3x5v2l5w1w5x2l5y3t5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q2l6r3m6s3r6t1w6u1w6v3m6w1w6x4y6y3r6z3m7k3m7l3m7m2r7n2r7o1w7p3r7q2w7r4m7s3m7t2w7u2r7v2n7w1q7x2n7y3t202l3mcl4mal2ram3man3mao3map3mar3mas2lat4uau1uav3maw3way4uaz2lbk2sbl3t'fof'6obo2lbp3tbq3mbr1tbs2lbu1ybv3mbz3mck4m202k3mcm4mcn4mco4mcp4mcq5ycr4mcs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz2w203k6o212m6o2dw2l2cq2l3t3m3u2l17s3x19m3m}'kerning'{cl{4qu5kt5qt5rs17ss5ts}201s{201ss}201t{cks4lscmscnscoscpscls2wu2yu201ts}201x{2wu2yu}2k{201ts}2w{4qx5kx5ou5qx5rs17su5tu}2x{17su5tu5ou}2y{4qx5kx5ou5qx5rs17ss5ts}'fof'-6ofn{17sw5tw5ou5qw5rs}7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qs}3v{17su5tu5os5qs}7p{17su5tu}ck{4qu5kt5qt5rs17ss5ts}4l{4qu5kt5qt5rs17ss5ts}cm{4qu5kt5qt5rs17ss5ts}cn{4qu5kt5qt5rs17ss5ts}co{4qu5kt5qt5rs17ss5ts}cp{4qu5kt5qt5rs17ss5ts}6l{4qu5ou5qw5rt17su5tu}5q{ckuclucmucnucoucpu4lu}5r{ckuclucmucnucoucpu4lu}7q{cksclscmscnscoscps4ls}6p{4qu5ou5qw5rt17sw5tw}ek{4qu5ou5qw5rt17su5tu}el{4qu5ou5qw5rt17su5tu}em{4qu5ou5qw5rt17su5tu}en{4qu5ou5qw5rt17su5tu}eo{4qu5ou5qw5rt17su5tu}ep{4qu5ou5qw5rt17su5tu}es{17ss5ts5qs4qu}et{4qu5ou5qw5rt17sw5tw}eu{4qu5ou5qw5rt17ss5ts}ev{17ss5ts5qs4qu}6z{17sw5tw5ou5qw5rs}fm{17sw5tw5ou5qw5rs}7n{201ts}fo{17sw5tw5ou5qw5rs}fp{17sw5tw5ou5qw5rs}fq{17sw5tw5ou5qw5rs}7r{cksclscmscnscoscps4ls}fs{17sw5tw5ou5qw5rs}ft{17su5tu}fu{17su5tu}fv{17su5tu}fw{17su5tu}fz{cksclscmscnscoscps4ls}}}")
	, 'Helvetica-Bold': uncompress("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}")
	, 'Courier': uncompress("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}")
	, 'Courier-BoldOblique': uncompress("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}")
	, 'Times-Bold': uncompress("{'widths'{k3q2q5ncx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2l202m2n2n3m2o3m2p6o202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5x4l4s4m4m4n4s4o4s4p4m4q3x4r4y4s4y4t2r4u3m4v4y4w4m4x5y4y4s4z4y5k3x5l4y5m4s5n3r5o4m5p4s5q4s5r6o5s4s5t4s5u4m5v2l5w1w5x2l5y3u5z3m6k2l6l3m6m3r6n2w6o3r6p2w6q2l6r3m6s3r6t1w6u2l6v3r6w1w6x5n6y3r6z3m7k3r7l3r7m2w7n2r7o2l7p3r7q3m7r4s7s3m7t3m7u2w7v2r7w1q7x2r7y3o202l3mcl4sal2lam3man3mao3map3mar3mas2lat4uau1yav3maw3tay4uaz2lbk2sbl3t'fof'6obo2lbp3rbr1tbs2lbu2lbv3mbz3mck4s202k3mcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3rek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3m3u2l17s4s19m3m}'kerning'{cl{4qt5ks5ot5qy5rw17sv5tv}201t{cks4lscmscnscoscpscls4wv}2k{201ts}2w{4qu5ku7mu5os5qx5ru17su5tu}2x{17su5tu5ou5qs}2y{4qv5kv7mu5ot5qz5ru17su5tu}'fof'-6o7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qu}3v{17su5tu5os5qu}fu{17su5tu5ou5qu}7p{17su5tu5ou5qu}ck{4qt5ks5ot5qy5rw17sv5tv}4l{4qt5ks5ot5qy5rw17sv5tv}cm{4qt5ks5ot5qy5rw17sv5tv}cn{4qt5ks5ot5qy5rw17sv5tv}co{4qt5ks5ot5qy5rw17sv5tv}cp{4qt5ks5ot5qy5rw17sv5tv}6l{17st5tt5ou5qu}17s{ckuclucmucnucoucpu4lu4wu}5o{ckuclucmucnucoucpu4lu4wu}5q{ckzclzcmzcnzcozcpz4lz4wu}5r{ckxclxcmxcnxcoxcpx4lx4wu}5t{ckuclucmucnucoucpu4lu4wu}7q{ckuclucmucnucoucpu4lu}6p{17sw5tw5ou5qu}ek{17st5tt5qu}el{17st5tt5ou5qu}em{17st5tt5qu}en{17st5tt5qu}eo{17st5tt5qu}ep{17st5tt5ou5qu}es{17ss5ts5qu}et{17sw5tw5ou5qu}eu{17sw5tw5ou5qu}ev{17ss5ts5qu}6z{17sw5tw5ou5qu5rs}fm{17sw5tw5ou5qu5rs}fn{17sw5tw5ou5qu5rs}fo{17sw5tw5ou5qu5rs}fp{17sw5tw5ou5qu5rs}fq{17sw5tw5ou5qu5rs}7r{cktcltcmtcntcotcpt4lt5os}fs{17sw5tw5ou5qu5rs}ft{17su5tu5ou5qu}7m{5os}fv{17su5tu5ou5qu}fw{17su5tu5ou5qu}fz{cksclscmscnscoscps4ls}}}")
	//, 'Symbol': uncompress("{'widths'{k3uaw4r19m3m2k1t2l2l202m2y2n3m2p5n202q6o3k3m2s2l2t2l2v3r2w1t3m3m2y1t2z1wbk2sbl3r'fof'6o3n3m3o3m3p3m3q3m3r3m3s3m3t3m3u1w3v1w3w3r3x3r3y3r3z2wbp3t3l3m5v2l5x2l5z3m2q4yfr3r7v3k7w1o7x3k}'kerning'{'fof'-6o}}")
	, 'Helvetica': uncompress("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}")
	, 'Helvetica-BoldOblique': uncompress("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}")
	//, 'ZapfDingbats': uncompress("{'widths'{k4u2k1w'fof'6o}'kerning'{'fof'-6o}}")
	, 'Courier-Bold': uncompress("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}")
	, 'Times-Italic': uncompress("{'widths'{k3n2q4ycx2l201n3m201o5t201s2l201t2l201u2l201w3r201x3r201y3r2k1t2l2l202m2n2n3m2o3m2p5n202q5t2r1p2s2l2t2l2u3m2v4n2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w4n3x4n3y4n3z3m4k5w4l3x4m3x4n4m4o4s4p3x4q3x4r4s4s4s4t2l4u2w4v4m4w3r4x5n4y4m4z4s5k3x5l4s5m3x5n3m5o3r5p4s5q3x5r5n5s3x5t3r5u3r5v2r5w1w5x2r5y2u5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q1w6r3m6s3m6t1w6u1w6v2w6w1w6x4s6y3m6z3m7k3m7l3m7m2r7n2r7o1w7p3m7q2w7r4m7s2w7t2w7u2r7v2s7w1v7x2s7y3q202l3mcl3xal2ram3man3mao3map3mar3mas2lat4wau1vav3maw4nay4waz2lbk2sbl4n'fof'6obo2lbp3mbq3obr1tbs2lbu1zbv3mbz3mck3x202k3mcm3xcn3xco3xcp3xcq5tcr4mcs3xct3xcu3xcv3xcw2l2m2ucy2lcz2ldl4mdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr4nfs3mft3mfu3mfv3mfw3mfz2w203k6o212m6m2dw2l2cq2l3t3m3u2l17s3r19m3m}'kerning'{cl{5kt4qw}201s{201sw}201t{201tw2wy2yy6q-t}201x{2wy2yy}2k{201tw}2w{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}2x{17ss5ts5os}2y{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}'fof'-6o6t{17ss5ts5qs}7t{5os}3v{5qs}7p{17su5tu5qs}ck{5kt4qw}4l{5kt4qw}cm{5kt4qw}cn{5kt4qw}co{5kt4qw}cp{5kt4qw}6l{4qs5ks5ou5qw5ru17su5tu}17s{2ks}5q{ckvclvcmvcnvcovcpv4lv}5r{ckuclucmucnucoucpu4lu}5t{2ks}6p{4qs5ks5ou5qw5ru17su5tu}ek{4qs5ks5ou5qw5ru17su5tu}el{4qs5ks5ou5qw5ru17su5tu}em{4qs5ks5ou5qw5ru17su5tu}en{4qs5ks5ou5qw5ru17su5tu}eo{4qs5ks5ou5qw5ru17su5tu}ep{4qs5ks5ou5qw5ru17su5tu}es{5ks5qs4qs}et{4qs5ks5ou5qw5ru17su5tu}eu{4qs5ks5qw5ru17su5tu}ev{5ks5qs4qs}ex{17ss5ts5qs}6z{4qv5ks5ou5qw5ru17su5tu}fm{4qv5ks5ou5qw5ru17su5tu}fn{4qv5ks5ou5qw5ru17su5tu}fo{4qv5ks5ou5qw5ru17su5tu}fp{4qv5ks5ou5qw5ru17su5tu}fq{4qv5ks5ou5qw5ru17su5tu}7r{5os}fs{4qv5ks5ou5qw5ru17su5tu}ft{17su5tu5qs}fu{17su5tu5qs}fv{17su5tu5qs}fw{17su5tu5qs}}}")
	, 'Times-Roman': uncompress("{'widths'{k3n2q4ycx2l201n3m201o6o201s2l201t2l201u2l201w2w201x2w201y2w2k1t2l2l202m2n2n3m2o3m2p5n202q6o2r1m2s2l2t2l2u3m2v3s2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v1w3w3s3x3s3y3s3z2w4k5w4l4s4m4m4n4m4o4s4p3x4q3r4r4s4s4s4t2l4u2r4v4s4w3x4x5t4y4s4z4s5k3r5l4s5m4m5n3r5o3x5p4s5q4s5r5y5s4s5t4s5u3x5v2l5w1w5x2l5y2z5z3m6k2l6l2w6m3m6n2w6o3m6p2w6q2l6r3m6s3m6t1w6u1w6v3m6w1w6x4y6y3m6z3m7k3m7l3m7m2l7n2r7o1w7p3m7q3m7r4s7s3m7t3m7u2w7v3k7w1o7x3k7y3q202l3mcl4sal2lam3man3mao3map3mar3mas2lat4wau1vav3maw3say4waz2lbk2sbl3s'fof'6obo2lbp3mbq2xbr1tbs2lbu1zbv3mbz2wck4s202k3mcm4scn4sco4scp4scq5tcr4mcs3xct3xcu3xcv3xcw2l2m2tcy2lcz2ldl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek2wel2wem2wen2weo2wep2weq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr3sfs3mft3mfu3mfv3mfw3mfz3m203k6o212m6m2dw2l2cq2l3t3m3u1w17s4s19m3m}'kerning'{cl{4qs5ku17sw5ou5qy5rw201ss5tw201ws}201s{201ss}201t{ckw4lwcmwcnwcowcpwclw4wu201ts}2k{201ts}2w{4qs5kw5os5qx5ru17sx5tx}2x{17sw5tw5ou5qu}2y{4qs5kw5os5qx5ru17sx5tx}'fof'-6o7t{ckuclucmucnucoucpu4lu5os5rs}3u{17su5tu5qs}3v{17su5tu5qs}7p{17sw5tw5qs}ck{4qs5ku17sw5ou5qy5rw201ss5tw201ws}4l{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cm{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cn{4qs5ku17sw5ou5qy5rw201ss5tw201ws}co{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cp{4qs5ku17sw5ou5qy5rw201ss5tw201ws}6l{17su5tu5os5qw5rs}17s{2ktclvcmvcnvcovcpv4lv4wuckv}5o{ckwclwcmwcnwcowcpw4lw4wu}5q{ckyclycmycnycoycpy4ly4wu5ms}5r{cktcltcmtcntcotcpt4lt4ws}5t{2ktclvcmvcnvcovcpv4lv4wuckv}7q{cksclscmscnscoscps4ls}6p{17su5tu5qw5rs}ek{5qs5rs}el{17su5tu5os5qw5rs}em{17su5tu5os5qs5rs}en{17su5qs5rs}eo{5qs5rs}ep{17su5tu5os5qw5rs}es{5qs}et{17su5tu5qw5rs}eu{17su5tu5qs5rs}ev{5qs}6z{17sv5tv5os5qx5rs}fm{5os5qt5rs}fn{17sv5tv5os5qx5rs}fo{17sv5tv5os5qx5rs}fp{5os5qt5rs}fq{5os5qt5rs}7r{ckuclucmucnucoucpu4lu5os}fs{17sv5tv5os5qx5rs}ft{17ss5ts5qs}fu{17sw5tw5qs}fv{17sw5tw5qs}fw{17ss5ts5qs}fz{ckuclucmucnucoucpu4lu5os5rs}}}")
	, 'Helvetica-Oblique': uncompress("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}")
}};

/*
This event handler is fired when a new jsPDF object is initialized
This event handler appends metrics data to standard fonts within
that jsPDF instance. The metrics are mapped over Unicode character
codes, NOT CIDs or other codes matching the StandardEncoding table of the
standard PDF fonts.
Future:
Also included is the encoding maping table, converting Unicode (UCS-2, UTF-16)
char codes to StandardEncoding character codes. The encoding table is to be used
somewhere around "pdfEscape" call.
*/

API.events.push([ 
	'addFonts'
	,function(fontManagementObjects) {
		// fontManagementObjects is {
		//	'fonts':font_ID-keyed hash of font objects
		//	, 'dictionary': lookup object, linking ["FontFamily"]['Style'] to font ID
		//}
		var font
		, fontID
		, metrics
		, unicode_section
		, encoding = 'Unicode'
		, encodingBlock

		for (fontID in fontManagementObjects.fonts){
			if (fontManagementObjects.fonts.hasOwnProperty(fontID)) {
				font = fontManagementObjects.fonts[fontID]

				// // we only ship 'Unicode' mappings and metrics. No need for loop.
				// // still, leaving this for the future.

				// for (encoding in fontMetrics){
				// 	if (fontMetrics.hasOwnProperty(encoding)) {

						metrics = fontMetrics[encoding][font.PostScriptName]
						if (metrics) {
							if (font.metadata[encoding]) {
								unicode_section = font.metadata[encoding]
							} else {
								unicode_section = font.metadata[encoding] = {}
							}

							unicode_section.widths = metrics.widths
							unicode_section.kerning = metrics.kerning
						}
				// 	}
				// }
				// for (encoding in encodings){
				// 	if (encodings.hasOwnProperty(encoding)) {
						encodingBlock = encodings[encoding][font.PostScriptName]
						if (encodingBlock) {
							if (font.metadata[encoding]) {
								unicode_section = font.metadata[encoding]
							} else {
								unicode_section = font.metadata[encoding] = {}
							}

							unicode_section.encoding = encodingBlock
							if (encodingBlock.codePages &amp;&amp; encodingBlock.codePages.length) {
								font.encoding = encodingBlock.codePages[0]
							}
						}
				// 	}
				// }
			}
		}
	}
]) // end of adding event handler

})(jsPDF.API);
/** ==================================================================== 
 * jsPDF total_pages plugin
 * Copyright (c) 2013 Eduardo Menezes de Morais, eduardo.morais@usp.br
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

(function(jsPDFAPI) {
'use strict';

jsPDFAPI.putTotalPages = function(pageExpression) {
	'use strict';
        var replaceExpression = new RegExp(pageExpression, 'g');
        for (var n = 1; n &lt;= this.internal.getNumberOfPages(); n++) {
            for (var i = 0; i &lt; this.internal.pages[n].length; i++)
               this.internal.pages[n][i] = this.internal.pages[n][i].replace(replaceExpression, this.internal.getNumberOfPages());
        }
	return this;
};

})(jsPDF.API);
/* Blob.js
 * A Blob implementation.
 * 2014-07-24
 *
 * By Eli Grey, http://eligrey.com
 * By Devin Samarin, https://github.com/dsamarin
 * License: X11/MIT
 *   See https://github.com/eligrey/Blob.js/blob/master/LICENSE.md
 */

/*global self, unescape */
/*jslint bitwise: true, regexp: true, confusion: true, es5: true, vars: true, white: true,
  plusplus: true */

/*! @source http://purl.eligrey.com/github/Blob.js/blob/master/Blob.js */

(function (view) {
	"use strict";

	view.URL = view.URL || view.webkitURL;

	if (view.Blob &amp;&amp; view.URL) {
		try {
			new Blob;
			return;
		} catch (e) {}
	}

	// Internally we use a BlobBuilder implementation to base Blob off of
	// in order to support older browsers that only have BlobBuilder
	var BlobBuilder = view.BlobBuilder || view.WebKitBlobBuilder || view.MozBlobBuilder || (function(view) {
		var
			  get_class = function(object) {
				return Object.prototype.toString.call(object).match(/^\[object\s(.*)\]$/)[1];
			}
			, FakeBlobBuilder = function BlobBuilder() {
				this.data = [];
			}
			, FakeBlob = function Blob(data, type, encoding) {
				this.data = data;
				this.size = data.length;
				this.type = type;
				this.encoding = encoding;
			}
			, FBB_proto = FakeBlobBuilder.prototype
			, FB_proto = FakeBlob.prototype
			, FileReaderSync = view.FileReaderSync
			, FileException = function(type) {
				this.code = this[this.name = type];
			}
			, file_ex_codes = (
				  "NOT_FOUND_ERR SECURITY_ERR ABORT_ERR NOT_READABLE_ERR ENCODING_ERR "
				+ "NO_MODIFICATION_ALLOWED_ERR INVALID_STATE_ERR SYNTAX_ERR"
			).split(" ")
			, file_ex_code = file_ex_codes.length
			, real_URL = view.URL || view.webkitURL || view
			, real_create_object_URL = real_URL.createObjectURL
			, real_revoke_object_URL = real_URL.revokeObjectURL
			, URL = real_URL
			, btoa = view.btoa
			, atob = view.atob

			, ArrayBuffer = view.ArrayBuffer
			, Uint8Array = view.Uint8Array

			, origin = /^[\w-]+:\/*\[?[\w\.:-]+\]?(?::[0-9]+)?/
		;
		FakeBlob.fake = FB_proto.fake = true;
		while (file_ex_code--) {
			FileException.prototype[file_ex_codes[file_ex_code]] = file_ex_code + 1;
		}
		// Polyfill URL
		if (!real_URL.createObjectURL) {
			URL = view.URL = function(uri) {
				var
					  uri_info = document.createElementNS("http://www.w3.org/1999/xhtml", "a")
					, uri_origin
				;
				uri_info.href = uri;
				if (!("origin" in uri_info)) {
					if (uri_info.protocol.toLowerCase() === "data:") {
						uri_info.origin = null;
					} else {
						uri_origin = uri.match(origin);
						uri_info.origin = uri_origin &amp;&amp; uri_origin[1];
					}
				}
				return uri_info;
			};
		}
		URL.createObjectURL = function(blob) {
			var
				  type = blob.type
				, data_URI_header
			;
			if (type === null) {
				type = "application/octet-stream";
			}
			if (blob instanceof FakeBlob) {
				data_URI_header = "data:" + type;
				if (blob.encoding === "base64") {
					return data_URI_header + ";base64," + blob.data;
				} else if (blob.encoding === "URI") {
					return data_URI_header + "," + decodeURIComponent(blob.data);
				} if (btoa) {
					return data_URI_header + ";base64," + btoa(blob.data);
				} else {
					return data_URI_header + "," + encodeURIComponent(blob.data);
				}
			} else if (real_create_object_URL) {
				return real_create_object_URL.call(real_URL, blob);
			}
		};
		URL.revokeObjectURL = function(object_URL) {
			if (object_URL.substring(0, 5) !== "data:" &amp;&amp; real_revoke_object_URL) {
				real_revoke_object_URL.call(real_URL, object_URL);
			}
		};
		FBB_proto.append = function(data/*, endings*/) {
			var bb = this.data;
			// decode data to a binary string
			if (Uint8Array &amp;&amp; (data instanceof ArrayBuffer || data instanceof Uint8Array)) {
				var
					  str = ""
					, buf = new Uint8Array(data)
					, i = 0
					, buf_len = buf.length
				;
				for (; i &lt; buf_len; i++) {
					str += String.fromCharCode(buf[i]);
				}
				bb.push(str);
			} else if (get_class(data) === "Blob" || get_class(data) === "File") {
				if (FileReaderSync) {
					var fr = new FileReaderSync;
					bb.push(fr.readAsBinaryString(data));
				} else {
					// async FileReader won't work as BlobBuilder is sync
					throw new FileException("NOT_READABLE_ERR");
				}
			} else if (data instanceof FakeBlob) {
				if (data.encoding === "base64" &amp;&amp; atob) {
					bb.push(atob(data.data));
				} else if (data.encoding === "URI") {
					bb.push(decodeURIComponent(data.data));
				} else if (data.encoding === "raw") {
					bb.push(data.data);
				}
			} else {
				if (typeof data !== "string") {
					data += ""; // convert unsupported types to strings
				}
				// decode UTF-16 to binary string
				bb.push(unescape(encodeURIComponent(data)));
			}
		};
		FBB_proto.getBlob = function(type) {
			if (!arguments.length) {
				type = null;
			}
			return new FakeBlob(this.data.join(""), type, "raw");
		};
		FBB_proto.toString = function() {
			return "[object BlobBuilder]";
		};
		FB_proto.slice = function(start, end, type) {
			var args = arguments.length;
			if (args &lt; 3) {
				type = null;
			}
			return new FakeBlob(
				  this.data.slice(start, args &gt; 1 ? end : this.data.length)
				, type
				, this.encoding
			);
		};
		FB_proto.toString = function() {
			return "[object Blob]";
		};
		FB_proto.close = function() {
			this.size = 0;
			delete this.data;
		};
		return FakeBlobBuilder;
	}(view));

	view.Blob = function(blobParts, options) {
		var type = options ? (options.type || "") : "";
		var builder = new BlobBuilder();
		if (blobParts) {
			for (var i = 0, len = blobParts.length; i &lt; len; i++) {
				builder.append(blobParts[i]);
			}
		}
		return builder.getBlob(type);
	};
}(typeof self !== "undefined" &amp;&amp; self || typeof window !== "undefined" &amp;&amp; window || this.content || this));
/* FileSaver.js
 * A saveAs() FileSaver implementation.
 * 2014-08-29
 *
 * By Eli Grey, http://eligrey.com
 * License: X11/MIT
 *   See https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md
 */

/*global self */
/*jslint bitwise: true, indent: 4, laxbreak: true, laxcomma: true, smarttabs: true, plusplus: true */

/*! @source http://purl.eligrey.com/github/FileSaver.js/blob/master/FileSaver.js */

var saveAs = saveAs
  // IE 10+ (native saveAs)
  || (typeof navigator !== "undefined" &amp;&amp;
      navigator.msSaveOrOpenBlob &amp;&amp; navigator.msSaveOrOpenBlob.bind(navigator))
  // Everyone else
  || (function(view) {
	"use strict";
	// IE &lt;10 is explicitly unsupported
	if (typeof navigator !== "undefined" &amp;&amp;
	    /MSIE [1-9]\./.test(navigator.userAgent)) {
		return;
	}
	var
		  doc = view.document
		  // only get URL when necessary in case Blob.js hasn't overridden it yet
		, get_URL = function() {
			return view.URL || view.webkitURL || view;
		}
		, save_link = doc.createElementNS("http://www.w3.org/1999/xhtml", "a")
		, can_use_save_link = "download" in save_link
		, click = function(node) {
			var event = doc.createEvent("MouseEvents");
			event.initMouseEvent(
				"click", true, false, view, 0, 0, 0, 0, 0
				, false, false, false, false, 0, null
			);
			node.dispatchEvent(event);
		}
		, webkit_req_fs = view.webkitRequestFileSystem
		, req_fs = view.requestFileSystem || webkit_req_fs || view.mozRequestFileSystem
		, throw_outside = function(ex) {
			(view.setImmediate || view.setTimeout)(function() {
				throw ex;
			}, 0);
		}
		, force_saveable_type = "application/octet-stream"
		, fs_min_size = 0
		// See https://code.google.com/p/chromium/issues/detail?id=375297#c7 for
		// the reasoning behind the timeout and revocation flow
		, arbitrary_revoke_timeout = 10
		, revoke = function(file) {
			var revoker = function() {
				if (typeof file === "string") { // file is an object URL
					get_URL().revokeObjectURL(file);
				} else { // file is a File
					file.remove();
				}
			};
			if (view.chrome) {
				revoker();
			} else {
				setTimeout(revoker, arbitrary_revoke_timeout);
			}
		}
		, dispatch = function(filesaver, event_types, event) {
			event_types = [].concat(event_types);
			var i = event_types.length;
			while (i--) {
				var listener = filesaver["on" + event_types[i]];
				if (typeof listener === "function") {
					try {
						listener.call(filesaver, event || filesaver);
					} catch (ex) {
						throw_outside(ex);
					}
				}
			}
		}
		, FileSaver = function(blob, name) {
			// First try a.download, then web filesystem, then object URLs
			var
				  filesaver = this
				, type = blob.type
				, blob_changed = false
				, object_url
				, target_view
				, dispatch_all = function() {
					dispatch(filesaver, "writestart progress write writeend".split(" "));
				}
				// on any filesys errors revert to saving with object URLs
				, fs_error = function() {
					// don't create more object URLs than needed
					if (blob_changed || !object_url) {
						object_url = get_URL().createObjectURL(blob);
					}
					if (target_view) {
						target_view.location.href = object_url;
					} else {
						var new_tab = view.open(object_url, "_blank");
						if (new_tab == undefined &amp;&amp; typeof safari !== "undefined") {
							//Apple do not allow window.open, see http://bit.ly/1kZffRI
							view.location.href = object_url
						}
					}
					filesaver.readyState = filesaver.DONE;
					dispatch_all();
					revoke(object_url);
				}
				, abortable = function(func) {
					return function() {
						if (filesaver.readyState !== filesaver.DONE) {
							return func.apply(this, arguments);
						}
					};
				}
				, create_if_not_found = {create: true, exclusive: false}
				, slice
			;
			filesaver.readyState = filesaver.INIT;
			if (!name) {
				name = "download";
			}
			if (can_use_save_link) {
				object_url = get_URL().createObjectURL(blob);
				save_link.href = object_url;
				save_link.download = name;
				click(save_link);
				filesaver.readyState = filesaver.DONE;
				dispatch_all();
				revoke(object_url);
				return;
			}
			// Object and web filesystem URLs have a problem saving in Google Chrome when
			// viewed in a tab, so I force save with application/octet-stream
			// http://code.google.com/p/chromium/issues/detail?id=91158
			// Update: Google errantly closed 91158, I submitted it again:
			// https://code.google.com/p/chromium/issues/detail?id=389642
			if (view.chrome &amp;&amp; type &amp;&amp; type !== force_saveable_type) {
				slice = blob.slice || blob.webkitSlice;
				blob = slice.call(blob, 0, blob.size, force_saveable_type);
				blob_changed = true;
			}
			// Since I can't be sure that the guessed media type will trigger a download
			// in WebKit, I append .download to the filename.
			// https://bugs.webkit.org/show_bug.cgi?id=65440
			if (webkit_req_fs &amp;&amp; name !== "download") {
				name += ".download";
			}
			if (type === force_saveable_type || webkit_req_fs) {
				target_view = view;
			}
			if (!req_fs) {
				fs_error();
				return;
			}
			fs_min_size += blob.size;
			req_fs(view.TEMPORARY, fs_min_size, abortable(function(fs) {
				fs.root.getDirectory("saved", create_if_not_found, abortable(function(dir) {
					var save = function() {
						dir.getFile(name, create_if_not_found, abortable(function(file) {
							file.createWriter(abortable(function(writer) {
								writer.onwriteend = function(event) {
									target_view.location.href = file.toURL();
									filesaver.readyState = filesaver.DONE;
									dispatch(filesaver, "writeend", event);
									revoke(file);
								};
								writer.onerror = function() {
									var error = writer.error;
									if (error.code !== error.ABORT_ERR) {
										fs_error();
									}
								};
								"writestart progress write abort".split(" ").forEach(function(event) {
									writer["on" + event] = filesaver["on" + event];
								});
								writer.write(blob);
								filesaver.abort = function() {
									writer.abort();
									filesaver.readyState = filesaver.DONE;
								};
								filesaver.readyState = filesaver.WRITING;
							}), fs_error);
						}), fs_error);
					};
					dir.getFile(name, {create: false}, abortable(function(file) {
						// delete file if it already exists
						file.remove();
						save();
					}), abortable(function(ex) {
						if (ex.code === ex.NOT_FOUND_ERR) {
							save();
						} else {
							fs_error();
						}
					}));
				}), fs_error);
			}), fs_error);
		}
		, FS_proto = FileSaver.prototype
		, saveAs = function(blob, name) {
			return new FileSaver(blob, name);
		}
	;
	FS_proto.abort = function() {
		var filesaver = this;
		filesaver.readyState = filesaver.DONE;
		dispatch(filesaver, "abort");
	};
	FS_proto.readyState = FS_proto.INIT = 0;
	FS_proto.WRITING = 1;
	FS_proto.DONE = 2;

	FS_proto.error =
	FS_proto.onwritestart =
	FS_proto.onprogress =
	FS_proto.onwrite =
	FS_proto.onabort =
	FS_proto.onerror =
	FS_proto.onwriteend =
		null;

	return saveAs;
}(
	   typeof self !== "undefined" &amp;&amp; self
	|| typeof window !== "undefined" &amp;&amp; window
	|| this.content
));
// `self` is undefined in Firefox for Android content script context
// while `this` is nsIContentFrameMessageManager
// with an attribute `content` that corresponds to the window

if (typeof module !== "undefined" &amp;&amp; module !== null) {
  module.exports = saveAs;
} else if ((typeof define !== "undefined" &amp;&amp; 0)) {
  define([], function() {
    return saveAs;
  });
}
/*
 * Copyright (c) 2012 chick307 &lt;chick307@gmail.com&gt;
 *
 * Licensed under the MIT License.
 * http://opensource.org/licenses/mit-license
 */

void function(global, callback) {
	if (typeof module === 'object') {
		module.exports = callback();
	} else if (0 === 'function') {
		define(callback);
	} else {
		global.adler32cs = callback();
	}
}(jsPDF, function() {
	var _hasArrayBuffer = typeof ArrayBuffer === 'function' &amp;&amp;
		typeof Uint8Array === 'function';

	var _Buffer = null, _isBuffer = (function() {
		if (!_hasArrayBuffer)
			return function _isBuffer() { return false };

		try {
			var buffer = require('buffer');
			if (typeof buffer.Buffer === 'function')
				_Buffer = buffer.Buffer;
		} catch (error) {}

		return function _isBuffer(value) {
			return value instanceof ArrayBuffer ||
				_Buffer !== null &amp;&amp; value instanceof _Buffer;
		};
	}());

	var _utf8ToBinary = (function() {
		if (_Buffer !== null) {
			return function _utf8ToBinary(utf8String) {
				return new _Buffer(utf8String, 'utf8').toString('binary');
			};
		} else {
			return function _utf8ToBinary(utf8String) {
				return unescape(encodeURIComponent(utf8String));
			};
		}
	}());

	var MOD = 65521;

	var _update = function _update(checksum, binaryString) {
		var a = checksum &amp; 0xFFFF, b = checksum &gt;&gt;&gt; 16;
		for (var i = 0, length = binaryString.length; i &lt; length; i++) {
			a = (a + (binaryString.charCodeAt(i) &amp; 0xFF)) % MOD;
			b = (b + a) % MOD;
		}
		return (b &lt;&lt; 16 | a) &gt;&gt;&gt; 0;
	};

	var _updateUint8Array = function _updateUint8Array(checksum, uint8Array) {
		var a = checksum &amp; 0xFFFF, b = checksum &gt;&gt;&gt; 16;
		for (var i = 0, length = uint8Array.length, x; i &lt; length; i++) {
			a = (a + uint8Array[i]) % MOD;
			b = (b + a) % MOD;
		}
		return (b &lt;&lt; 16 | a) &gt;&gt;&gt; 0
	};

	var exports = {};

	var Adler32 = exports.Adler32 = (function() {
		var ctor = function Adler32(checksum) {
			if (!(this instanceof ctor)) {
				throw new TypeError(
					'Constructor cannot called be as a function.');
			}
			if (!isFinite(checksum = checksum == null ? 1 : +checksum)) {
				throw new Error(
					'First arguments needs to be a finite number.');
			}
			this.checksum = checksum &gt;&gt;&gt; 0;
		};

		var proto = ctor.prototype = {};
		proto.constructor = ctor;

		ctor.from = function(from) {
			from.prototype = proto;
			return from;
		}(function from(binaryString) {
			if (!(this instanceof ctor)) {
				throw new TypeError(
					'Constructor cannot called be as a function.');
			}
			if (binaryString == null)
				throw new Error('First argument needs to be a string.');
			this.checksum = _update(1, binaryString.toString());
		});

		ctor.fromUtf8 = function(fromUtf8) {
			fromUtf8.prototype = proto;
			return fromUtf8;
		}(function fromUtf8(utf8String) {
			if (!(this instanceof ctor)) {
				throw new TypeError(
					'Constructor cannot called be as a function.');
			}
			if (utf8String == null)
				throw new Error('First argument needs to be a string.');
			var binaryString = _utf8ToBinary(utf8String.toString());
			this.checksum = _update(1, binaryString);
		});

		if (_hasArrayBuffer) {
			ctor.fromBuffer = function(fromBuffer) {
				fromBuffer.prototype = proto;
				return fromBuffer;
			}(function fromBuffer(buffer) {
				if (!(this instanceof ctor)) {
					throw new TypeError(
						'Constructor cannot called be as a function.');
				}
				if (!_isBuffer(buffer))
					throw new Error('First argument needs to be ArrayBuffer.');
				var array = new Uint8Array(buffer);
				return this.checksum = _updateUint8Array(1, array);
			});
		}

		proto.update = function update(binaryString) {
			if (binaryString == null)
				throw new Error('First argument needs to be a string.');
			binaryString = binaryString.toString();
			return this.checksum = _update(this.checksum, binaryString);
		};

		proto.updateUtf8 = function updateUtf8(utf8String) {
			if (utf8String == null)
				throw new Error('First argument needs to be a string.');
			var binaryString = _utf8ToBinary(utf8String.toString());
			return this.checksum = _update(this.checksum, binaryString);
		};

		if (_hasArrayBuffer) {
			proto.updateBuffer = function updateBuffer(buffer) {
				if (!_isBuffer(buffer))
					throw new Error('First argument needs to be ArrayBuffer.');
				var array = new Uint8Array(buffer);
				return this.checksum = _updateUint8Array(this.checksum, array);
			};
		}

		proto.clone = function clone() {
			return new Adler32(this.checksum);
		};

		return ctor;
	}());

	exports.from = function from(binaryString) {
		if (binaryString == null)
			throw new Error('First argument needs to be a string.');
		return _update(1, binaryString.toString());
	};

	exports.fromUtf8 = function fromUtf8(utf8String) {
		if (utf8String == null)
			throw new Error('First argument needs to be a string.');
		var binaryString = _utf8ToBinary(utf8String.toString());
		return _update(1, binaryString);
	};

	if (_hasArrayBuffer) {
		exports.fromBuffer = function fromBuffer(buffer) {
			if (!_isBuffer(buffer))
				throw new Error('First argument need to be ArrayBuffer.');
			var array = new Uint8Array(buffer);
			return _updateUint8Array(1, array);
		};
	}

	return exports;
});
/*
 Deflate.js - https://github.com/gildas-lormeau/zip.js
 Copyright (c) 2013 Gildas Lormeau. All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 1. Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright 
 notice, this list of conditions and the following disclaimer in 
 the documentation and/or other materials provided with the distribution.

 3. The names of the authors may not be used to endorse or promote products
 derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JCRAFT,
 INC. OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * This program is based on JZlib 1.0.2 ymnk, JCraft,Inc.
 * JZlib is based on zlib-1.1.3, so all credit should go authors
 * Jean-loup Gailly(jloup@gzip.org) and Mark Adler(madler@alumni.caltech.edu)
 * and contributors of zlib.
 */

var Deflater = (function(obj) {

	// Global

	var MAX_BITS = 15;
	var D_CODES = 30;
	var BL_CODES = 19;

	var LENGTH_CODES = 29;
	var LITERALS = 256;
	var L_CODES = (LITERALS + 1 + LENGTH_CODES);
	var HEAP_SIZE = (2 * L_CODES + 1);

	var END_BLOCK = 256;

	// Bit length codes must not exceed MAX_BL_BITS bits
	var MAX_BL_BITS = 7;

	// repeat previous bit length 3-6 times (2 bits of repeat count)
	var REP_3_6 = 16;

	// repeat a zero length 3-10 times (3 bits of repeat count)
	var REPZ_3_10 = 17;

	// repeat a zero length 11-138 times (7 bits of repeat count)
	var REPZ_11_138 = 18;

	// The lengths of the bit length codes are sent in order of decreasing
	// probability, to avoid transmitting the lengths for unused bit
	// length codes.

	var Buf_size = 8 * 2;

	// JZlib version : "1.0.2"
	var Z_DEFAULT_COMPRESSION = -1;

	// compression strategy
	var Z_FILTERED = 1;
	var Z_HUFFMAN_ONLY = 2;
	var Z_DEFAULT_STRATEGY = 0;

	var Z_NO_FLUSH = 0;
	var Z_PARTIAL_FLUSH = 1;
	var Z_FULL_FLUSH = 3;
	var Z_FINISH = 4;

	var Z_OK = 0;
	var Z_STREAM_END = 1;
	var Z_NEED_DICT = 2;
	var Z_STREAM_ERROR = -2;
	var Z_DATA_ERROR = -3;
	var Z_BUF_ERROR = -5;

	// Tree

	// see definition of array dist_code below
	var _dist_code = [ 0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
			10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
			12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13,
			13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
			14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
			14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,
			15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 16, 17, 18, 18, 19, 19,
			20, 20, 20, 20, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
			24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26,
			26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
			27, 27, 27, 27, 27, 27, 27, 27, 27, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
			28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 29,
			29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
			29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29 ];

	function Tree() {
		var that = this;

		// dyn_tree; // the dynamic tree
		// max_code; // largest code with non zero frequency
		// stat_desc; // the corresponding static tree

		// Compute the optimal bit lengths for a tree and update the total bit
		// length
		// for the current block.
		// IN assertion: the fields freq and dad are set, heap[heap_max] and
		// above are the tree nodes sorted by increasing frequency.
		// OUT assertions: the field len is set to the optimal bit length, the
		// array bl_count contains the frequencies for each bit length.
		// The length opt_len is updated; static_len is also updated if stree is
		// not null.
		function gen_bitlen(s) {
			var tree = that.dyn_tree;
			var stree = that.stat_desc.static_tree;
			var extra = that.stat_desc.extra_bits;
			var base = that.stat_desc.extra_base;
			var max_length = that.stat_desc.max_length;
			var h; // heap index
			var n, m; // iterate over the tree elements
			var bits; // bit length
			var xbits; // extra bits
			var f; // frequency
			var overflow = 0; // number of elements with bit length too large

			for (bits = 0; bits &lt;= MAX_BITS; bits++)
				s.bl_count[bits] = 0;

			// In a first pass, compute the optimal bit lengths (which may
			// overflow in the case of the bit length tree).
			tree[s.heap[s.heap_max] * 2 + 1] = 0; // root of the heap

			for (h = s.heap_max + 1; h &lt; HEAP_SIZE; h++) {
				n = s.heap[h];
				bits = tree[tree[n * 2 + 1] * 2 + 1] + 1;
				if (bits &gt; max_length) {
					bits = max_length;
					overflow++;
				}
				tree[n * 2 + 1] = bits;
				// We overwrite tree[n*2+1] which is no longer needed

				if (n &gt; that.max_code)
					continue; // not a leaf node

				s.bl_count[bits]++;
				xbits = 0;
				if (n &gt;= base)
					xbits = extra[n - base];
				f = tree[n * 2];
				s.opt_len += f * (bits + xbits);
				if (stree)
					s.static_len += f * (stree[n * 2 + 1] + xbits);
			}
			if (overflow === 0)
				return;

			// This happens for example on obj2 and pic of the Calgary corpus
			// Find the first bit length which could increase:
			do {
				bits = max_length - 1;
				while (s.bl_count[bits] === 0)
					bits--;
				s.bl_count[bits]--; // move one leaf down the tree
				s.bl_count[bits + 1] += 2; // move one overflow item as its brother
				s.bl_count[max_length]--;
				// The brother of the overflow item also moves one step up,
				// but this does not affect bl_count[max_length]
				overflow -= 2;
			} while (overflow &gt; 0);

			for (bits = max_length; bits !== 0; bits--) {
				n = s.bl_count[bits];
				while (n !== 0) {
					m = s.heap[--h];
					if (m &gt; that.max_code)
						continue;
					if (tree[m * 2 + 1] != bits) {
						s.opt_len += (bits - tree[m * 2 + 1]) * tree[m * 2];
						tree[m * 2 + 1] = bits;
					}
					n--;
				}
			}
		}

		// Reverse the first len bits of a code, using straightforward code (a
		// faster
		// method would use a table)
		// IN assertion: 1 &lt;= len &lt;= 15
		function bi_reverse(code, // the value to invert
		len // its bit length
		) {
			var res = 0;
			do {
				res |= code &amp; 1;
				code &gt;&gt;&gt;= 1;
				res &lt;&lt;= 1;
			} while (--len &gt; 0);
			return res &gt;&gt;&gt; 1;
		}

		// Generate the codes for a given tree and bit counts (which need not be
		// optimal).
		// IN assertion: the array bl_count contains the bit length statistics for
		// the given tree and the field len is set for all tree elements.
		// OUT assertion: the field code is set for all tree elements of non
		// zero code length.
		function gen_codes(tree, // the tree to decorate
		max_code, // largest code with non zero frequency
		bl_count // number of codes at each bit length
		) {
			var next_code = []; // next code value for each
			// bit length
			var code = 0; // running code value
			var bits; // bit index
			var n; // code index
			var len;

			// The distribution counts are first used to generate the code values
			// without bit reversal.
			for (bits = 1; bits &lt;= MAX_BITS; bits++) {
				next_code[bits] = code = ((code + bl_count[bits - 1]) &lt;&lt; 1);
			}

			// Check that the bit counts in bl_count are consistent. The last code
			// must be all ones.
			// Assert (code + bl_count[MAX_BITS]-1 == (1&lt;&lt;MAX_BITS)-1,
			// "inconsistent bit counts");
			// Tracev((stderr,"\ngen_codes: max_code %d ", max_code));

			for (n = 0; n &lt;= max_code; n++) {
				len = tree[n * 2 + 1];
				if (len === 0)
					continue;
				// Now reverse the bits
				tree[n * 2] = bi_reverse(next_code[len]++, len);
			}
		}

		// Construct one Huffman tree and assigns the code bit strings and lengths.
		// Update the total bit length for the current block.
		// IN assertion: the field freq is set for all tree elements.
		// OUT assertions: the fields len and code are set to the optimal bit length
		// and corresponding code. The length opt_len is updated; static_len is
		// also updated if stree is not null. The field max_code is set.
		that.build_tree = function(s) {
			var tree = that.dyn_tree;
			var stree = that.stat_desc.static_tree;
			var elems = that.stat_desc.elems;
			var n, m; // iterate over heap elements
			var max_code = -1; // largest code with non zero frequency
			var node; // new node being created

			// Construct the initial heap, with least frequent element in
			// heap[1]. The sons of heap[n] are heap[2*n] and heap[2*n+1].
			// heap[0] is not used.
			s.heap_len = 0;
			s.heap_max = HEAP_SIZE;

			for (n = 0; n &lt; elems; n++) {
				if (tree[n * 2] !== 0) {
					s.heap[++s.heap_len] = max_code = n;
					s.depth[n] = 0;
				} else {
					tree[n * 2 + 1] = 0;
				}
			}

			// The pkzip format requires that at least one distance code exists,
			// and that at least one bit should be sent even if there is only one
			// possible code. So to avoid special checks later on we force at least
			// two codes of non zero frequency.
			while (s.heap_len &lt; 2) {
				node = s.heap[++s.heap_len] = max_code &lt; 2 ? ++max_code : 0;
				tree[node * 2] = 1;
				s.depth[node] = 0;
				s.opt_len--;
				if (stree)
					s.static_len -= stree[node * 2 + 1];
				// node is 0 or 1 so it does not have extra bits
			}
			that.max_code = max_code;

			// The elements heap[heap_len/2+1 .. heap_len] are leaves of the tree,
			// establish sub-heaps of increasing lengths:

			for (n = Math.floor(s.heap_len / 2); n &gt;= 1; n--)
				s.pqdownheap(tree, n);

			// Construct the Huffman tree by repeatedly combining the least two
			// frequent nodes.

			node = elems; // next internal node of the tree
			do {
				// n = node of least frequency
				n = s.heap[1];
				s.heap[1] = s.heap[s.heap_len--];
				s.pqdownheap(tree, 1);
				m = s.heap[1]; // m = node of next least frequency

				s.heap[--s.heap_max] = n; // keep the nodes sorted by frequency
				s.heap[--s.heap_max] = m;

				// Create a new node father of n and m
				tree[node * 2] = (tree[n * 2] + tree[m * 2]);
				s.depth[node] = Math.max(s.depth[n], s.depth[m]) + 1;
				tree[n * 2 + 1] = tree[m * 2 + 1] = node;

				// and insert the new node in the heap
				s.heap[1] = node++;
				s.pqdownheap(tree, 1);
			} while (s.heap_len &gt;= 2);

			s.heap[--s.heap_max] = s.heap[1];

			// At this point, the fields freq and dad are set. We can now
			// generate the bit lengths.

			gen_bitlen(s);

			// The field len is now set, we can generate the bit codes
			gen_codes(tree, that.max_code, s.bl_count);
		};

	}

	Tree._length_code = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16,
			16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20,
			20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
			22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
			24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25,
			25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26,
			26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 28 ];

	Tree.base_length = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 0 ];

	Tree.base_dist = [ 0, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096, 6144, 8192, 12288, 16384,
			24576 ];

	// Mapping from a distance to a distance code. dist is the distance - 1 and
	// must not have side effects. _dist_code[256] and _dist_code[257] are never
	// used.
	Tree.d_code = function(dist) {
		return ((dist) &lt; 256 ? _dist_code[dist] : _dist_code[256 + ((dist) &gt;&gt;&gt; 7)]);
	};

	// extra bits for each length code
	Tree.extra_lbits = [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 ];

	// extra bits for each distance code
	Tree.extra_dbits = [ 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 ];

	// extra bits for each bit length code
	Tree.extra_blbits = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7 ];

	Tree.bl_order = [ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ];

	// StaticTree

	function StaticTree(static_tree, extra_bits, extra_base, elems, max_length) {
		var that = this;
		that.static_tree = static_tree;
		that.extra_bits = extra_bits;
		that.extra_base = extra_base;
		that.elems = elems;
		that.max_length = max_length;
	}

	StaticTree.static_ltree = [ 12, 8, 140, 8, 76, 8, 204, 8, 44, 8, 172, 8, 108, 8, 236, 8, 28, 8, 156, 8, 92, 8, 220, 8, 60, 8, 188, 8, 124, 8, 252, 8, 2, 8,
			130, 8, 66, 8, 194, 8, 34, 8, 162, 8, 98, 8, 226, 8, 18, 8, 146, 8, 82, 8, 210, 8, 50, 8, 178, 8, 114, 8, 242, 8, 10, 8, 138, 8, 74, 8, 202, 8, 42,
			8, 170, 8, 106, 8, 234, 8, 26, 8, 154, 8, 90, 8, 218, 8, 58, 8, 186, 8, 122, 8, 250, 8, 6, 8, 134, 8, 70, 8, 198, 8, 38, 8, 166, 8, 102, 8, 230, 8,
			22, 8, 150, 8, 86, 8, 214, 8, 54, 8, 182, 8, 118, 8, 246, 8, 14, 8, 142, 8, 78, 8, 206, 8, 46, 8, 174, 8, 110, 8, 238, 8, 30, 8, 158, 8, 94, 8,
			222, 8, 62, 8, 190, 8, 126, 8, 254, 8, 1, 8, 129, 8, 65, 8, 193, 8, 33, 8, 161, 8, 97, 8, 225, 8, 17, 8, 145, 8, 81, 8, 209, 8, 49, 8, 177, 8, 113,
			8, 241, 8, 9, 8, 137, 8, 73, 8, 201, 8, 41, 8, 169, 8, 105, 8, 233, 8, 25, 8, 153, 8, 89, 8, 217, 8, 57, 8, 185, 8, 121, 8, 249, 8, 5, 8, 133, 8,
			69, 8, 197, 8, 37, 8, 165, 8, 101, 8, 229, 8, 21, 8, 149, 8, 85, 8, 213, 8, 53, 8, 181, 8, 117, 8, 245, 8, 13, 8, 141, 8, 77, 8, 205, 8, 45, 8,
			173, 8, 109, 8, 237, 8, 29, 8, 157, 8, 93, 8, 221, 8, 61, 8, 189, 8, 125, 8, 253, 8, 19, 9, 275, 9, 147, 9, 403, 9, 83, 9, 339, 9, 211, 9, 467, 9,
			51, 9, 307, 9, 179, 9, 435, 9, 115, 9, 371, 9, 243, 9, 499, 9, 11, 9, 267, 9, 139, 9, 395, 9, 75, 9, 331, 9, 203, 9, 459, 9, 43, 9, 299, 9, 171, 9,
			427, 9, 107, 9, 363, 9, 235, 9, 491, 9, 27, 9, 283, 9, 155, 9, 411, 9, 91, 9, 347, 9, 219, 9, 475, 9, 59, 9, 315, 9, 187, 9, 443, 9, 123, 9, 379,
			9, 251, 9, 507, 9, 7, 9, 263, 9, 135, 9, 391, 9, 71, 9, 327, 9, 199, 9, 455, 9, 39, 9, 295, 9, 167, 9, 423, 9, 103, 9, 359, 9, 231, 9, 487, 9, 23,
			9, 279, 9, 151, 9, 407, 9, 87, 9, 343, 9, 215, 9, 471, 9, 55, 9, 311, 9, 183, 9, 439, 9, 119, 9, 375, 9, 247, 9, 503, 9, 15, 9, 271, 9, 143, 9,
			399, 9, 79, 9, 335, 9, 207, 9, 463, 9, 47, 9, 303, 9, 175, 9, 431, 9, 111, 9, 367, 9, 239, 9, 495, 9, 31, 9, 287, 9, 159, 9, 415, 9, 95, 9, 351, 9,
			223, 9, 479, 9, 63, 9, 319, 9, 191, 9, 447, 9, 127, 9, 383, 9, 255, 9, 511, 9, 0, 7, 64, 7, 32, 7, 96, 7, 16, 7, 80, 7, 48, 7, 112, 7, 8, 7, 72, 7,
			40, 7, 104, 7, 24, 7, 88, 7, 56, 7, 120, 7, 4, 7, 68, 7, 36, 7, 100, 7, 20, 7, 84, 7, 52, 7, 116, 7, 3, 8, 131, 8, 67, 8, 195, 8, 35, 8, 163, 8,
			99, 8, 227, 8 ];

	StaticTree.static_dtree = [ 0, 5, 16, 5, 8, 5, 24, 5, 4, 5, 20, 5, 12, 5, 28, 5, 2, 5, 18, 5, 10, 5, 26, 5, 6, 5, 22, 5, 14, 5, 30, 5, 1, 5, 17, 5, 9, 5,
			25, 5, 5, 5, 21, 5, 13, 5, 29, 5, 3, 5, 19, 5, 11, 5, 27, 5, 7, 5, 23, 5 ];

	StaticTree.static_l_desc = new StaticTree(StaticTree.static_ltree, Tree.extra_lbits, LITERALS + 1, L_CODES, MAX_BITS);

	StaticTree.static_d_desc = new StaticTree(StaticTree.static_dtree, Tree.extra_dbits, 0, D_CODES, MAX_BITS);

	StaticTree.static_bl_desc = new StaticTree(null, Tree.extra_blbits, 0, BL_CODES, MAX_BL_BITS);

	// Deflate

	var MAX_MEM_LEVEL = 9;
	var DEF_MEM_LEVEL = 8;

	function Config(good_length, max_lazy, nice_length, max_chain, func) {
		var that = this;
		that.good_length = good_length;
		that.max_lazy = max_lazy;
		that.nice_length = nice_length;
		that.max_chain = max_chain;
		that.func = func;
	}

	var STORED = 0;
	var FAST = 1;
	var SLOW = 2;
	var config_table = [ new Config(0, 0, 0, 0, STORED), new Config(4, 4, 8, 4, FAST), new Config(4, 5, 16, 8, FAST), new Config(4, 6, 32, 32, FAST),
			new Config(4, 4, 16, 16, SLOW), new Config(8, 16, 32, 32, SLOW), new Config(8, 16, 128, 128, SLOW), new Config(8, 32, 128, 256, SLOW),
			new Config(32, 128, 258, 1024, SLOW), new Config(32, 258, 258, 4096, SLOW) ];

	var z_errmsg = [ "need dictionary", // Z_NEED_DICT
	// 2
	"stream end", // Z_STREAM_END 1
	"", // Z_OK 0
	"", // Z_ERRNO (-1)
	"stream error", // Z_STREAM_ERROR (-2)
	"data error", // Z_DATA_ERROR (-3)
	"", // Z_MEM_ERROR (-4)
	"buffer error", // Z_BUF_ERROR (-5)
	"",// Z_VERSION_ERROR (-6)
	"" ];

	// block not completed, need more input or more output
	var NeedMore = 0;

	// block flush performed
	var BlockDone = 1;

	// finish started, need only more output at next deflate
	var FinishStarted = 2;

	// finish done, accept no more input or output
	var FinishDone = 3;

	// preset dictionary flag in zlib header
	var PRESET_DICT = 0x20;

	var INIT_STATE = 42;
	var BUSY_STATE = 113;
	var FINISH_STATE = 666;

	// The deflate compression method
	var Z_DEFLATED = 8;

	var STORED_BLOCK = 0;
	var STATIC_TREES = 1;
	var DYN_TREES = 2;

	var MIN_MATCH = 3;
	var MAX_MATCH = 258;
	var MIN_LOOKAHEAD = (MAX_MATCH + MIN_MATCH + 1);

	function smaller(tree, n, m, depth) {
		var tn2 = tree[n * 2];
		var tm2 = tree[m * 2];
		return (tn2 &lt; tm2 || (tn2 == tm2 &amp;&amp; depth[n] &lt;= depth[m]));
	}

	function Deflate() {

		var that = this;
		var strm; // pointer back to this zlib stream
		var status; // as the name implies
		// pending_buf; // output still pending
		var pending_buf_size; // size of pending_buf
		// pending_out; // next pending byte to output to the stream
		// pending; // nb of bytes in the pending buffer
		var method; // STORED (for zip only) or DEFLATED
		var last_flush; // value of flush param for previous deflate call

		var w_size; // LZ77 window size (32K by default)
		var w_bits; // log2(w_size) (8..16)
		var w_mask; // w_size - 1

		var window;
		// Sliding window. Input bytes are read into the second half of the window,
		// and move to the first half later to keep a dictionary of at least wSize
		// bytes. With this organization, matches are limited to a distance of
		// wSize-MAX_MATCH bytes, but this ensures that IO is always
		// performed with a length multiple of the block size. Also, it limits
		// the window size to 64K, which is quite useful on MSDOS.
		// To do: use the user input buffer as sliding window.

		var window_size;
		// Actual size of window: 2*wSize, except when the user input buffer
		// is directly used as sliding window.

		var prev;
		// Link to older string with same hash index. To limit the size of this
		// array to 64K, this link is maintained only for the last 32K strings.
		// An index in this array is thus a window index modulo 32K.

		var head; // Heads of the hash chains or NIL.

		var ins_h; // hash index of string to be inserted
		var hash_size; // number of elements in hash table
		var hash_bits; // log2(hash_size)
		var hash_mask; // hash_size-1

		// Number of bits by which ins_h must be shifted at each input
		// step. It must be such that after MIN_MATCH steps, the oldest
		// byte no longer takes part in the hash key, that is:
		// hash_shift * MIN_MATCH &gt;= hash_bits
		var hash_shift;

		// Window position at the beginning of the current output block. Gets
		// negative when the window is moved backwards.

		var block_start;

		var match_length; // length of best match
		var prev_match; // previous match
		var match_available; // set if previous match exists
		var strstart; // start of string to insert
		var match_start; // start of matching string
		var lookahead; // number of valid bytes ahead in window

		// Length of the best match at previous step. Matches not greater than this
		// are discarded. This is used in the lazy match evaluation.
		var prev_length;

		// To speed up deflation, hash chains are never searched beyond this
		// length. A higher limit improves compression ratio but degrades the speed.
		var max_chain_length;

		// Attempt to find a better match only when the current match is strictly
		// smaller than this value. This mechanism is used only for compression
		// levels &gt;= 4.
		var max_lazy_match;

		// Insert new strings in the hash table only if the match length is not
		// greater than this length. This saves time but degrades compression.
		// max_insert_length is used only for compression levels &lt;= 3.

		var level; // compression level (1..9)
		var strategy; // favor or force Huffman coding

		// Use a faster search when the previous match is longer than this
		var good_match;

		// Stop searching when current match exceeds this
		var nice_match;

		var dyn_ltree; // literal and length tree
		var dyn_dtree; // distance tree
		var bl_tree; // Huffman tree for bit lengths

		var l_desc = new Tree(); // desc for literal tree
		var d_desc = new Tree(); // desc for distance tree
		var bl_desc = new Tree(); // desc for bit length tree

		// that.heap_len; // number of elements in the heap
		// that.heap_max; // element of largest frequency
		// The sons of heap[n] are heap[2*n] and heap[2*n+1]. heap[0] is not used.
		// The same heap array is used to build all trees.

		// Depth of each subtree used as tie breaker for trees of equal frequency
		that.depth = [];

		var l_buf; // index for literals or lengths */

		// Size of match buffer for literals/lengths. There are 4 reasons for
		// limiting lit_bufsize to 64K:
		// - frequencies can be kept in 16 bit counters
		// - if compression is not successful for the first block, all input
		// data is still in the window so we can still emit a stored block even
		// when input comes from standard input. (This can also be done for
		// all blocks if lit_bufsize is not greater than 32K.)
		// - if compression is not successful for a file smaller than 64K, we can
		// even emit a stored file instead of a stored block (saving 5 bytes).
		// This is applicable only for zip (not gzip or zlib).
		// - creating new Huffman trees less frequently may not provide fast
		// adaptation to changes in the input data statistics. (Take for
		// example a binary file with poorly compressible code followed by
		// a highly compressible string table.) Smaller buffer sizes give
		// fast adaptation but have of course the overhead of transmitting
		// trees more frequently.
		// - I can't count above 4
		var lit_bufsize;

		var last_lit; // running index in l_buf

		// Buffer for distances. To simplify the code, d_buf and l_buf have
		// the same number of elements. To use different lengths, an extra flag
		// array would be necessary.

		var d_buf; // index of pendig_buf

		// that.opt_len; // bit length of current block with optimal trees
		// that.static_len; // bit length of current block with static trees
		var matches; // number of string matches in current block
		var last_eob_len; // bit length of EOB code for last block

		// Output buffer. bits are inserted starting at the bottom (least
		// significant bits).
		var bi_buf;

		// Number of valid bits in bi_buf. All bits above the last valid bit
		// are always zero.
		var bi_valid;

		// number of codes at each bit length for an optimal tree
		that.bl_count = [];

		// heap used to build the Huffman trees
		that.heap = [];

		dyn_ltree = [];
		dyn_dtree = [];
		bl_tree = [];

		function lm_init() {
			var i;
			window_size = 2 * w_size;

			head[hash_size - 1] = 0;
			for (i = 0; i &lt; hash_size - 1; i++) {
				head[i] = 0;
			}

			// Set the default configuration parameters:
			max_lazy_match = config_table[level].max_lazy;
			good_match = config_table[level].good_length;
			nice_match = config_table[level].nice_length;
			max_chain_length = config_table[level].max_chain;

			strstart = 0;
			block_start = 0;
			lookahead = 0;
			match_length = prev_length = MIN_MATCH - 1;
			match_available = 0;
			ins_h = 0;
		}

		function init_block() {
			var i;
			// Initialize the trees.
			for (i = 0; i &lt; L_CODES; i++)
				dyn_ltree[i * 2] = 0;
			for (i = 0; i &lt; D_CODES; i++)
				dyn_dtree[i * 2] = 0;
			for (i = 0; i &lt; BL_CODES; i++)
				bl_tree[i * 2] = 0;

			dyn_ltree[END_BLOCK * 2] = 1;
			that.opt_len = that.static_len = 0;
			last_lit = matches = 0;
		}

		// Initialize the tree data structures for a new zlib stream.
		function tr_init() {

			l_desc.dyn_tree = dyn_ltree;
			l_desc.stat_desc = StaticTree.static_l_desc;

			d_desc.dyn_tree = dyn_dtree;
			d_desc.stat_desc = StaticTree.static_d_desc;

			bl_desc.dyn_tree = bl_tree;
			bl_desc.stat_desc = StaticTree.static_bl_desc;

			bi_buf = 0;
			bi_valid = 0;
			last_eob_len = 8; // enough lookahead for inflate

			// Initialize the first block of the first file:
			init_block();
		}

		// Restore the heap property by moving down the tree starting at node k,
		// exchanging a node with the smallest of its two sons if necessary,
		// stopping
		// when the heap property is re-established (each father smaller than its
		// two sons).
		that.pqdownheap = function(tree, // the tree to restore
		k // node to move down
		) {
			var heap = that.heap;
			var v = heap[k];
			var j = k &lt;&lt; 1; // left son of k
			while (j &lt;= that.heap_len) {
				// Set j to the smallest of the two sons:
				if (j &lt; that.heap_len &amp;&amp; smaller(tree, heap[j + 1], heap[j], that.depth)) {
					j++;
				}
				// Exit if v is smaller than both sons
				if (smaller(tree, v, heap[j], that.depth))
					break;

				// Exchange v with the smallest son
				heap[k] = heap[j];
				k = j;
				// And continue down the tree, setting j to the left son of k
				j &lt;&lt;= 1;
			}
			heap[k] = v;
		};

		// Scan a literal or distance tree to determine the frequencies of the codes
		// in the bit length tree.
		function scan_tree(tree,// the tree to be scanned
		max_code // and its largest code of non zero frequency
		) {
			var n; // iterates over all tree elements
			var prevlen = -1; // last emitted length
			var curlen; // length of current code
			var nextlen = tree[0 * 2 + 1]; // length of next code
			var count = 0; // repeat count of the current code
			var max_count = 7; // max repeat count
			var min_count = 4; // min repeat count

			if (nextlen === 0) {
				max_count = 138;
				min_count = 3;
			}
			tree[(max_code + 1) * 2 + 1] = 0xffff; // guard

			for (n = 0; n &lt;= max_code; n++) {
				curlen = nextlen;
				nextlen = tree[(n + 1) * 2 + 1];
				if (++count &lt; max_count &amp;&amp; curlen == nextlen) {
					continue;
				} else if (count &lt; min_count) {
					bl_tree[curlen * 2] += count;
				} else if (curlen !== 0) {
					if (curlen != prevlen)
						bl_tree[curlen * 2]++;
					bl_tree[REP_3_6 * 2]++;
				} else if (count &lt;= 10) {
					bl_tree[REPZ_3_10 * 2]++;
				} else {
					bl_tree[REPZ_11_138 * 2]++;
				}
				count = 0;
				prevlen = curlen;
				if (nextlen === 0) {
					max_count = 138;
					min_count = 3;
				} else if (curlen == nextlen) {
					max_count = 6;
					min_count = 3;
				} else {
					max_count = 7;
					min_count = 4;
				}
			}
		}

		// Construct the Huffman tree for the bit lengths and return the index in
		// bl_order of the last bit length code to send.
		function build_bl_tree() {
			var max_blindex; // index of last bit length code of non zero freq

			// Determine the bit length frequencies for literal and distance trees
			scan_tree(dyn_ltree, l_desc.max_code);
			scan_tree(dyn_dtree, d_desc.max_code);

			// Build the bit length tree:
			bl_desc.build_tree(that);
			// opt_len now includes the length of the tree representations, except
			// the lengths of the bit lengths codes and the 5+5+4 bits for the
			// counts.

			// Determine the number of bit length codes to send. The pkzip format
			// requires that at least 4 bit length codes be sent. (appnote.txt says
			// 3 but the actual value used is 4.)
			for (max_blindex = BL_CODES - 1; max_blindex &gt;= 3; max_blindex--) {
				if (bl_tree[Tree.bl_order[max_blindex] * 2 + 1] !== 0)
					break;
			}
			// Update opt_len to include the bit length tree and counts
			that.opt_len += 3 * (max_blindex + 1) + 5 + 5 + 4;

			return max_blindex;
		}

		// Output a byte on the stream.
		// IN assertion: there is enough room in pending_buf.
		function put_byte(p) {
			that.pending_buf[that.pending++] = p;
		}

		function put_short(w) {
			put_byte(w &amp; 0xff);
			put_byte((w &gt;&gt;&gt; 8) &amp; 0xff);
		}

		function putShortMSB(b) {
			put_byte((b &gt;&gt; 8) &amp; 0xff);
			put_byte((b &amp; 0xff) &amp; 0xff);
		}

		function send_bits(value, length) {
			var val, len = length;
			if (bi_valid &gt; Buf_size - len) {
				val = value;
				// bi_buf |= (val &lt;&lt; bi_valid);
				bi_buf |= ((val &lt;&lt; bi_valid) &amp; 0xffff);
				put_short(bi_buf);
				bi_buf = val &gt;&gt;&gt; (Buf_size - bi_valid);
				bi_valid += len - Buf_size;
			} else {
				// bi_buf |= (value) &lt;&lt; bi_valid;
				bi_buf |= (((value) &lt;&lt; bi_valid) &amp; 0xffff);
				bi_valid += len;
			}
		}

		function send_code(c, tree) {
			var c2 = c * 2;
			send_bits(tree[c2] &amp; 0xffff, tree[c2 + 1] &amp; 0xffff);
		}

		// Send a literal or distance tree in compressed form, using the codes in
		// bl_tree.
		function send_tree(tree,// the tree to be sent
		max_code // and its largest code of non zero frequency
		) {
			var n; // iterates over all tree elements
			var prevlen = -1; // last emitted length
			var curlen; // length of current code
			var nextlen = tree[0 * 2 + 1]; // length of next code
			var count = 0; // repeat count of the current code
			var max_count = 7; // max repeat count
			var min_count = 4; // min repeat count

			if (nextlen === 0) {
				max_count = 138;
				min_count = 3;
			}

			for (n = 0; n &lt;= max_code; n++) {
				curlen = nextlen;
				nextlen = tree[(n + 1) * 2 + 1];
				if (++count &lt; max_count &amp;&amp; curlen == nextlen) {
					continue;
				} else if (count &lt; min_count) {
					do {
						send_code(curlen, bl_tree);
					} while (--count !== 0);
				} else if (curlen !== 0) {
					if (curlen != prevlen) {
						send_code(curlen, bl_tree);
						count--;
					}
					send_code(REP_3_6, bl_tree);
					send_bits(count - 3, 2);
				} else if (count &lt;= 10) {
					send_code(REPZ_3_10, bl_tree);
					send_bits(count - 3, 3);
				} else {
					send_code(REPZ_11_138, bl_tree);
					send_bits(count - 11, 7);
				}
				count = 0;
				prevlen = curlen;
				if (nextlen === 0) {
					max_count = 138;
					min_count = 3;
				} else if (curlen == nextlen) {
					max_count = 6;
					min_count = 3;
				} else {
					max_count = 7;
					min_count = 4;
				}
			}
		}

		// Send the header for a block using dynamic Huffman trees: the counts, the
		// lengths of the bit length codes, the literal tree and the distance tree.
		// IN assertion: lcodes &gt;= 257, dcodes &gt;= 1, blcodes &gt;= 4.
		function send_all_trees(lcodes, dcodes, blcodes) {
			var rank; // index in bl_order

			send_bits(lcodes - 257, 5); // not +255 as stated in appnote.txt
			send_bits(dcodes - 1, 5);
			send_bits(blcodes - 4, 4); // not -3 as stated in appnote.txt
			for (rank = 0; rank &lt; blcodes; rank++) {
				send_bits(bl_tree[Tree.bl_order[rank] * 2 + 1], 3);
			}
			send_tree(dyn_ltree, lcodes - 1); // literal tree
			send_tree(dyn_dtree, dcodes - 1); // distance tree
		}

		// Flush the bit buffer, keeping at most 7 bits in it.
		function bi_flush() {
			if (bi_valid == 16) {
				put_short(bi_buf);
				bi_buf = 0;
				bi_valid = 0;
			} else if (bi_valid &gt;= 8) {
				put_byte(bi_buf &amp; 0xff);
				bi_buf &gt;&gt;&gt;= 8;
				bi_valid -= 8;
			}
		}

		// Send one empty static block to give enough lookahead for inflate.
		// This takes 10 bits, of which 7 may remain in the bit buffer.
		// The current inflate code requires 9 bits of lookahead. If the
		// last two codes for the previous block (real code plus EOB) were coded
		// on 5 bits or less, inflate may have only 5+3 bits of lookahead to decode
		// the last real code. In this case we send two empty static blocks instead
		// of one. (There are no problems if the previous block is stored or fixed.)
		// To simplify the code, we assume the worst case of last real code encoded
		// on one bit only.
		function _tr_align() {
			send_bits(STATIC_TREES &lt;&lt; 1, 3);
			send_code(END_BLOCK, StaticTree.static_ltree);

			bi_flush();

			// Of the 10 bits for the empty block, we have already sent
			// (10 - bi_valid) bits. The lookahead for the last real code (before
			// the EOB of the previous block) was thus at least one plus the length
			// of the EOB plus what we have just sent of the empty static block.
			if (1 + last_eob_len + 10 - bi_valid &lt; 9) {
				send_bits(STATIC_TREES &lt;&lt; 1, 3);
				send_code(END_BLOCK, StaticTree.static_ltree);
				bi_flush();
			}
			last_eob_len = 7;
		}

		// Save the match info and tally the frequency counts. Return true if
		// the current block must be flushed.
		function _tr_tally(dist, // distance of matched string
		lc // match length-MIN_MATCH or unmatched char (if dist==0)
		) {
			var out_length, in_length, dcode;
			that.pending_buf[d_buf + last_lit * 2] = (dist &gt;&gt;&gt; 8) &amp; 0xff;
			that.pending_buf[d_buf + last_lit * 2 + 1] = dist &amp; 0xff;

			that.pending_buf[l_buf + last_lit] = lc &amp; 0xff;
			last_lit++;

			if (dist === 0) {
				// lc is the unmatched char
				dyn_ltree[lc * 2]++;
			} else {
				matches++;
				// Here, lc is the match length - MIN_MATCH
				dist--; // dist = match distance - 1
				dyn_ltree[(Tree._length_code[lc] + LITERALS + 1) * 2]++;
				dyn_dtree[Tree.d_code(dist) * 2]++;
			}

			if ((last_lit &amp; 0x1fff) === 0 &amp;&amp; level &gt; 2) {
				// Compute an upper bound for the compressed length
				out_length = last_lit * 8;
				in_length = strstart - block_start;
				for (dcode = 0; dcode &lt; D_CODES; dcode++) {
					out_length += dyn_dtree[dcode * 2] * (5 + Tree.extra_dbits[dcode]);
				}
				out_length &gt;&gt;&gt;= 3;
				if ((matches &lt; Math.floor(last_lit / 2)) &amp;&amp; out_length &lt; Math.floor(in_length / 2))
					return true;
			}

			return (last_lit == lit_bufsize - 1);
			// We avoid equality with lit_bufsize because of wraparound at 64K
			// on 16 bit machines and because stored blocks are restricted to
			// 64K-1 bytes.
		}

		// Send the block data compressed using the given Huffman trees
		function compress_block(ltree, dtree) {
			var dist; // distance of matched string
			var lc; // match length or unmatched char (if dist === 0)
			var lx = 0; // running index in l_buf
			var code; // the code to send
			var extra; // number of extra bits to send

			if (last_lit !== 0) {
				do {
					dist = ((that.pending_buf[d_buf + lx * 2] &lt;&lt; 8) &amp; 0xff00) | (that.pending_buf[d_buf + lx * 2 + 1] &amp; 0xff);
					lc = (that.pending_buf[l_buf + lx]) &amp; 0xff;
					lx++;

					if (dist === 0) {
						send_code(lc, ltree); // send a literal byte
					} else {
						// Here, lc is the match length - MIN_MATCH
						code = Tree._length_code[lc];

						send_code(code + LITERALS + 1, ltree); // send the length
						// code
						extra = Tree.extra_lbits[code];
						if (extra !== 0) {
							lc -= Tree.base_length[code];
							send_bits(lc, extra); // send the extra length bits
						}
						dist--; // dist is now the match distance - 1
						code = Tree.d_code(dist);

						send_code(code, dtree); // send the distance code
						extra = Tree.extra_dbits[code];
						if (extra !== 0) {
							dist -= Tree.base_dist[code];
							send_bits(dist, extra); // send the extra distance bits
						}
					} // literal or match pair ?

					// Check that the overlay between pending_buf and d_buf+l_buf is
					// ok:
				} while (lx &lt; last_lit);
			}

			send_code(END_BLOCK, ltree);
			last_eob_len = ltree[END_BLOCK * 2 + 1];
		}

		// Flush the bit buffer and align the output on a byte boundary
		function bi_windup() {
			if (bi_valid &gt; 8) {
				put_short(bi_buf);
			} else if (bi_valid &gt; 0) {
				put_byte(bi_buf &amp; 0xff);
			}
			bi_buf = 0;
			bi_valid = 0;
		}

		// Copy a stored block, storing first the length and its
		// one's complement if requested.
		function copy_block(buf, // the input data
		len, // its length
		header // true if block header must be written
		) {
			bi_windup(); // align on byte boundary
			last_eob_len = 8; // enough lookahead for inflate

			if (header) {
				put_short(len);
				put_short(~len);
			}

			that.pending_buf.set(window.subarray(buf, buf + len), that.pending);
			that.pending += len;
		}

		// Send a stored block
		function _tr_stored_block(buf, // input block
		stored_len, // length of input block
		eof // true if this is the last block for a file
		) {
			send_bits((STORED_BLOCK &lt;&lt; 1) + (eof ? 1 : 0), 3); // send block type
			copy_block(buf, stored_len, true); // with header
		}

		// Determine the best encoding for the current block: dynamic trees, static
		// trees or store, and output the encoded block to the zip file.
		function _tr_flush_block(buf, // input block, or NULL if too old
		stored_len, // length of input block
		eof // true if this is the last block for a file
		) {
			var opt_lenb, static_lenb;// opt_len and static_len in bytes
			var max_blindex = 0; // index of last bit length code of non zero freq

			// Build the Huffman trees unless a stored block is forced
			if (level &gt; 0) {
				// Construct the literal and distance trees
				l_desc.build_tree(that);

				d_desc.build_tree(that);

				// At this point, opt_len and static_len are the total bit lengths
				// of
				// the compressed block data, excluding the tree representations.

				// Build the bit length tree for the above two trees, and get the
				// index
				// in bl_order of the last bit length code to send.
				max_blindex = build_bl_tree();

				// Determine the best encoding. Compute first the block length in
				// bytes
				opt_lenb = (that.opt_len + 3 + 7) &gt;&gt;&gt; 3;
				static_lenb = (that.static_len + 3 + 7) &gt;&gt;&gt; 3;

				if (static_lenb &lt;= opt_lenb)
					opt_lenb = static_lenb;
			} else {
				opt_lenb = static_lenb = stored_len + 5; // force a stored block
			}

			if ((stored_len + 4 &lt;= opt_lenb) &amp;&amp; buf != -1) {
				// 4: two words for the lengths
				// The test buf != NULL is only necessary if LIT_BUFSIZE &gt; WSIZE.
				// Otherwise we can't have processed more than WSIZE input bytes
				// since
				// the last block flush, because compression would have been
				// successful. If LIT_BUFSIZE &lt;= WSIZE, it is never too late to
				// transform a block into a stored block.
				_tr_stored_block(buf, stored_len, eof);
			} else if (static_lenb == opt_lenb) {
				send_bits((STATIC_TREES &lt;&lt; 1) + (eof ? 1 : 0), 3);
				compress_block(StaticTree.static_ltree, StaticTree.static_dtree);
			} else {
				send_bits((DYN_TREES &lt;&lt; 1) + (eof ? 1 : 0), 3);
				send_all_trees(l_desc.max_code + 1, d_desc.max_code + 1, max_blindex + 1);
				compress_block(dyn_ltree, dyn_dtree);
			}

			// The above check is made mod 2^32, for files larger than 512 MB
			// and uLong implemented on 32 bits.

			init_block();

			if (eof) {
				bi_windup();
			}
		}

		function flush_block_only(eof) {
			_tr_flush_block(block_start &gt;= 0 ? block_start : -1, strstart - block_start, eof);
			block_start = strstart;
			strm.flush_pending();
		}

		// Fill the window when the lookahead becomes insufficient.
		// Updates strstart and lookahead.
		//
		// IN assertion: lookahead &lt; MIN_LOOKAHEAD
		// OUT assertions: strstart &lt;= window_size-MIN_LOOKAHEAD
		// At least one byte has been read, or avail_in === 0; reads are
		// performed for at least two bytes (required for the zip translate_eol
		// option -- not supported here).
		function fill_window() {
			var n, m;
			var p;
			var more; // Amount of free space at the end of the window.

			do {
				more = (window_size - lookahead - strstart);

				// Deal with !@#$% 64K limit:
				if (more === 0 &amp;&amp; strstart === 0 &amp;&amp; lookahead === 0) {
					more = w_size;
				} else if (more == -1) {
					// Very unlikely, but possible on 16 bit machine if strstart ==
					// 0
					// and lookahead == 1 (input done one byte at time)
					more--;

					// If the window is almost full and there is insufficient
					// lookahead,
					// move the upper half to the lower one to make room in the
					// upper half.
				} else if (strstart &gt;= w_size + w_size - MIN_LOOKAHEAD) {
					window.set(window.subarray(w_size, w_size + w_size), 0);

					match_start -= w_size;
					strstart -= w_size; // we now have strstart &gt;= MAX_DIST
					block_start -= w_size;

					// Slide the hash table (could be avoided with 32 bit values
					// at the expense of memory usage). We slide even when level ==
					// 0
					// to keep the hash table consistent if we switch back to level
					// &gt; 0
					// later. (Using level 0 permanently is not an optimal usage of
					// zlib, so we don't care about this pathological case.)

					n = hash_size;
					p = n;
					do {
						m = (head[--p] &amp; 0xffff);
						head[p] = (m &gt;= w_size ? m - w_size : 0);
					} while (--n !== 0);

					n = w_size;
					p = n;
					do {
						m = (prev[--p] &amp; 0xffff);
						prev[p] = (m &gt;= w_size ? m - w_size : 0);
						// If n is not on any hash chain, prev[n] is garbage but
						// its value will never be used.
					} while (--n !== 0);
					more += w_size;
				}

				if (strm.avail_in === 0)
					return;

				// If there was no sliding:
				// strstart &lt;= WSIZE+MAX_DIST-1 &amp;&amp; lookahead &lt;= MIN_LOOKAHEAD - 1 &amp;&amp;
				// more == window_size - lookahead - strstart
				// =&gt; more &gt;= window_size - (MIN_LOOKAHEAD-1 + WSIZE + MAX_DIST-1)
				// =&gt; more &gt;= window_size - 2*WSIZE + 2
				// In the BIG_MEM or MMAP case (not yet supported),
				// window_size == input_size + MIN_LOOKAHEAD &amp;&amp;
				// strstart + s-&gt;lookahead &lt;= input_size =&gt; more &gt;= MIN_LOOKAHEAD.
				// Otherwise, window_size == 2*WSIZE so more &gt;= 2.
				// If there was sliding, more &gt;= WSIZE. So in all cases, more &gt;= 2.

				n = strm.read_buf(window, strstart + lookahead, more);
				lookahead += n;

				// Initialize the hash value now that we have some input:
				if (lookahead &gt;= MIN_MATCH) {
					ins_h = window[strstart] &amp; 0xff;
					ins_h = (((ins_h) &lt;&lt; hash_shift) ^ (window[strstart + 1] &amp; 0xff)) &amp; hash_mask;
				}
				// If the whole input has less than MIN_MATCH bytes, ins_h is
				// garbage,
				// but this is not important since only literal bytes will be
				// emitted.
			} while (lookahead &lt; MIN_LOOKAHEAD &amp;&amp; strm.avail_in !== 0);
		}

		// Copy without compression as much as possible from the input stream,
		// return
		// the current block state.
		// This function does not insert new strings in the dictionary since
		// uncompressible data is probably not useful. This function is used
		// only for the level=0 compression option.
		// NOTE: this function should be optimized to avoid extra copying from
		// window to pending_buf.
		function deflate_stored(flush) {
			// Stored blocks are limited to 0xffff bytes, pending_buf is limited
			// to pending_buf_size, and each stored block has a 5 byte header:

			var max_block_size = 0xffff;
			var max_start;

			if (max_block_size &gt; pending_buf_size - 5) {
				max_block_size = pending_buf_size - 5;
			}

			// Copy as much as possible from input to output:
			while (true) {
				// Fill the window as much as possible:
				if (lookahead &lt;= 1) {
					fill_window();
					if (lookahead === 0 &amp;&amp; flush == Z_NO_FLUSH)
						return NeedMore;
					if (lookahead === 0)
						break; // flush the current block
				}

				strstart += lookahead;
				lookahead = 0;

				// Emit a stored block if pending_buf will be full:
				max_start = block_start + max_block_size;
				if (strstart === 0 || strstart &gt;= max_start) {
					// strstart === 0 is possible when wraparound on 16-bit machine
					lookahead = (strstart - max_start);
					strstart = max_start;

					flush_block_only(false);
					if (strm.avail_out === 0)
						return NeedMore;

				}

				// Flush if we may have to slide, otherwise block_start may become
				// negative and the data will be gone:
				if (strstart - block_start &gt;= w_size - MIN_LOOKAHEAD) {
					flush_block_only(false);
					if (strm.avail_out === 0)
						return NeedMore;
				}
			}

			flush_block_only(flush == Z_FINISH);
			if (strm.avail_out === 0)
				return (flush == Z_FINISH) ? FinishStarted : NeedMore;

			return flush == Z_FINISH ? FinishDone : BlockDone;
		}

		function longest_match(cur_match) {
			var chain_length = max_chain_length; // max hash chain length
			var scan = strstart; // current string
			var match; // matched string
			var len; // length of current match
			var best_len = prev_length; // best match length so far
			var limit = strstart &gt; (w_size - MIN_LOOKAHEAD) ? strstart - (w_size - MIN_LOOKAHEAD) : 0;
			var _nice_match = nice_match;

			// Stop when cur_match becomes &lt;= limit. To simplify the code,
			// we prevent matches with the string of window index 0.

			var wmask = w_mask;

			var strend = strstart + MAX_MATCH;
			var scan_end1 = window[scan + best_len - 1];
			var scan_end = window[scan + best_len];

			// The code is optimized for HASH_BITS &gt;= 8 and MAX_MATCH-2 multiple of
			// 16.
			// It is easy to get rid of this optimization if necessary.

			// Do not waste too much time if we already have a good match:
			if (prev_length &gt;= good_match) {
				chain_length &gt;&gt;= 2;
			}

			// Do not look for matches beyond the end of the input. This is
			// necessary
			// to make deflate deterministic.
			if (_nice_match &gt; lookahead)
				_nice_match = lookahead;

			do {
				match = cur_match;

				// Skip to next match if the match length cannot increase
				// or if the match length is less than 2:
				if (window[match + best_len] != scan_end || window[match + best_len - 1] != scan_end1 || window[match] != window[scan]
						|| window[++match] != window[scan + 1])
					continue;

				// The check at best_len-1 can be removed because it will be made
				// again later. (This heuristic is not always a win.)
				// It is not necessary to compare scan[2] and match[2] since they
				// are always equal when the other bytes match, given that
				// the hash keys are equal and that HASH_BITS &gt;= 8.
				scan += 2;
				match++;

				// We check for insufficient lookahead only every 8th comparison;
				// the 256th check will be made at strstart+258.
				do {
				} while (window[++scan] == window[++match] &amp;&amp; window[++scan] == window[++match] &amp;&amp; window[++scan] == window[++match]
						&amp;&amp; window[++scan] == window[++match] &amp;&amp; window[++scan] == window[++match] &amp;&amp; window[++scan] == window[++match]
						&amp;&amp; window[++scan] == window[++match] &amp;&amp; window[++scan] == window[++match] &amp;&amp; scan &lt; strend);

				len = MAX_MATCH - (strend - scan);
				scan = strend - MAX_MATCH;

				if (len &gt; best_len) {
					match_start = cur_match;
					best_len = len;
					if (len &gt;= _nice_match)
						break;
					scan_end1 = window[scan + best_len - 1];
					scan_end = window[scan + best_len];
				}

			} while ((cur_match = (prev[cur_match &amp; wmask] &amp; 0xffff)) &gt; limit &amp;&amp; --chain_length !== 0);

			if (best_len &lt;= lookahead)
				return best_len;
			return lookahead;
		}

		// Compress as much as possible from the input stream, return the current
		// block state.
		// This function does not perform lazy evaluation of matches and inserts
		// new strings in the dictionary only for unmatched strings or for short
		// matches. It is used only for the fast compression options.
		function deflate_fast(flush) {
			// short hash_head = 0; // head of the hash chain
			var hash_head = 0; // head of the hash chain
			var bflush; // set if current block must be flushed

			while (true) {
				// Make sure that we always have enough lookahead, except
				// at the end of the input file. We need MAX_MATCH bytes
				// for the next match, plus MIN_MATCH bytes to insert the
				// string following the next match.
				if (lookahead &lt; MIN_LOOKAHEAD) {
					fill_window();
					if (lookahead &lt; MIN_LOOKAHEAD &amp;&amp; flush == Z_NO_FLUSH) {
						return NeedMore</pre></div></div></div></div></div></div><div class="drive-viewer-gradient-top" style="display: none;"></div><div class="drive-viewer-gradient-bottom" style="display: none;"></div></div></div></div><div style="opacity: 1;" class="drive-viewer-toolstrip" role="toolbar"><div style="margin-right: 11px; padding-left: 11px;" class="drive-viewer-toolstrip-inner"><div style="left: 11px;" class="drive-viewer-toolstrip-lft"><div aria-label="Icono de JavaScript" style="background-image: url(&quot;//ssl.gstatic.com/docs/doclist/images/mediatype/icon_1_text_x16.png&quot;); background-position: left top; background-repeat: no-repeat;" class="drive-viewer-toolstrip-icon" tabindex="-1" role="img"></div><div class="drive-viewer-toolstrip-metadata" tabindex="-1"><div data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="width: 44px;" class="drive-viewer-toolstrip-name">jspdf.js</div><div class="drive-viewer-toolstrip-name drive-viewer-toolstrip-name-sizing">jspdf.js</div><div style="display: none;" class="drive-viewer-toolstrip-secondary-name"></div><div class="drive-viewer-toolstrip-secondary-name drive-viewer-toolstrip-secondary-name-sizing"></div></div></div><div class="drive-viewer-toolstrip-mid-panel"><div style="" class="drive-viewer-toolstrip-open-and-openwith"><div data-tooltip="Abrir" aria-label="Abrir" aria-hidden="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-toolstrip-open drive-viewer-dark-button goog-inline-block drive-viewer-button"><div style="display: none;" class="drive-viewer-open-app-icon"></div><div class="drive-viewer-open-label">Abrir</div></div><div aria-hidden="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-toolstrip-extract drive-viewer-dark-button goog-inline-block drive-viewer-button drive-viewer-toolstrip-open-has-openwith"><div class="drive-viewer-toolstrip-extract-content">Extraer</div><div class="drive-viewer-toolstrip-extracting-icon"><div class="drive-spinner"><div class="drive-quantum-spinner active"><div class="spinner-layer spinner-blue"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-red"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-yellow"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-green"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div></div></div></div></div><div tabindex="0" aria-hidden="false" data-tooltip="Abrir con" aria-label="Abrir con" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" aria-haspopup="true" aria-expanded="false" style="-moz-user-select: none;" role="button" class="drive-viewer-toolstrip-openwith drive-viewer-dark-button goog-inline-block drive-viewer-button"><div class="drive-viewer-toolstrip-open-separator"></div><div class="drive-viewer-toolstrip-openwith-inner"><div class="drive-viewer-toolstrip-openwith-text" tabindex="-1">Abrir con</div><div class="drive-viewer-toolstrip-menu-button-arrow"><div class="drive-viewer-icon"></div></div></div></div></div><div class="drive-viewer-toolstrip-custom-panel"></div></div><div class="drive-viewer-toolstrip-rgt-panel"><div style="display: none;" class="drive-viewer-popout-button drive-viewer-dark-button" aria-label="Ventana emergente"><div class="drive-viewer-icon drive-viewer-nav-icon"></div></div><div class="drive-viewer-toolstrip-actions"><div tabindex="0" data-tooltip="Añadir a Mi unidad" aria-label="Añadir a Mi unidad" aria-hidden="false" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none;" role="button" class="drive-viewer-toolstrip-add-to-drive drive-viewer-dark-button goog-inline-block drive-viewer-button"><div class="drive-viewer-toolstrip-add-to-my-drive-icon"><div class="drive-spinner"><div class="drive-quantum-spinner active"><div class="spinner-layer spinner-blue"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-red"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-yellow"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div><div class="spinner-layer spinner-green"><div class="spinner-circle-clipper spinner-left"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-gap-patch"><div class="spinner-circle spinner-fit"></div></div><div class="spinner-circle-clipper spinner-right"><div class="spinner-circle spinner-fit"></div></div></div></div></div></div></div><div class="drive-viewer-toolstrip-custom-panel"><div data-tooltip="Añadir un comentario" aria-label="Añadir un comentario" aria-hidden="true" aria-disabled="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-dark-button drive-viewer-custom-button goog-inline-block drive-viewer-button drive-viewer-custom-button-with-icon drive-viewer-button-disabled"><div class="drive-viewer-icon drive-viewer-custom-button-icon drive-viewer-add-comment-icon"></div></div><div data-tooltip="Imprimir" tabindex="0" aria-label="Imprimir" aria-hidden="false" aria-disabled="false" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none;" role="button" class="drive-viewer-dark-button drive-viewer-custom-button goog-inline-block drive-viewer-button drive-viewer-custom-button-with-icon"><div class="drive-viewer-icon drive-viewer-custom-button-icon drive-viewer-print-icon"></div></div><div data-tooltip="Descargar" aria-label="Descargar" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" tabindex="0" style="-moz-user-select: none;" role="button" class="drive-viewer-dark-button drive-viewer-custom-button goog-inline-block drive-viewer-button drive-viewer-custom-button-with-icon"><div class="drive-viewer-icon drive-viewer-custom-button-icon drive-viewer-download-icon"></div></div><div tabindex="0" aria-hidden="false" data-tooltip="Más acciones" aria-label="Más acciones" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" aria-haspopup="true" aria-expanded="false" style="-moz-user-select: none;" role="button" class="drive-viewer-more-button drive-viewer-dark-button goog-inline-block drive-viewer-button"><div class="drive-viewer-icon"></div></div></div></div><div id="one-google-bar" class="drive-viewer-one-google-bar drive-viewer-profile-icon"><div class="gb_Xa gb_9d gb_tb gb_Za" id="gb"><div class="gb_Dc gb_nb gb_Cc gb_5d" ng-non-bindable="" style="padding:0;height:auto;display:block"><div class="gb_Ec gb_8d" style="display:block"><div class="gb_6d"></div><div class="gb_jb gb_9c gb_Mg gb_R gb_Cf gb_rb"><div class="gb_Qc gb_mb gb_Mg gb_R"><a aria-expanded="false" class="gb_b gb_ib gb_R" aria-label="Cuenta de Google: Jose Antonio Albalat  
(proyectojosealbalat@gmail.com)" href="https://accounts.google.com/SignOutOptions?hl=es&amp;continue=https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view&amp;service=writely" role="button" tabindex="0"><span class="gb_db gbii"></span></a><div class="gb_wb"></div><div class="gb_vb"></div></div><div class="gb_xb gb_fa" aria-label="Información de la cuenta" aria-hidden="true"><div class="gb_Ab"><a class="gb_Bb gb_0f gb_Db" aria-label="Cambiar foto de perfil" href="https://profiles.google.com/?hl=es&amp;authuser=0" target="_blank"><div class="gb_Eb gbip" title="Perfil"></div><span class="gb_ob">Cambiar</span></a><div class="gb_Cb"><div class="gb_Fb gb_Hb">Jose Antonio Albalat</div><div class="gb_Ib">proyectojosealbalat@gmail.com</div><div class="gb_zb"><a href="https://myaccount.google.com/privacypolicy" target="_blank">Privacidad</a></div><a class="gb_Ea gb_Wf gbp1 gb_Me gb_Jb" href="https://myaccount.google.com/?utm_source=OGB&amp;authuser=0&amp;utm_medium=act" target="_blank">Mi Cuenta</a></div></div><div class="gb_Ob"><div class="gb_Qb" aria-hidden="false"><a class="gb_Sb gb_0b" href="https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view?authuser=0" target="_blank"><img class="gb_2b gb_Db" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="Perfil" data-src="https://lh3.googleusercontent.com/-dNn56SgAmO8/AAAAAAAAAAI/AAAAAAAAAAA/AIcfdXAjGe_QCIAYQ908NFgNYirJhV0kzw/s48-c-mo/photo.jpg"><div class="gb_Ub"><div class="gb_3b">Jose Antonio Albalat</div><div class="gb_4b">proyectojosealbalat@gmail.com (predeterminada)</div></div></a><a class="gb_Sb" href="https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view?authuser=1" target="_blank"><img class="gb_2b gb_Db" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="Perfil" data-src="https://lh3.googleusercontent.com/-1hizJAOBQlc/AAAAAAAAAAI/AAAAAAAAAAA/AIcfdXDHk6_1RrxAJqtpWlhaskhGHY8s7w/s48-c-mo/photo.jpg"><div class="gb_Ub"><div class="gb_3b">jose antonio albalat almenara</div><div class="gb_4b">josealbalat.9991@gmail.com</div></div></a></div><a class="gb_6b gb_bb" href="https://myaccount.google.com/brandaccounts?authuser=0&amp;continue=https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view&amp;service=/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view%3Fauthuser%3D%24authuser" aria-hidden="true"><span class="gb_7b gb_hc"></span><div class="gb_8b">Todas tus cuentas de marca »</div></a></div><div class="gb_pb gb_bb"><div class="gb_qb"></div></div><div class="gb_Kb"><div><a class="gb_Ea gb_Vf gb_Me gb_Jb" href="https://accounts.google.com/AddSession?service=wise&amp;continue=https://drive.google.com/file/d/0BwHqLHKAfVJeUGVDRmw1aWZCQUk/view" target="_blank">Añadir cuenta</a></div><div><a class="gb_Ea gb_Xf gb_5f gb_Me gb_Jb" id="gb_71" href="https://accounts.google.com/Logout?service=wise&amp;continue=https://docs.google.com" target="_top">Cerrar sesión</a></div></div></div></div></div></div></div><script>/* _GlobalPrefix_ */
this.gbar_=this.gbar_||{};(function(_){var window=this;
/* _Module_:syc */
try{
_.Ic=!_.y||_.rb(9);_.Jc=!_.y||_.rb(9);_.Kc=_.y&&!_.pb("9");_.Lc=function(){if(!_.l.addEventListener||!Object.defineProperty)return!1;var a=!1,c=Object.defineProperty({},"passive",{get:function(){a=!0}});_.l.addEventListener("test",_.na,c);_.l.removeEventListener("test",_.na,c);return a}();
var Mc;Mc=function(a){return _.$a?"webkit"+a:_.Wa?"o"+a.toLowerCase():a.toLowerCase()};_.Nc=Mc("AnimationEnd");_.Oc=Mc("TransitionEnd");
}catch(e){_._DumpException(e)}
/* _Module_:sye */
try{
_.Pc=function(a,c,d){if(!a.f)if(d instanceof Array)for(var e in d)_.Pc(a,c,d[e]);else{e=(0,_.r)(a.B,a,c);var f=a.w+d;a.w++;c.setAttribute("data-eqid",f);a.o[f]=e;c&&c.addEventListener?c.addEventListener(d,e,!1):c&&c.attachEvent?c.attachEvent("on"+d,e):a.A.log(Error("d`"+c))}};

}catch(e){_._DumpException(e)}
/* _Module_:qaaw */
try{
var Qc=window.document.querySelector(".gb_da .gb_b");Qc&&_.Pc(_.yc,Qc,"click");
}catch(e){_._DumpException(e)}
/* _Module_:syh */
try{
_.Rc=function(a,c){var d=Array.prototype.slice.call(arguments,1);return function(){var c=d.slice();c.push.apply(c,arguments);return a.apply(this,c)}};
}catch(e){_._DumpException(e)}
/* _Module_:syg */
try{
var Sc,Tc;Sc=null;Tc=/^[\w+/_-]+[=]{0,2}$/;_.Uc=function(){if(null===Sc){var a;a:{if((a=_.l.document.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&Tc.test(a))break a;a=null}Sc=a||""}return Sc};_.Vc=function(a){var c=_.pa(a);return"array"==c||"object"==c&&"number"==typeof a.length};_.Wc=function(a){var c=a.length;if(0<c){for(var d=Array(c),e=0;e<c;e++)d[e]=a[e];return d}return[]};_.Xc=!_.y||_.rb(9);_.Yc=!_.Za&&!_.y||_.y&&_.rb(9)||_.Za&&_.pb("1.9.1");_.Zc=_.y&&!_.pb("9"); _.$c=_.y||_.Wa||_.$a;
_.bd=function(){this.b="";this.f=_.ad};_.bd.prototype.Fb=!0;_.bd.prototype.kb=function(){return this.b};_.bd.prototype.toString=function(){return"Const{"+this.b+"}"};_.ad={};_.cd=function(a){var c=new _.bd;c.b=a;return c};_.cd("");_.ed=function(){this.b="";this.f=_.dd};_.ed.prototype.Fb=!0;_.dd={};_.ed.prototype.kb=function(){return this.b};_.fd=function(a){var c=new _.ed;c.b=a;return c};_.fd("");var gd;_.hd=function(){this.f="";this.j=gd};_.hd.prototype.Fb=!0;_.hd.prototype.kb=function(){return this.f};_.hd.prototype.re=!0;_.hd.prototype.b=function(){return 1};_.id=function(a){if(a instanceof _.hd&&a.constructor===_.hd&&a.j===gd)return a.f;_.pa(a);return"type_error:TrustedResourceUrl"};gd={};_.jd=function(a){var c=new _.hd;c.f=a;return c};
_.ld=function(){this.f="";this.j=_.kd};_.ld.prototype.Fb=!0;_.ld.prototype.kb=function(){return this.f};_.ld.prototype.re=!0;_.ld.prototype.b=function(){return 1};_.md=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;_.kd={};_.nd=function(a){var c=new _.ld;c.f=a;return c};_.nd("about:blank");
_.pd=function(){this.b="";this.f=_.od};_.pd.prototype.Fb=!0;_.od={};_.pd.prototype.kb=function(){return this.b};_.qd=function(a){var c=new _.pd;c.b=a;return c};_.rd=_.qd("");_.td=function(){this.f="";this.o=_.sd;this.j=null};_.td.prototype.re=!0;_.td.prototype.b=function(){return this.j};_.td.prototype.Fb=!0;_.td.prototype.kb=function(){return this.f};_.sd={};_.ud=function(a,c){var d=new _.td;d.f=a;d.j=c;return d};_.ud("<!DOCTYPE html>",0);_.vd=_.ud("",0);_.wd=_.ud("<br>",0);
_.xd=function(a,c){a.src=_.id(c);if(c=_.Uc())a.nonce=c};_.yd=function(a,c){return _.n(c)?a.getElementById(c):c};_.zd=function(a,c){return(c||window.document).getElementsByTagName(String(a))};_.Ad=function(a){return window.document.createElement(String(a))};_.Bd=function(a){return a&&a.parentNode?a.parentNode.removeChild(a):null};

}catch(e){_._DumpException(e)}
/* _Module_:syf */
try{
var Cd,Ed;Cd=function(a){var c=arguments.length;if(1==c&&_.p(arguments[0]))return Cd.apply(null,arguments[0]);for(var d={},e=0;e<c;e++)d[arguments[e]]=!0;return d};_.Dd=function(a){return _.ra(a)&&1==a.nodeType};Cd("A AREA BUTTON HEAD INPUT LINK MENU META OPTGROUP OPTION PROGRESS STYLE SELECT SOURCE TEXTAREA TITLE TRACK".split(" "));_.Fd=function(a,c){c?a.setAttribute("role",c):a.removeAttribute("role")};
_.L=function(a,c,d){_.p(d)&&(d=d.join(" "));var e="aria-"+c;""===d||void 0==d?(Ed||(Ed={atomic:!1,autocomplete:"none",dropeffect:"none",haspopup:!1,live:"off",multiline:!1,multiselectable:!1,orientation:"vertical",readonly:!1,relevant:"additions text",required:!1,sort:"none",busy:!1,disabled:!1,hidden:!1,invalid:"false"}),d=Ed,c in d?a.setAttribute(e,d[c]):a.removeAttribute(e)):a.setAttribute(e,d)};

}catch(e){_._DumpException(e)}
/* _Module_:syj */
try{
_.Gd=function(a){a=a.split(".");for(var c=_.l,d=0;d<a.length;d++)if(c=c[a[d]],null==c)return null;return c};_.Hd=function(a,c){return 0==a.lastIndexOf(c,0)};_.Id=function(a){return _.cc(_.Zb.ra(),a)};
}catch(e){_._DumpException(e)}
/* _Module_:syi */
try{
var Kd;_.Jd=function(a,c){c=(0,_.xa)(a,c);var d;(d=0<=c)&&Array.prototype.splice.call(a,c,1);return d};Kd=function(a,c){for(var d in a)if(c.call(void 0,a[d],d,a))return!0;return!1};_.Ld=function(a,c){try{return _.Ta(a[c]),!0}catch(d){}return!1};_.Md=function(a,c){this.type=a;this.b=this.target=c;this.j=!1;this.Rf=!0};_.Md.prototype.stopPropagation=function(){this.j=!0};_.Md.prototype.preventDefault=function(){this.Rf=!1};_.Nd=function(a,c){_.Md.call(this,a?a.type:"");this.relatedTarget=this.b=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=0;this.key="";this.f=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.ab=null;a&&this.init(a,c)};_.v(_.Nd,_.Md);var Od={2:"touch",3:"pen",4:"mouse"};
_.Nd.prototype.init=function(a,c){var d=this.type=a.type,e=a.changedTouches?a.changedTouches[0]:null;this.target=a.target||a.srcElement;this.b=c;(c=a.relatedTarget)?_.Za&&(_.Ld(c,"nodeName")||(c=null)):"mouseover"==d?c=a.fromElement:"mouseout"==d&&(c=a.toElement);this.relatedTarget=c;null===e?(this.clientX=void 0!==a.clientX?a.clientX:a.pageX,this.clientY=void 0!==a.clientY?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0):(this.clientX=void 0!==e.clientX?e.clientX:e.pageX,this.clientY=
void 0!==e.clientY?e.clientY:e.pageY,this.screenX=e.screenX||0,this.screenY=e.screenY||0);this.button=a.button;this.keyCode=a.keyCode||0;this.key=a.key||"";this.f=a.charCode||("keypress"==d?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.pointerId=a.pointerId||0;this.pointerType=_.n(a.pointerType)?a.pointerType:Od[a.pointerType]||"";this.state=a.state;this.ab=a;a.defaultPrevented&&this.preventDefault()};
_.Nd.prototype.stopPropagation=function(){_.Nd.J.stopPropagation.call(this);this.ab.stopPropagation?this.ab.stopPropagation():this.ab.cancelBubble=!0};_.Nd.prototype.preventDefault=function(){_.Nd.J.preventDefault.call(this);var a=this.ab;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,_.Kc)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(c){}};
var Rd;_.Pd="closure_listenable_"+(1E6*Math.random()|0);_.Qd=function(a){return!(!a||!a[_.Pd])};Rd=0;var Sd;Sd=function(a,c,d,e,f){this.listener=a;this.b=null;this.src=c;this.type=d;this.capture=!!e;this.Bd=f;this.key=++Rd;this.Lc=this.qd=!1};_.Td=function(a){a.Lc=!0;a.listener=null;a.b=null;a.src=null;a.Bd=null};_.Ud=function(a){this.src=a;this.b={};this.f=0};_.Ud.prototype.add=function(a,c,d,e,f){var g=a.toString();a=this.b[g];a||(a=this.b[g]=[],this.f++);var h=Vd(a,c,e,f);-1<h?(c=a[h],d||(c.qd=!1)):(c=new Sd(c,this.src,g,!!e,f),c.qd=d,a.push(c));return c};_.Ud.prototype.remove=function(a,c,d,e){a=a.toString();if(!(a in this.b))return!1;var f=this.b[a];c=Vd(f,c,d,e);return-1<c?(_.Td(f[c]),Array.prototype.splice.call(f,c,1),0==f.length&&(delete this.b[a],this.f--),!0):!1};
_.Wd=function(a,c){var d=c.type;if(!(d in a.b))return!1;var e=_.Jd(a.b[d],c);e&&(_.Td(c),0==a.b[d].length&&(delete a.b[d],a.f--));return e};_.Ud.prototype.Fc=function(a,c){a=this.b[a.toString()];var d=[];if(a)for(var e=0;e<a.length;++e){var f=a[e];f.capture==c&&d.push(f)}return d};_.Ud.prototype.kc=function(a,c,d,e){a=this.b[a.toString()];var f=-1;a&&(f=Vd(a,c,d,e));return-1<f?a[f]:null};
_.Ud.prototype.hasListener=function(a,c){var d=_.la(a),e=d?a.toString():"",f=_.la(c);return Kd(this.b,function(a){for(var g=0;g<a.length;++g)if(!(d&&a[g].type!=e||f&&a[g].capture!=c))return!0;return!1})};var Vd=function(a,c,d,e){for(var f=0;f<a.length;++f){var g=a[f];if(!g.Lc&&g.listener==c&&g.capture==!!d&&g.Bd==e)return f}return-1};
var Xd,Yd,Zd,be,de,ee,je,ie,fe,ke;Xd="closure_lm_"+(1E6*Math.random()|0);Yd={};Zd=0;_.M=function(a,c,d,e,f){if(e&&e.once)return _.$d(a,c,d,e,f);if(_.p(c)){for(var g=0;g<c.length;g++)_.M(a,c[g],d,e,f);return null}d=_.ae(d);return _.Qd(a)?a.K(c,d,_.ra(e)?!!e.capture:!!e,f):be(a,c,d,!1,e,f)};
be=function(a,c,d,e,f,g){if(!c)throw Error("n");var h=_.ra(f)?!!f.capture:!!f,m=_.ce(a);m||(a[Xd]=m=new _.Ud(a));d=m.add(c,d,e,h,g);if(d.b)return d;e=de();d.b=e;e.src=a;e.listener=d;if(a.addEventListener)_.Lc||(f=h),void 0===f&&(f=!1),a.addEventListener(c.toString(),e,f);else if(a.attachEvent)a.attachEvent(ee(c.toString()),e);else if(a.addListener&&a.removeListener)a.addListener(e);else throw Error("o");Zd++;return d};
de=function(){var a=fe,c=_.Jc?function(d){return a.call(c.src,c.listener,d)}:function(d){d=a.call(c.src,c.listener,d);if(!d)return d};return c};_.$d=function(a,c,d,e,f){if(_.p(c)){for(var g=0;g<c.length;g++)_.$d(a,c[g],d,e,f);return null}d=_.ae(d);return _.Qd(a)?a.nb(c,d,_.ra(e)?!!e.capture:!!e,f):be(a,c,d,!0,e,f)};_.ge=function(a,c,d,e,f){if(_.p(c))for(var g=0;g<c.length;g++)_.ge(a,c[g],d,e,f);else e=_.ra(e)?!!e.capture:!!e,d=_.ae(d),_.Qd(a)?a.Fa(c,d,e,f):a&&(a=_.ce(a))&&(c=a.kc(c,d,e,f))&&_.he(c)};
_.he=function(a){if(_.ma(a)||!a||a.Lc)return!1;var c=a.src;if(_.Qd(c))return c.Rd(a);var d=a.type,e=a.b;c.removeEventListener?c.removeEventListener(d,e,a.capture):c.detachEvent?c.detachEvent(ee(d),e):c.addListener&&c.removeListener&&c.removeListener(e);Zd--;(d=_.ce(c))?(_.Wd(d,a),0==d.f&&(d.src=null,c[Xd]=null)):_.Td(a);return!0};ee=function(a){return a in Yd?Yd[a]:Yd[a]="on"+a};
je=function(a,c,d,e){var f=!0;if(a=_.ce(a))if(c=a.b[c.toString()])for(c=c.concat(),a=0;a<c.length;a++){var g=c[a];g&&g.capture==d&&!g.Lc&&(g=ie(g,e),f=f&&!1!==g)}return f};ie=function(a,c){var d=a.listener,e=a.Bd||a.src;a.qd&&_.he(a);return d.call(e,c)};
fe=function(a,c){if(a.Lc)return!0;if(!_.Jc){var d=c||_.Gd("window.event");c=new _.Nd(d,this);var e=!0;if(!(0>d.keyCode||void 0!=d.returnValue)){a:{var f=!1;if(0==d.keyCode)try{d.keyCode=-1;break a}catch(h){f=!0}if(f||void 0==d.returnValue)d.returnValue=!0}d=[];for(f=c.b;f;f=f.parentNode)d.push(f);a=a.type;for(f=d.length-1;!c.j&&0<=f;f--){c.b=d[f];var g=je(d[f],a,!0,c);e=e&&g}for(f=0;!c.j&&f<d.length;f++)c.b=d[f],g=je(d[f],a,!1,c),e=e&&g}return e}return ie(a,new _.Nd(c,this))}; _.ce=function(a){a=a[Xd];return a instanceof _.Ud?a:null};ke="__closure_events_fn_"+(1E9*Math.random()>>>0);_.ae=function(a){if(_.qa(a))return a;a[ke]||(a[ke]=function(c){return a.handleEvent(c)});return a[ke]};

}catch(e){_._DumpException(e)}
/* _Module_:syl */
try{
_.le=function(a,c,d){return 2>=arguments.length?Array.prototype.slice.call(a,c):Array.prototype.slice.call(a,c,d)};_.N=function(){_.F.call(this);this.Eb=new _.Ud(this);this.kg=this;this.Ee=null};_.v(_.N,_.F);_.N.prototype[_.Pd]=!0;_.k=_.N.prototype;_.k.Qc=function(){return this.Ee};_.k.yc=function(a){this.Ee=a};_.k.addEventListener=function(a,c,d,e){_.M(this,a,c,d,e)};_.k.removeEventListener=function(a,c,d,e){_.ge(this,a,c,d,e)};
_.k.dispatchEvent=function(a){var c,d=this.Qc();if(d)for(c=[];d;d=d.Qc())c.push(d);d=this.kg;var e=a.type||a;if(_.n(a))a=new _.Md(a,d);else if(a instanceof _.Md)a.target=a.target||d;else{var f=a;a=new _.Md(e,d);_.Na(a,f)}f=!0;if(c)for(var g=c.length-1;!a.j&&0<=g;g--){var h=a.b=c[g];f=h.Cc(e,!0,a)&&f}a.j||(h=a.b=d,f=h.Cc(e,!0,a)&&f,a.j||(f=h.Cc(e,!1,a)&&f));if(c)for(g=0;!a.j&&g<c.length;g++)h=a.b=c[g],f=h.Cc(e,!1,a)&&f;return f};_.k.O=function(){_.N.J.O.call(this);this.Kd();this.Ee=null};
_.k.K=function(a,c,d,e){return this.Eb.add(String(a),c,!1,d,e)};_.k.nb=function(a,c,d,e){return this.Eb.add(String(a),c,!0,d,e)};_.k.Fa=function(a,c,d,e){return this.Eb.remove(String(a),c,d,e)};_.k.Rd=function(a){return _.Wd(this.Eb,a)};_.k.Kd=function(a){if(this.Eb){var c=this.Eb;a=a&&a.toString();var d=0,e;for(e in c.b)if(!a||e==a){for(var f=c.b[e],g=0;g<f.length;g++)++d,_.Td(f[g]);delete c.b[e];c.f--}c=d}else c=0;return c};
_.k.Cc=function(a,c,d){a=this.Eb.b[String(a)];if(!a)return!0;a=a.concat();for(var e=!0,f=0;f<a.length;++f){var g=a[f];if(g&&!g.Lc&&g.capture==c){var h=g.listener,m=g.Bd||g.src;g.qd&&this.Rd(g);e=!1!==h.call(m,d)&&e}}return e&&0!=d.Rf};_.k.Fc=function(a,c){return this.Eb.Fc(String(a),c)};_.k.kc=function(a,c,d,e){return this.Eb.kc(String(a),c,d,e)};_.k.hasListener=function(a,c){return this.Eb.hasListener(_.la(a)?String(a):void 0,c)};

}catch(e){_._DumpException(e)}
/* _Module_:sym */
try{
var pe;_.me=function(a,c){if(void 0!==a.b||void 0!==a.f)throw Error("f");a.b=c;_.mc(a)};_.ne=function(a){return/^[\s\xa0]*$/.test(a)};_.oe=function(a){var c=[],d=0,e;for(e in a)c[d++]=a[e];return c};pe=function(a,c){this.j=a;this.o=c;this.f=0;this.b=null};pe.prototype.get=function(){if(0<this.f){this.f--;var a=this.b;this.b=a.next;a.next=null}else a=this.j();return a};var qe=function(a,c){a.o(c);100>a.f&&(a.f++,c.next=a.b,a.b=c)};
var re;re=function(a){return function(){return a}};_.se=re(!0);_.te=re(null);_.ue=function(a){return a};var ve=function(a){_.l.setTimeout(function(){throw a;},0)},we,xe=function(){var a=_.l.MessageChannel;"undefined"===typeof a&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!_.x("Presto")&&(a=function(){var a=window.document.createElement("IFRAME");a.style.display="none";a.src="";window.document.documentElement.appendChild(a);var c=a.contentWindow;a=c.document;a.open();a.write("");a.close();var d="callImmediate"+Math.random(),e="file:"==c.location.protocol?"*":c.location.protocol+
"//"+c.location.host;a=(0,_.r)(function(a){if(("*"==e||a.origin==e)&&a.data==d)this.port1.onmessage()},this);c.addEventListener("message",a,!1);this.port1={};this.port2={postMessage:function(){c.postMessage(d,e)}}});if("undefined"!==typeof a&&!_.x("Trident")&&!_.x("MSIE")){var c=new a,d={},e=d;c.port1.onmessage=function(){if(_.la(d.next)){d=d.next;var a=d.Re;d.Re=null;a()}};return function(a){e.next={Re:a};e=e.next;c.port2.postMessage(0)}}return"undefined"!==typeof window.document&&"onreadystatechange"in
window.document.createElement("SCRIPT")?function(a){var c=window.document.createElement("SCRIPT");c.onreadystatechange=function(){c.onreadystatechange=null;c.parentNode.removeChild(c);c=null;a();a=null};window.document.documentElement.appendChild(c)}:function(a){_.l.setTimeout(a,0)}};
var ye=function(){this.f=this.b=null},Ae=new pe(function(){return new ze},function(a){a.reset()});ye.prototype.add=function(a,c){var d=Ae.get();d.set(a,c);this.f?this.f.next=d:this.b=d;this.f=d};ye.prototype.remove=function(){var a=null;this.b&&(a=this.b,this.b=this.b.next,this.b||(this.f=null),a.next=null);return a};var ze=function(){this.next=this.scope=this.b=null};ze.prototype.set=function(a,c){this.b=a;this.scope=c;this.next=null};ze.prototype.reset=function(){this.next=this.scope=this.b=null};
var Fe=function(a,c){Be||Ce();De||(Be(),De=!0);Ee.add(a,c)},Be,Ce=function(){if(_.l.Promise&&_.l.Promise.resolve){var a=_.l.Promise.resolve(void 0);Be=function(){a.then(Ge)}}else Be=function(){var a=Ge;!_.qa(_.l.setImmediate)||_.l.Window&&_.l.Window.prototype&&!_.x("Edge")&&_.l.Window.prototype.setImmediate==_.l.setImmediate?(we||(we=xe()),we(a)):_.l.setImmediate(a)}},De=!1,Ee=new ye,Ge=function(){for(var a;a=Ee.remove();){try{a.b.call(a.scope)}catch(c){ve(c)}qe(Ae,a)}De=!1};
_.He=function(a){a.prototype.then=a.prototype.then;a.prototype.$goog_Thenable=!0};_.Ie=function(a){if(!a)return!1;try{return!!a.$goog_Thenable}catch(c){return!1}};var Le,Qe,Ue,Se,Xe,We,Ye;_.Ke=function(a,c){this.b=0;this.B=void 0;this.o=this.f=this.j=null;this.A=this.w=!1;if(a!=_.na)try{var d=this;a.call(c,function(a){Je(d,2,a)},function(a){Je(d,3,a)})}catch(e){Je(this,3,e)}};Le=function(){this.next=this.context=this.f=this.j=this.b=null;this.o=!1};Le.prototype.reset=function(){this.context=this.f=this.j=this.b=null;this.o=!1};var Me=new pe(function(){return new Le},function(a){a.reset()}),Ne=function(a,c,d){var e=Me.get();e.j=a;e.f=c;e.context=d;return e};
_.Ke.prototype.then=function(a,c,d){return _.Oe(this,_.qa(a)?a:null,_.qa(c)?c:null,d)};_.He(_.Ke);_.Ke.prototype.cancel=function(a){0==this.b&&Fe(function(){var c=new _.Pe(a);Qe(this,c)},this)};Qe=function(a,c){if(0==a.b)if(a.j){var d=a.j;if(d.f){for(var e=0,f=null,g=null,h=d.f;h&&(h.o||(e++,h.b==a&&(f=h),!(f&&1<e)));h=h.next)f||(g=h);f&&(0==d.b&&1==e?Qe(d,c):(g?(e=g,e.next==d.o&&(d.o=e),e.next=e.next.next):Re(d),Se(d,f,3,c)))}a.j=null}else Je(a,3,c)};
Ue=function(a,c){a.f||2!=a.b&&3!=a.b||Te(a);a.o?a.o.next=c:a.f=c;a.o=c};_.Oe=function(a,c,d,e){var f=Ne(null,null,null);f.b=new _.Ke(function(a,h){f.j=c?function(d){try{var f=c.call(e,d);a(f)}catch(t){h(t)}}:a;f.f=d?function(c){try{var f=d.call(e,c);!_.la(f)&&c instanceof _.Pe?h(c):a(f)}catch(t){h(t)}}:h});f.b.j=a;Ue(a,f);return f.b};_.Ke.prototype.D=function(a){this.b=0;Je(this,2,a)};_.Ke.prototype.F=function(a){this.b=0;Je(this,3,a)};
var Je=function(a,c,d){if(0==a.b){a===d&&(c=3,d=new TypeError("Promise cannot resolve to itself"));a.b=1;a:{var e=d,f=a.D,g=a.F;if(e instanceof _.Ke){Ue(e,Ne(f||_.na,g||null,a));var h=!0}else if(_.Ie(e))e.then(f,g,a),h=!0;else{if(_.ra(e))try{var m=e.then;if(_.qa(m)){Ve(e,m,f,g,a);h=!0;break a}}catch(q){g.call(a,q);h=!0;break a}h=!1}}h||(a.B=d,a.b=c,a.j=null,Te(a),3!=c||d instanceof _.Pe||We(a,d))}},Ve=function(a,c,d,e,f){var g=!1,h=function(a){g||(g=!0,d.call(f,a))},m=function(a){g||(g=!0,e.call(f,
a))};try{c.call(a,h,m)}catch(q){m(q)}},Te=function(a){a.w||(a.w=!0,Fe(a.C,a))},Re=function(a){var c=null;a.f&&(c=a.f,a.f=c.next,c.next=null);a.f||(a.o=null);return c};_.Ke.prototype.C=function(){for(var a;a=Re(this);)Se(this,a,this.b,this.B);this.w=!1};Se=function(a,c,d,e){if(3==d&&c.f&&!c.o)for(;a&&a.A;a=a.j)a.A=!1;if(c.b)c.b.j=null,Xe(c,d,e);else try{c.o?c.j.call(c.context):Xe(c,d,e)}catch(f){Ye.call(null,f)}qe(Me,c)};Xe=function(a,c,d){2==c?a.j.call(a.context,d):a.f&&a.f.call(a.context,d)}; We=function(a,c){a.A=!0;Fe(function(){a.A&&Ye.call(null,c)})};Ye=ve;_.Pe=function(a){_.wa.call(this,a)};_.v(_.Pe,_.wa);_.Pe.prototype.name="cancel";

}catch(e){_._DumpException(e)}
/* _Module_:syn */
try{
var af;_.Ze=function(a){a&&"function"==typeof a.ha&&a.ha()};_.$e=function(a,c){c=_.Rc(_.Ze,c);a.Ga?_.la(void 0)?c.call(void 0):c():(a.Bb||(a.Bb=[]),a.Bb.push(_.la(void 0)?(0,_.r)(c,void 0):c))};af=0;_.bf=function(a){return a[_.sa]||(a[_.sa]=++af)};_.cf=function(a,c){_.N.call(this);this.f=a||1;this.b=c||_.l;this.j=(0,_.r)(this.lj,this);this.o=(0,_.va)()};_.v(_.cf,_.N);_.k=_.cf.prototype;_.k.Vb=!1;_.k.lb=null;
_.k.lj=function(){if(this.Vb){var a=(0,_.va)()-this.o;0<a&&a<.8*this.f?this.lb=this.b.setTimeout(this.j,this.f-a):(this.lb&&(this.b.clearTimeout(this.lb),this.lb=null),this.dispatchEvent("tick"),this.Vb&&(this.lb=this.b.setTimeout(this.j,this.f),this.o=(0,_.va)()))}};_.k.start=function(){this.Vb=!0;this.lb||(this.lb=this.b.setTimeout(this.j,this.f),this.o=(0,_.va)())};_.k.stop=function(){this.Vb=!1;this.lb&&(this.b.clearTimeout(this.lb),this.lb=null)};
_.k.O=function(){_.cf.J.O.call(this);this.stop();delete this.b};_.df=function(a,c,d){if(_.qa(a))d&&(a=(0,_.r)(a,d));else if(a&&"function"==typeof a.handleEvent)a=(0,_.r)(a.handleEvent,a);else throw Error("p");return 2147483647<Number(c)?-1:_.l.setTimeout(a,c||0)};

}catch(e){_._DumpException(e)}
/* _Module_:syt */
try{
var ef,ff,gf,hf,jf,kf,lf,mf,qf,xf,Bf,Cf,Df;ff=/&/g;gf=/</g;hf=/>/g;jf=/"/g;kf=/'/g;lf=/\x00/g;mf=/[\x00&<>"']/;_.nf=function(a){if(!mf.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(ff,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(gf,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(hf,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(jf,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(kf,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(lf,"&#0;"));return a};
_.of=function(a){return String(a).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g,"\\$1").replace(/\x08/g,"\\x08")};_.pf=function(a){return String(a).replace(/\-([a-z])/g,function(a,d){return d.toUpperCase()})};qf=function(a){var c=_.n(void 0)?_.of(void 0):"\\s";return a.replace(new RegExp("(^"+(c?"|["+c+"]+":"")+")([a-z])","g"),function(a,c,f){return c+f.toUpperCase()})};_.rf=function(a,c,d){for(var e in a)c.call(d,a[e],e,a)};_.sf=function(a,c){this.width=a;this.height=c};
_.tf=function(a){return new _.sf(a.width,a.height)};_.k=_.sf.prototype;_.k.mg=function(){return this.width*this.height};_.k.aspectRatio=function(){return this.width/this.height};_.k.tc=function(){return!this.mg()};_.k.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};_.k.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
_.k.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};_.uf=function(a,c){return a==c?!0:a&&c?a.width==c.width&&a.height==c.height:!1};_.vf=function(a){return 9==a.nodeType?a:a.ownerDocument||a.document};
_.wf=function(a,c,d){var e;a=d||a;if(a.querySelectorAll&&a.querySelector&&c)return a.querySelectorAll(c?"."+c:"");if(c&&a.getElementsByClassName){var f=a.getElementsByClassName(c);return f}f=a.getElementsByTagName("*");if(c){var g={};for(d=e=0;a=f[d];d++){var h=a.className;"function"==typeof h.split&&_.Ea(h.split(/\s+/),c)&&(g[e++]=a)}g.length=e;return g}return f};
_.P=function(a,c){var d=c||window.document;if(d.getElementsByClassName)a=d.getElementsByClassName(a)[0];else{d=window.document;var e=c||d;a=e.querySelectorAll&&e.querySelector&&a?e.querySelector(a?"."+a:""):_.wf(d,a,c)[0]||null}return a||null};xf={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",nonce:"nonce",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};
_.yf=function(a,c){_.rf(c,function(c,e){c&&c.Fb&&(c=c.kb());"style"==e?a.style.cssText=c:"class"==e?a.className=c:"for"==e?a.htmlFor=c:xf.hasOwnProperty(e)?a.setAttribute(xf[e],c):_.Hd(e,"aria-")||_.Hd(e,"data-")?a.setAttribute(e,c):a[e]=c})};_.zf=function(a){return"CSS1Compat"==a.compatMode};_.Af=function(a){a=(a||window).document;a=_.zf(a)?a.documentElement:a.body;return new _.sf(a.clientWidth,a.clientHeight)};
Bf=function(a){if(a&&"number"==typeof a.length){if(_.ra(a))return"function"==typeof a.item||"string"==typeof a.item;if(_.qa(a))return"function"==typeof a.item}return!1};Cf=function(a,c,d){function e(d){d&&c.appendChild(_.n(d)?a.createTextNode(d):d)}for(var f=2;f<d.length;f++){var g=d[f];!_.Vc(g)||_.ra(g)&&0<g.nodeType?e(g):(0,_.za)(Bf(g)?_.Wc(g):g,e)}};
Df=function(a,c){var d=String(c[0]),e=c[1];if(!_.Xc&&e&&(e.name||e.type)){d=["<",d];e.name&&d.push(' name="',_.nf(e.name),'"');if(e.type){d.push(' type="',_.nf(e.type),'"');var f={};_.Na(f,e);delete f.type;e=f}d.push(">");d=d.join("")}d=a.createElement(d);e&&(_.n(e)?d.className=e:_.p(e)?d.className=e.join(" "):_.yf(d,e));2<c.length&&Cf(a,d,c);return d};_.Q=function(a,c,d){return Df(window.document,arguments)};_.Ef=function(a){for(var c;c=a.firstChild;)a.removeChild(c)};
_.Ff=function(a,c){if(!a||!c)return!1;if(a.contains&&1==c.nodeType)return a==c||a.contains(c);if("undefined"!=typeof a.compareDocumentPosition)return a==c||!!(a.compareDocumentPosition(c)&16);for(;c&&a!=c;)c=c.parentNode;return c==a};_.Gf=function(a,c){if("textContent"in a)a.textContent=c;else if(3==a.nodeType)a.data=String(c);else if(a.firstChild&&3==a.firstChild.nodeType){for(;a.lastChild!=a.firstChild;)a.removeChild(a.lastChild);a.firstChild.data=String(c)}else _.Ef(a),a.appendChild(_.vf(a).createTextNode(String(c)))};
_.Hf=function(a){try{var c=a&&a.activeElement;return c&&c.nodeName?c:null}catch(d){return null}};_.If=function(a){this.b=a||_.l.document||window.document};_.k=_.If.prototype;_.k.G=function(a){return _.yd(this.b,a)};_.k.Ta=function(a,c,d){return Df(this.b,arguments)};_.k.createElement=function(a){return this.b.createElement(String(a))};_.k.yd=function(a,c){a.appendChild(c)};_.k.jf=_.Ef;_.k.kf=_.Bd;_.k.eh=_.Ff;_.Jf=function(a){return a?new _.If(_.vf(a)):ef||(ef=new _.If)};
_.Kf=function(a){_.F.call(this);this.V=a;this.P={}};_.v(_.Kf,_.F);var Lf=[];_.Kf.prototype.K=function(a,c,d,e){return Mf(this,a,c,d,e)};_.Kf.prototype.j=function(a,c,d,e,f){return Mf(this,a,c,d,e,f)};var Mf=function(a,c,d,e,f,g){_.p(d)||(d&&(Lf[0]=d.toString()),d=Lf);for(var h=0;h<d.length;h++){var m=_.M(c,d[h],e||a.handleEvent,f||!1,g||a.V||a);if(!m)break;a.P[m.key]=m}return a};_.Kf.prototype.nb=function(a,c,d,e){return Nf(this,a,c,d,e)};
var Nf=function(a,c,d,e,f,g){if(_.p(d))for(var h=0;h<d.length;h++)Nf(a,c,d[h],e,f,g);else{c=_.$d(c,d,e||a.handleEvent,f,g||a.V||a);if(!c)return a;a.P[c.key]=c}return a};_.Kf.prototype.Fa=function(a,c,d,e,f){if(_.p(c))for(var g=0;g<c.length;g++)this.Fa(a,c[g],d,e,f);else d=d||this.handleEvent,e=_.ra(e)?!!e.capture:!!e,f=f||this.V||this,d=_.ae(d),e=!!e,c=_.Qd(a)?a.kc(c,d,e,f):a?(a=_.ce(a))?a.kc(c,d,e,f):null:null,c&&(_.he(c),delete this.P[c.key]);return this}; _.Of=function(a){_.rf(a.P,function(a,d){this.P.hasOwnProperty(d)&&_.he(a)},a);a.P={}};_.Kf.prototype.O=function(){_.Kf.J.O.call(this);_.Of(this)};_.Kf.prototype.handleEvent=function(){throw Error("q");};
var Sf;_.Rf=function(a,c,d,e,f,g){if(!(_.y||_.Xa||_.$a&&_.pb("525")))return!0;if(_.ab&&f)return _.Pf(a);if(f&&!e)return!1;_.ma(c)&&(c=_.Qf(c));f=17==c||18==c||_.ab&&91==c;if((!d||_.ab)&&f||_.ab&&16==c&&(e||g))return!1;if((_.$a||_.Xa)&&e&&d)switch(a){case 220:case 219:case 221:case 192:case 186:case 189:case 187:case 188:case 190:case 191:case 192:case 222:return!1}if(_.y&&e&&c==a)return!1;switch(a){case 13:return!0;case 27:return!(_.$a||_.Xa)}return _.Pf(a)};
_.Pf=function(a){if(48<=a&&57>=a||96<=a&&106>=a||65<=a&&90>=a||(_.$a||_.Xa)&&0==a)return!0;switch(a){case 32:case 43:case 63:case 64:case 107:case 109:case 110:case 111:case 186:case 59:case 189:case 187:case 61:case 188:case 190:case 191:case 192:case 222:case 219:case 220:case 221:return!0;default:return!1}};_.Qf=function(a){if(_.Za)a=Sf(a);else if(_.ab&&_.$a)switch(a){case 93:a=91}return a}; Sf=function(a){switch(a){case 61:return 187;case 59:return 186;case 173:return 189;case 224:return 91;case 0:return 224;default:return a}};
var Vf;_.Uf=function(a,c,d){if(_.n(c))(c=_.Tf(a,c))&&(a.style[c]=d);else for(var e in c){d=a;var f=c[e],g=_.Tf(d,e);g&&(d.style[g]=f)}};Vf={};_.Tf=function(a,c){var d=Vf[c];if(!d){var e=_.pf(c);d=e;void 0===a.style[e]&&(e=(_.$a?"Webkit":_.Za?"Moz":_.y?"ms":_.Wa?"O":null)+qf(e),void 0!==a.style[e]&&(d=e));Vf[c]=d}return d};_.Wf=function(a,c){var d=_.vf(a);return d.defaultView&&d.defaultView.getComputedStyle&&(a=d.defaultView.getComputedStyle(a,null))?a[c]||a.getPropertyValue(c)||"":""};
_.Xf=function(a,c){return _.Wf(a,c)||(a.currentStyle?a.currentStyle[c]:null)||a.style&&a.style[c]};_.Yf=function(a){try{var c=a.getBoundingClientRect()}catch(d){return{left:0,top:0,right:0,bottom:0}}_.y&&a.ownerDocument.body&&(a=a.ownerDocument,c.left-=a.documentElement.clientLeft+a.body.clientLeft,c.top-=a.documentElement.clientTop+a.body.clientTop);return c};
_.$f=function(a,c,d){if(c instanceof _.sf)d=c.height,c=c.width;else if(void 0==d)throw Error("r");a.style.width=_.Zf(c,!0);a.style.height=_.Zf(d,!0)};_.Zf=function(a,c){"number"==typeof a&&(a=(c?Math.round(a):a)+"px");return a};_.bg=function(a){var c=_.ag;if("none"!=_.Xf(a,"display"))return c(a);var d=a.style,e=d.display,f=d.visibility,g=d.position;d.visibility="hidden";d.position="absolute";d.display="inline";a=c(a);d.display=e;d.position=g;d.visibility=f;return a};
_.ag=function(a){var c=a.offsetWidth,d=a.offsetHeight,e=_.$a&&!c&&!d;return _.la(c)&&!e||!a.getBoundingClientRect?new _.sf(c,d):(a=_.Yf(a),new _.sf(a.right-a.left,a.bottom-a.top))};_.cg=function(a,c){a.style.display=c?"":"none"};_.dg=_.Za?"MozUserSelect":_.$a||_.Xa?"WebkitUserSelect":null;

}catch(e){_._DumpException(e)}
/* _Module_:syo */
try{
var ig,kg;_.eg=function(a){if(a instanceof _.ld&&a.constructor===_.ld&&a.j===_.kd)return a.f;_.pa(a);return"type_error:SafeUrl"};_.fg=function(a){if(a instanceof _.ld)return a;a=a.Fb?a.kb():String(a);_.md.test(a)||(a="about:invalid#zClosurez");return _.nd(a)};_.gg=function(a){if(a instanceof _.td&&a.constructor===_.td&&a.o===_.sd)return a.f;_.pa(a);return"type_error:SafeHtml"};_.hg=function(a,c){a.innerHTML=_.gg(c)};ig=function(a,c,d,e){Array.prototype.splice.apply(a,_.le(arguments,1))}; _.jg=function(a){return null==a?"":String(a)};kg=function(a,c){return null!==a&&c in a?a[c]:void 0};_.lg=function(a,c){c=c instanceof _.ld?c:_.fg(c);a.href=_.eg(c)};
_.mg=function(){};_.oa(_.mg);_.mg.prototype.b=0;_.ng=function(a){return":"+(a.b++).toString(36)};var og,rg,sg;_.R=function(a){_.N.call(this);this.j=a||_.Jf();this.$=og;this.W=null;this.Ea=!1;this.b=null;this.L=void 0;this.D=this.A=this.f=this.w=null;this.Ca=!1};_.v(_.R,_.N);_.R.prototype.Ia=_.mg.ra();og=null;_.pg=function(a){return a.W||(a.W=_.ng(a.Ia))};_.R.prototype.G=function(){return this.b};_.qg=function(a){a.L||(a.L=new _.Kf(a));return a.L};
rg=function(a,c){if(a==c)throw Error("s");var d;if(d=c&&a.f&&a.W){d=a.f;var e=a.W;d=d.D&&e?kg(d.D,e)||null:null}if(d&&a.f!=c)throw Error("s");a.f=c;_.R.J.yc.call(a,c)};_.R.prototype.yc=function(a){if(this.f&&this.f!=a)throw Error("t");_.R.J.yc.call(this,a)};_.R.prototype.mc=function(){this.b=this.j.createElement("DIV")};_.R.prototype.wc=function(a){sg(this,a)};sg=function(a,c,d){if(a.Ea)throw Error("u");a.b||a.mc();c?c.insertBefore(a.b,d||null):a.j.b.body.appendChild(a.b);a.f&&!a.f.Ea||a.Aa()};
_.tg=function(a,c){if(a.Ea)throw Error("u");if(c){a.Ca=!0;var d=_.vf(c);a.j&&a.j.b==d||(a.j=_.Jf(c));a.Ub(c);a.Aa()}else throw Error("v");};_.k=_.R.prototype;_.k.Ub=function(a){this.b=a};_.k.Aa=function(){this.Ea=!0;_.ug(this,function(a){!a.Ea&&a.G()&&a.Aa()})};_.k.Pa=function(){_.ug(this,function(a){a.Ea&&a.Pa()});this.L&&_.Of(this.L);this.Ea=!1};
_.k.O=function(){this.Ea&&this.Pa();this.L&&(this.L.ha(),delete this.L);_.ug(this,function(a){a.ha()});!this.Ca&&this.b&&_.Bd(this.b);this.f=this.w=this.b=this.D=this.A=null;_.R.J.O.call(this)};
_.k.hc=function(a,c,d){if(a.Ea&&(d||!this.Ea))throw Error("u");if(0>c||c>_.vg(this))throw Error("w");this.D&&this.A||(this.D={},this.A=[]);if(a.f==this){var e=_.pg(a);this.D[e]=a;_.Jd(this.A,a)}else{e=this.D;var f=_.pg(a);if(null!==e&&f in e)throw Error("a`"+f);e[f]=a}rg(a,this);ig(this.A,c,0,a);a.Ea&&this.Ea&&a.f==this?(d=this.b,c=d.childNodes[c]||null,c!=a.G()&&d.insertBefore(a.G(),c)):d?(this.b||this.mc(),c=_.wg(this,c+1),sg(a,this.b,c?c.b:null)):this.Ea&&!a.Ea&&a.b&&a.b.parentNode&&1==a.b.parentNode.nodeType&&
a.Aa()};_.vg=function(a){return a.A?a.A.length:0};_.wg=function(a,c){return a.A?a.A[c]||null:null};_.ug=function(a,c,d){a.A&&(0,_.za)(a.A,c,d)};_.R.prototype.removeChild=function(a,c){if(a){var d=_.n(a)?a:_.pg(a);a=this.D&&d?kg(this.D,d)||null:null;if(d&&a){var e=this.D;d in e&&delete e[d];_.Jd(this.A,a);c&&(a.Pa(),a.b&&_.Bd(a.b));rg(a,null)}}if(!a)throw Error("x");return a};

}catch(e){_._DumpException(e)}
/* _Module_:syr */
try{
var yg;_.xg=function(a,c){var d=a.length-c.length;return 0<=d&&a.indexOf(c,d)==d};yg=function(a){if(a.classList)return a.classList;a=a.className;return _.n(a)&&a.match(/\S+/g)||[]};_.S=function(a,c){return a.classList?a.classList.contains(c):_.Ea(yg(a),c)};_.T=function(a,c){a.classList?a.classList.add(c):_.S(a,c)||(a.className+=0<a.className.length?" "+c:c)};
_.zg=function(a,c){if(a.classList)(0,_.za)(c,function(c){_.T(a,c)});else{var d={};(0,_.za)(yg(a),function(a){d[a]=!0});(0,_.za)(c,function(a){d[a]=!0});a.className="";for(var e in d)a.className+=0<a.className.length?" "+e:e}};_.U=function(a,c){a.classList?a.classList.remove(c):_.S(a,c)&&(a.className=(0,_.Aa)(yg(a),function(a){return a!=c}).join(" "))};_.Ag=function(a,c){a.classList?(0,_.za)(c,function(c){_.U(a,c)}):a.className=(0,_.Aa)(yg(a),function(a){return!_.Ea(c,a)}).join(" ")}; _.V=function(a,c,d){d?_.T(a,c):_.U(a,c)};

}catch(e){_._DumpException(e)}
/* _Module_:syu */
try{
var Bg;Bg=[1,4,2];_.Cg=function(a){return(_.Ic?0==a.ab.button:"click"==a.type?!0:!!(a.ab.button&Bg[0]))&&!(_.$a&&_.ab&&a.ctrlKey)};_.Eg=function(a,c,d){_.Dg.K(c,d,void 0,a.V||a,a)};var Fg,Gg;Fg=function(){};_.Dg=new Fg;Gg=["click",_.Za?"keypress":"keydown","keyup"];Fg.prototype.K=function(a,c,d,e,f){var g=function(a){var d=_.ae(c),f=_.Dd(a.target)?a.target.getAttribute("role")||null:null;"click"==a.type&&_.Cg(a)?d.call(e,a):13!=a.keyCode&&3!=a.keyCode||"keyup"==a.type?32!=a.keyCode||"keyup"!=a.type||"button"!=f&&"tab"!=f||(d.call(e,a),a.preventDefault()):(a.type="keypress",d.call(e,a))};g.uc=c;g.$i=e;f?f.K(a,Gg,g,d):_.M(a,Gg,g,d)};
Fg.prototype.Fa=function(a,c,d,e,f){for(var g,h=0;g=Gg[h];h++){var m=a;var q=g;var t=!!d;q=_.Qd(m)?m.Fc(q,t):m?(m=_.ce(m))?m.Fc(q,t):[]:[];for(m=0;t=q[m];m++){var w=t.listener;if(w.uc==c&&w.$i==e){f?f.Fa(a,g,t.listener,d,e):_.ge(a,g,t.listener,d,e);break}}}};

}catch(e){_._DumpException(e)}
/* _Module_:sys */
try{
_.Hg=!_.y&&!_.Pa();
}catch(e){_._DumpException(e)}
/* _Module_:syv */
try{
var Jg,Kg,Lg,Pg;_.Ig=function(a,c,d,e){if(null!=a)for(a=a.firstChild;a;){if(c(a)&&(d.push(a),e)||_.Ig(a,c,d,e))return!0;a=a.nextSibling}return!1};Jg=function(a,c){var d=[];_.Ig(a,c,d,!1);return d};Kg=function(a){return _.y&&!_.pb("9")?(a=a.getAttributeNode("tabindex"),null!=a&&a.specified):a.hasAttribute("tabindex")};Lg=function(a){a=a.tabIndex;return _.ma(a)&&0<=a&&32768>a};
_.Mg=function(a){var c;if((c="A"==a.tagName||"INPUT"==a.tagName||"TEXTAREA"==a.tagName||"SELECT"==a.tagName||"BUTTON"==a.tagName?!a.disabled&&(!Kg(a)||Lg(a)):Kg(a)&&Lg(a))&&_.y){var d;!_.qa(a.getBoundingClientRect)||_.y&&null==a.parentElement?d={height:a.offsetHeight,width:a.offsetWidth}:d=a.getBoundingClientRect();a=null!=d&&0<d.height&&0<d.width}else a=c;return a};_.Ng=function(a,c,d){for(var e=0;a&&(null==d||e<=d);){if(c(a))return a;a=a.parentNode;e++}return null};
_.Og=function(a,c){a=a.getAttribute("aria-"+c);return null==a||void 0==a?"":String(a)};Pg=function(a){return null!=_.Ng(a,function(a){return 1==a.nodeType&&"true"==_.Og(a,"hidden")})};_.Qg=function(a){return a?Jg(a,function(a){return 1==a.nodeType&&_.Mg(a)&&!Pg(a)}):[]};

}catch(e){_._DumpException(e)}
/* _Module_:syx */
try{
var Rg;Rg=function(a,c,d){if(a.f)return null;if(d instanceof Array){var e=null,f;for(f in d){var g=Rg(a,c,d[f]);g&&(e=g)}return e}e=null;a.b&&a.b.type==d&&a.j==c&&(e=a.b,a.b=null);if(f=c.getAttribute("data-eqid"))c.removeAttribute("data-eqid"),(f=a.o[f])?c.removeEventListener?c.removeEventListener(d,f,!1):c.detachEvent&&c.detachEvent("on"+d,f):a.A.log(Error("e`"+c));return e};_.Sg=function(a,c,d){return function(){try{return c.apply(d,arguments)}catch(e){a.log(e)}}};
_.Ug=function(a,c,d,e,f,g){e=_.Sg(a,e,g);a=_.M(c,d,e,f,g);_.Tg(c,d);return a};_.Tg=function(a,c){if(a instanceof window.Element&&(c=Rg(_.Id("eq"),a,c||[])))if(_.y&&c instanceof window.MouseEvent&&a.dispatchEvent){var d=window.document.createEvent("MouseEvent");d.initMouseEvent(c.type,!0,!0,c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget);a.dispatchEvent(d)}else a.dispatchEvent&&a.dispatchEvent(c)};

}catch(e){_._DumpException(e)}
/* _Module_:syy */
try{
_.Vg=function(a,c){_.Kf.call(this,c);this.A=a;this.ma=c||this};_.v(_.Vg,_.Kf);_.Vg.prototype.K=function(a,c,d,e){if(d){if("function"!=typeof d)throw new TypeError("Function expected");d=_.Sg(this.A,d,this.ma);d=_.Vg.J.K.call(this,a,c,d,e);_.Tg(a,Wg(c));return d}return _.Vg.J.K.call(this,a,c,d,e)};
_.Vg.prototype.j=function(a,c,d,e,f){if(d){if("function"!=typeof d)throw new TypeError("Function expected");d=_.Sg(this.A,d,f||this.ma);d=_.Vg.J.j.call(this,a,c,d,e,f);_.Tg(a,Wg(c));return d}return _.Vg.J.j.call(this,a,c,d,e,f)};_.Vg.prototype.nb=function(a,c,d,e){if(d){if("function"!=typeof d)throw new TypeError("Function expected");d=_.Sg(this.A,d,this.ma);d=_.Vg.J.nb.call(this,a,c,d,e);_.Tg(a,Wg(c));return d}return _.Vg.J.nb.call(this,a,c,d,e)}; var Wg=function(a){return _.p(a)?(0,_.Ba)(a,Wg):_.n(a)?a:a?a.toString():a};
_.Xg=function(a,c){_.Vg.call(this,c);this.f=a};_.v(_.Xg,_.Vg);_.Xg.prototype.G=function(){return this.f};_.Xg.prototype.O=function(){this.f=null;_.Xg.J.O.call(this)};
}catch(e){_._DumpException(e)}
/* _Module_:syz */
try{
_.Yg=function(a,c,d){_.Xg.call(this,a,c);this.w=d;this.o=_.S(this.f,"gb_ec");(a=_.P("gb_fc",this.f))&&_.Eg(this,a,this.b)};_.v(_.Yg,_.Xg);_.Yg.prototype.b=function(a){var c;(a=a.b)&&(a=a.getAttributeNode("data-ved"))&&a.value&&(c={ved:a.value});this.w.log(this.o?41:39,c)};

}catch(e){_._DumpException(e)}
/* _Module_:sy10 */
try{
var Zg=function(a){_.F.call(this);this.A=a;this.j=this.o=null;this.b={};this.w={};this.f={}};_.v(Zg,_.F);_.$g=function(a){if(a.o)return a.o;for(var c in a.f)if(a.f[c].zf()&&a.f[c].Gb())return a.f[c];return null};_.k=Zg.prototype;_.k.Md=function(a){a&&_.$g(this)&&a!=_.$g(this)&&_.$g(this).$c(!1);this.o=a};_.k.Df=function(a){a=this.f[a]||a;return _.$g(this)==a};_.k.Zd=function(a,c){c=c.Zc();if(this.b[a]&&this.b[a][c])for(var d=0;d<this.b[a][c].length;d++)try{this.b[a][c][d]()}catch(e){this.A.log(e)}}; _.k.ng=function(a){return!this.w[a.Zc()]};_.k.Fe=function(a){this.f[a.Zc()]=a};var ah=new Zg(_.K);_.ac("dd",ah);

}catch(e){_._DumpException(e)}
/* _Module_:syq */
try{
var dh,eh,gh,hh,ih,jh,nh,ph,qh,rh,vh,xh;_.ch=function(a,c){c&&_.bh(a,a.href.replace(/([?&](continue|followup)=)[^&]*/g,"$1"+(0,window.encodeURIComponent)(c)))};dh=function(a,c){if(void 0!==a.b||void 0!==a.f)throw Error("f");a.f=c;_.mc(a)};eh=function(a){_.A(this,a,0,-1,null)};_.v(eh,_.z);_.fh=function(a,c,d){_.F.call(this);this.uc=a;this.j=c||0;this.b=d;this.f=(0,_.r)(this.dh,this)};_.v(_.fh,_.F);_.k=_.fh.prototype;_.k.Gc=0;_.k.O=function(){_.fh.J.O.call(this);this.stop();delete this.uc;delete this.b};
_.k.start=function(a){this.stop();this.Gc=_.df(this.f,_.la(a)?a:this.j)};_.k.stop=function(){0!=this.Gc&&_.l.clearTimeout(this.Gc);this.Gc=0};_.k.dh=function(){this.Gc=0;this.uc&&this.uc.call(this.b)};gh=function(a,c){a=_.P("gb_1a",a.G());_.V(a,"gb_bb",!c)};hh=function(a){a=a.getAttribute("src");return null!=a&&""!=a};
ih=function(a,c,d){a=_.P("gb_1a",a.G());if(""!=c||""!=d)if(_.S(a,"gb_0a")){var e=a.style[_.pf("background-image")];""!=("undefined"!==typeof e?e:a.style[_.Tf(a,"background-image")]||"")&&(c=""!=d?d:c,_.Uf(a,"background-image","url('"+c+"')"),a=_.P("gb_ic",a),null!=a&&hh(a)&&a.setAttribute("src",c))}else"IMG"==a.tagName&&(e=""!=c?c:d,null!=a&&hh(a)&&a.setAttribute("src",e),c!=d&&(d=""!=d?d+" 2x ":"",""!=c&&(d=d+(""==d?"":",")+(c+" 1x")),a.setAttribute("srcset",d)))};
jh=function(a){return String(a).replace(/([A-Z])/g,"-$1").toLowerCase()};_.bh=function(a,c){c=c instanceof _.ld?c:_.fg(c);a.href=_.eg(c)};_.kh=function(a,c){var d=c||window.document;return d.querySelectorAll&&d.querySelector?d.querySelectorAll("."+a):_.wf(window.document,a,c)};_.lh=function(a,c){return _.P(a,c)};_.mh=function(a,c,d){a.insertBefore(c,a.childNodes[d]||null)};nh=function(a,c){var d=c.parentNode;d&&d.replaceChild(a,c)};
_.oh=function(a){return _.Yc&&void 0!=a.children?a.children:(0,_.Aa)(a.childNodes,function(a){return 1==a.nodeType})};ph=function(a,c){var d=[];return _.Ig(a,c,d,!0)?d[0]:void 0};qh={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1};rh={IMG:" ",BR:"\n"};_.sh=function(a,c){c?a.tabIndex=0:(a.tabIndex=-1,a.removeAttribute("tabIndex"))};
_.th=function(a,c,d){if(!(a.nodeName in qh))if(3==a.nodeType)d?c.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g,"")):c.push(a.nodeValue);else if(a.nodeName in rh)c.push(rh[a.nodeName]);else for(a=a.firstChild;a;)_.th(a,c,d),a=a.nextSibling};
_.uh=function(a){if(_.Zc&&null!==a&&"innerText"in a)a=a.innerText.replace(/(\r\n|\r|\n)/g,"\n");else{var c=[];_.th(a,c,!0);a=c.join("")}a=a.replace(/ \xAD /g," ").replace(/\xAD/g,"");a=a.replace(/\u200B/g,"");_.Zc||(a=a.replace(/ +/g," "));" "!=a&&(a=a.replace(/^\s*/,""));return a};vh=function(a,c){return c?_.Ng(a,function(a){return!c||_.n(a.className)&&_.Ea(a.className.split(/\s+/),c)},void 0):null};
_.wh=function(a,c,d){if(_.Hg&&a.dataset)a.dataset[c]=d;else{if(/-[a-z]/.test(c))throw Error("y");a.setAttribute("data-"+jh(c),d)}};xh=function(a){if(/-[a-z]/.test("item"))return null;if(_.Hg&&a.dataset){if(_.Qa()&&!("item"in a.dataset))return null;a=a.dataset.item;return void 0===a?null:a}return a.getAttribute("data-"+jh("item"))};_.zh=function(a,c){_.N.call(this);this.b=a;this.j=yh(this.b);this.B=c||100;this.o=_.M(a,"resize",this.A,!1,this)};_.v(_.zh,_.N);
_.zh.prototype.O=function(){_.he(this.o);_.zh.J.O.call(this)};_.zh.prototype.A=function(){this.f||(this.f=new _.fh(this.w,this.B,this),_.$e(this,this.f));this.f.start()};_.zh.prototype.w=function(){if(!this.b.Ga){var a=this.j,c=yh(this.b);this.j=c;if(a){var d=!1;a.width!=c.width&&(this.dispatchEvent("b"),d=!0);a.height!=c.height&&(this.dispatchEvent("a"),d=!0);d&&this.dispatchEvent("resize")}else this.dispatchEvent("a"),this.dispatchEvent("b"),this.dispatchEvent("resize")}};
var Ah=function(a){_.N.call(this);this.f=a||window;this.j=_.M(this.f,"resize",this.o,!1,this);this.b=_.Af(this.f)},Bh,yh;_.v(Ah,_.N);_.Ch=function(){var a=window,c=_.bf(a);return Bh[c]=Bh[c]||new Ah(a)};Bh={};yh=function(a){return a.b?_.tf(a.b):null};Ah.prototype.O=function(){Ah.J.O.call(this);this.j&&(_.he(this.j),this.j=null);this.b=this.f=null};Ah.prototype.o=function(){var a=_.Af(this.f);_.uf(a,this.b)||(this.b=a,this.dispatchEvent("resize"))};
_.Dh=function(a){this.f=a;this.b=null};_.Eh=function(a){a.b||(a.b=_.M(a.f,"keydown",a.j,!1,a))};_.Gh=function(a){Fh(a);_.V(a.f,"gb_5",!1)};_.Dh.prototype.j=function(a){9!=a.keyCode||_.S(this.f,"gb_5")||(_.V(this.f,"gb_5",!0),Fh(this))};var Fh=function(a){a.b&&(_.he(a.b),a.b=null)};
_.Hh=function(a,c){_.N.call(this);this.B=a;c&&(this.B.id=c)};_.v(_.Hh,_.N);_.Hh.prototype.G=function(){return this.B};_.Hh.prototype.Z=function(){return this.B.id};_.Hh.prototype.U=function(){var a=this.B.id;a||(a="gb$"+_.ng(_.mg.ra()),this.B.id=a);return a};_.Hh.prototype.O=function(){_.Bd(this.B);_.Hh.J.O.call(this)};
_.Ih=function(a){_.Hh.call(this,a);_.Dg.K(a,this.b,!1,this)};_.v(_.Ih,_.Hh);_.Ih.prototype.b=function(a){this.dispatchEvent("click")||a.preventDefault()};_.Jh=function(a){return ph(a,function(a){return _.Dd(a)&&_.Mg(a)})};_.Kh=function(a){(a=_.Jh(a))&&a.focus()};var Lh=function(){};var Mh=function(a,c,d){this.f=a;this.j=c;this.b=d||_.l};var Nh=function(){this.b=[]};Nh.prototype.f=function(a,c,d){this.A(a,c,d);this.b.push(new Mh(a,c,d))};Nh.prototype.A=function(a,c,d){d=d||_.l;for(var e=0,f=this.b.length;e<f;e++){var g=this.b[e];if(g.f==a&&g.j==c&&g.b==d){this.b.splice(e,1);break}}};Nh.prototype.j=function(a){for(var c=0,d=this.b.length;c<d;c++){var e=this.b[c];"catc"==e.f&&e.j.call(e.b,a)}};
var Ph=function(a,c){this.o=new Nh;this.C=a;this.w=c;this.b=Oh(a.offsetWidth,this.w);this.D=new _.zh(_.Ch(),10);_.M(this.D,"b",function(){window.requestAnimationFrame?window.requestAnimationFrame((0,_.r)(this.B,this)):this.B()},!1,this)},Oh=function(a,c){for(var d=0,e=c.length-1,f=c[0];d<e;){if(a<=f.max)return f.id;f=c[++d]}return c[e].id};Ph.prototype.B=function(){var a=Oh(this.C.offsetWidth,this.w);a!=this.b&&(this.b=a,this.j(new Lh))};Ph.prototype.f=function(a,c,d){this.o.f(a,c,d)}; Ph.prototype.A=function(a,c){this.o.A(a,c)};Ph.prototype.j=function(a){this.o.j(a)};
var Qh={Gj:"gb_Za",dk:"gb_Jd",wj:"gb_qc"};var Rh={id:"unlimitedProductControl",Gd:Number.MAX_SAFE_INTEGER};var Sh=function(a,c){c||(c=this.createElement(),a.hd().appendChild(c));_.Hh.call(this,c);this.o=new _.Kf(this);_.Eg(this.o,this.G(),this.qh)};_.v(Sh,_.Hh);_.k=Sh.prototype;_.k.createElement=function(){var a=_.Ad("LI");_.T(a,"gb_vc");_.Fd(a,"menuitem");return a};
_.k.Ci=function(a){a?_.wh(this.G(),"item",a):(a=this.G(),/-[a-z]/.test("item")||(_.Hg&&a.dataset?(/-[a-z]/.test("item")?0:_.Hg&&a.dataset?"item"in a.dataset:a.hasAttribute?a.hasAttribute("data-"+jh("item")):a.getAttribute("data-"+jh("item")))&&delete a.dataset.item:a.removeAttribute("data-"+jh("item"))));return this};_.k.ad=function(){return xh(this.G())};_.k.Mc=function(a){_.V(this.G(),"gb_xc",a);return this};_.k.focus=function(){_.Kh(this.G())};_.k.qh=function(){this.dispatchEvent("click")};
var Th=function(a,c){Sh.call(this,a,c);this.j=_.lh("gb_yc",this.G());this.w=_.P("gb_Ac",this.j);this.b=null;this.f=_.P("gb_zc",this.j)};_.v(Th,Sh);_.k=Th.prototype;_.k.createElement=function(){var a=Th.J.createElement.call(this);_.T(a,"gb_Bc");var c=_.Q("A","gb_yc");_.sh(c,!0);a.appendChild(c);var d=_.Q("SPAN","gb_zc");c.appendChild(d);return a};_.k.ad=function(){return Th.J.ad.call(this)||this.Gf()};_.k.Gf=function(){return _.uh(this.f)};_.k.Di=function(a){_.Gf(this.f,a);return this};
_.k.dj=function(a){if(!this.w)if(this.w=_.Q("IMG","gb_Ac"),this.w.setAttribute("alt",""),this.b)nh(this.w,this.b),this.b=null;else{var c=this.f;c.parentNode&&c.parentNode.insertBefore(this.w,c)}this.w.setAttribute("src",a);return this};
_.k.bj=function(a){if(!(a instanceof window.Element&&"svg"==a.tagName.toLowerCase()))return this;if(this.w)nh(a,this.w),this.w=null;else if(this.b)nh(a,this.b);else{var c=this.f;c.parentNode&&c.parentNode.insertBefore(a,c)}(c=a.getAttribute("class"))?a.setAttribute("class",c+" gb_Ac"):a.setAttribute("class","gb_Ac");this.b=a;return this};_.k.focus=function(){this.j.focus()};
_.Uh=function(a){_.Hh.call(this,a);this.f=[];this.F={}};_.v(_.Uh,_.Hh);_.Hh.prototype.hd=function(){return this.G()};_.Uh.prototype.ma=function(a){var c=this.F[a];if(c)return c;var d=window.document.getElementById(a);if(d)for(var e=0,f=this.f.length;e<f;++e)if(c=this.f[e],c.G()==d)return this.F[a]=c;return null};_.Uh.prototype.rb=function(a){a.yc(this);this.f.push(a);var c=a.B.id;c&&(this.F[c]=a)};_.Uh.prototype.R=function(){for(var a=0,c=this.f.length;a<c;a++)this.f[a].ha();this.F={};this.f=[]};
var Vh=function(a,c){_.Uh.call(this,c||this.createElement());this.j=a;a=this.G().getElementsByClassName("gb_vc");for(c=0;c<a.length;c++){var d=a[c];_.S(d,"gb_Bc")?this.rb(new Th(this,d)):this.rb(new Sh(this,d))}this.b=_.P("gb_wc",this.G())};_.v(Vh,_.Uh);_.k=Vh.prototype;_.k.createElement=function(){var a=_.Ad("UL");_.T(a,"gb_uc");var c=_.Q("SPAN","gb_wc");a.appendChild(c);return a};_.k.rb=function(a){Vh.J.rb.call(this,a);var c=this.j,d=a.G();d=d.id||(d.id="gbm"+_.ng(_.mg.ra()));c.P[d]=a}; _.k.Ai=function(){return null!=this.b?_.uh(this.b):null};_.k.Bi=function(a){return null!=this.b?(_.Gf(this.b,a),this):null};_.k.og=function(){var a=new Sh(this);this.rb(a);return a};_.k.qg=function(){var a=new Th(this);this.rb(a);return a};
var W=function(a,c,d,e,f,g){_.Uh.call(this,a);this.b=c;this.w=a;this.A=d;this.L=e;this.H=f;this.j=_.P("gb_rc",this.b);this.M=new _.Dh(this.j);this.C=_.P("gb_sc",this.j);this.D=_.P("gb_tc",this.j);this.P={};this.N=[];this.V=g||!1;this.o=new _.Kf(this);Wh(this);a=this.j.getElementsByClassName("gb_uc");for(c=0;c<a.length;c++)this.rb(new Vh(this,a[c]))};_.v(W,_.Uh);var Xh="click mousedown scroll touchstart wheel keydown".split(" ");W.prototype.O=function(){W.J.O.call(this);Yh(this)};W.prototype.hd=function(){return this.j};
W.prototype.W=function(){Zh(this);return $h(this,this.C)};W.prototype.T=function(){Zh(this);return $h(this,this.D)};var $h=function(a,c){var d=new Vh(a),e=d.G();c.appendChild(e);a.rb(d);return d},Zh=function(a){a.C||(a.C=_.Ad("DIV"),_.T(a.C,"gb_sc"),a.j.appendChild(a.C),a.D=_.Ad("DIV"),_.T(a.D,"gb_tc"),a.j.appendChild(a.D))};W.prototype.$=function(a){_.V(this.b,"gb_pc",1==a);this.dispatchEvent("msc")};W.prototype.X=function(){return ai(this)?0:1};
var bi=function(a,c){switch(c){case "menu":_.U(a.G(),"gb_bb");break;case "back":_.U(a.A,"gb_bb");break;case "close":_.U(a.L,"gb_bb")}},ci=function(a){_.T(a.G(),"gb_bb");_.T(a.A,"gb_bb");_.T(a.L,"gb_bb")},di=function(a){return!_.S(a,"gb_bb")};_.k=W.prototype;_.k.ua=function(a){switch(a){case "menu":return di(this.G());case "back":return di(this.A);case "close":return di(this.L)}return!1};
_.k.Ae=function(a){this.H||(a&&_.Uf(this.b,"transition","none"),this.dispatchEvent("beforeshow"),_.T(this.b,"gb_g"),_.L(this.G(),"expanded",!0),_.Kh(this.j),_.Eh(this.M),this.dispatchEvent("open"),this.o.j(window.document.body,Xh,this.uf,!0,this),this.o.K(window.document.body,"focusin",this.Hf),a&&_.df(function(){_.Uf(this.b,"transition","")},0,this))};
_.k.close=function(a){this.H||(a&&_.Uf(this.b,"transition","none"),_.U(this.b,"gb_g"),_.L(this.G(),"expanded",!1),window.document.activeElement==this.G()&&this.G().blur(),_.Gh(this.M),this.dispatchEvent("close"),Yh(this),a&&_.df(function(){_.Uf(this.b,"transition","")},0,this))};_.k.kj=function(a){di(this.w)&&_.T(this.w,"gb_nc");_.U(this.A,"gb_bb");a&&_.$d(this.A,"click",a)};_.k.ji=function(){_.T(this.A,"gb_bb");_.S(this.w,"gb_nc")&&_.U(this.w,"gb_nc")};_.k.Hb=function(){return _.S(this.b,"gb_g")};
var Wh=function(a){_.Eg(a.o,a.G(),a.Y);a.G().addEventListener("keydown",function(a){32==a.keyCode&&a.preventDefault()});_.Eg(a.o,a.j,a.Mh);a.o.K(a.b,"keydown",a.Ei);a.o.K(a.b,"keyup",a.Jh);_.Eg(a.o,a.A,function(){this.dispatchEvent("bbc")});_.Eg(a.o,a.L,function(){this.dispatchEvent("cbc")})};W.prototype.Y=function(){this.dispatchEvent("mbc");if(!this.H){if(this.Hb()){this.close();var a=!0}else this.Ae(),a=!1;a&&this.G().focus()}};
var ai=function(a){return!_.S(a.b,"gb_pc")||_.S(a.b,"gb_Za")||_.S(a.b,"gb_Jd")};_.k=W.prototype;_.k.Jh=function(a){9===a.keyCode&&this.Hb()&&(a=this.M,_.V(a.f,"gb_5",!0),Fh(a))};
_.k.Ei=function(a){a:{if(36==a.keyCode||35==a.keyCode){var c=_.Qg(this.b);if(0<c.length){var d=c[c.length-1];36==a.keyCode&&(d=!ai(this)&&1<c.length?c[1]:c[0]);d.focus();a.preventDefault();break a}}27!=a.keyCode||this.V&&!ai(this)||(this.close(),null!=this.w&&this.w.focus())}9===a.keyCode&&this.Hb()&&ai(this)&&(c=a.target,d=_.Qg(this.b),0<d.length&&(c==d[0]&&a.shiftKey?(d[d.length-1].focus(),a.preventDefault()):c!=d[d.length-1]||a.shiftKey||(d[0].focus(),a.preventDefault())))};
_.k.Mh=function(a){if(a.target instanceof window.Node){a:{a=a.target;for(var c=this.j;a&&a!==c;){var d=a.id;if(d in this.P){a=this.P[d];break a}a=a.parentNode}a=null}if(a){a=a.ad();c=0;for(d=this.N.length;c<d;++c){var e=this.N[c];e.b.call(e.f,a)}this.V&&!ai(this)||this.close()}}};
_.k.uf=function(a){this.Hb()&&a.target instanceof window.Node&&ai(this)&&("keydown"==a.type?27==a.keyCode&&(a.preventDefault(),a.stopPropagation(),this.close(),this.G().focus()):vh(a.target,"gb_fa")||vh(a.target,"gb_jc")||_.Ff(this.b,a.target)||("touchstart"==a.type&&(a.preventDefault(),a.stopPropagation()),this.close()))};_.k.Hf=function(){this.Hb()&&(!ai(this)||vh(window.document.activeElement,"gb_oc")||vh(window.document.activeElement,"gb_fa")||_.Kh(this.j))}; var Yh=function(a){a.o.Fa(window.document.body,Xh,a.uf,!1,a);a.o.Fa(window.document.body,"focusin",a.Hf)};W.prototype.S=function(a,c){this.N.push(new ei(a,c))};var ei=function(a,c){this.b=a;this.f=c};
_.fi=function(a){_.Hh.call(this,a);_.M(a,"click",this.b,!1,this)};_.v(_.fi,_.Hh);_.fi.prototype.f=function(){var a=this.G().getAttribute("aria-pressed");return(null==a?a:"boolean"==typeof a?a:"true"==a)||!1};_.fi.prototype.b=function(a){a=a.b;var c=_.Og(a,"pressed");_.ne(_.jg(c))||"true"==c||"false"==c?_.L(a,"pressed","true"==c?"false":"true"):a.removeAttribute("aria-pressed");this.dispatchEvent("click")};
var gi,ii;_.hi=function(){_.N.prototype.za=_.Rc(gi,_.N.prototype.K);_.N.prototype.zb=_.N.prototype.Qc;_.u("gbar.I",_.Hh);_.Hh.prototype.ia=_.Hh.prototype.Z;_.Hh.prototype.ib=_.Hh.prototype.G;_.Hh.prototype.ic=_.Hh.prototype.U;_.u("gbar.J",_.Uh);_.Uh.prototype.ja=_.Uh.prototype.ma;_.Uh.prototype.jb=_.Uh.prototype.R;_.u("gbar.K",_.Ih);_.u("gbar.L",_.fi);_.fi.prototype.la=_.fi.prototype.f};gi=function(a,c,d,e,f){return a.call(this,c,_.Rc(ii,d),e,f)}; ii=function(a,c){c.xa=c.type;c.xb=c.target;return a.call(this,c)};
var X=function(a,c,d,e){_.N.call(this);this.j=a;_.U(this.j,"gb_Dd");this.f=c;this.X=d;this.Za="";this.Ab=e;this.L=this.b=null;this.wb=this.N=this.Z=!1;this.ya=_.G(_.B(this.f,16),!1);this.Y=new _.Kf(this);this.S=_.P("gb_Vc",this.j);this.P=_.G(_.B(c,6),!1);this.Zb=_.P("gb_Wc",this.S);this.o=_.P("gb_Ed",this.j);this.M=_.P("gb_Md",this.j);(this.ta=_.G(_.B(this.f,21),!1))&&this.o&&(this.Ia=_.P("gb_pe",this.j),this.R=_.P("gb_te",this.j),this.V=_.P("gb_qe",this.j));this.A=_.P("gb_Dc",this.j);this.W=_.P("gb_6d",
this.j);this.eg=_.P("gb_8d",this.j);this.B=_.P("gb_Wd",this.j);this.C=_.P("gb_Td",this.j);this.H=Array.prototype.slice.call(_.kh("gb_be",this.j));this.T=!1;this.Nb=_.G(_.B(this.f,19),!1);this.Mb=_.G(_.B(this.f,20),!1);this.F=_.G(_.B(this.f,18),!1);a=ji(this,!0);c=ji(this,!1);this.Pb=Math.max(a,c);this.U=_.B(this.f,15);this.Ca=_.G(_.B(this.f,17),!1);d=_.I(_.B(this.f,30),0);0!=d&&ki(this,d);a=li(this,a,c);this.D=new Ph(this.j,mi);this.ta&&this.o&&(this.$a=new Ph(this.j,ni),this.$a.f("catc",this.va,
this),this.va(),_.Eg(this.Y,this.Ia,function(){var a=this.R;_.V(a,"gb_bb",!_.S(a,"gb_bb"))}));this.Ob=_.G(_.B(this.f,1),!1);oi(this);pi(this,this.D.b);this.D.f("catc",this.Ib,this);_.B(this.f,8)&&window.document.addEventListener("scroll",(0,_.r)(function(){_.V(this.j,"gb_Hd",0<window.scrollY)},this));null!=this.C&&_.B(this.f,7)&&(this.ma=new Ph(this.C,a),this.ma.f("catc",this.qe,this),this.qe())};_.v(X,_.N);
var qi="click mousedown scroll touchstart wheel keydown".split(" "),mi=[{id:"gb_Za",max:599},{id:"gb_Jd",max:1023},{id:"gb_qc"}],ni=[{id:{id:"oneProductControl",Gd:1},max:320},{id:{id:"twoProductControl",Gd:2},max:360},{id:{id:"threeProductControl",Gd:3},max:410},{id:Rh}];_.k=X.prototype;_.k.G=function(){return this.j};_.k.ej=function(a){this.L=a;this.F&&"gb_Za"==this.D.b?(ri(this,!0),this.Ja(!1)):gh(this.L,this.Z);a=si(this);0!=a&&ti(this,a)};_.k.fj=function(a,c){this.L&&ih(this.L,a,c)};
_.k.hj=function(a){this.S&&(_.Gf(this.Zb,a||""),_.V(this.S,"gb_bb",!a||this.F&&"gb_Za"==this.D.b),this.P=!!a,pi(this,this.D.b))};_.k.Ug=function(){return _.P("gb_ke",this.o)};_.k.qe=function(){if(null!=this.ma){var a=this.ma.b;3==a?ui(this,!1):1==a?ui(this,!this.F):ui(this,!this.F&&"gb_qc"==this.D.b)}};
var ui=function(a,c){if(_.B(a.f,7)&&(a.F||!a.T||c)){if(a.U){var d=_.P("gb_Ee",a.j);if(d){var e=_.P("gb_Fe",a.j),f="gb_qc"!=a.D.b||c?"":a.Pb+"px";_.Uf(d,"min-width",f);_.Uf(e,"min-width",f)}}_.S(a.C,"gb_Pd")!=c&&(_.V(a.C,"gb_Pd",c),c?a.dispatchEvent("sfi"):a.dispatchEvent("sfu"),_.V(_.P("gb_Pe",a.C),"gb_Pd",c),c&&a.va())}},oi=function(a){var c=_.J.ra();a.o||dh(c.b,Error("D"));_.G(_.B(a.f,11))||dh(c.B,Error("E"));_.G(_.B(a.f,7))||dh(c.w,Error("F"));_.G(_.B(a.f,12))||dh(c.o,Error("G"));_.G(_.B(a.f,13))||
dh(c.A,Error("H"))},pi=function(a,c){var d;if(!a.b&&a.o){if(d=_.P("gb_jc",a.j)){var e=_.P("gb_oc");if(e){var f=_.P("gb_lc");if(f){var g=_.P("gb_mc");g?(a.b=new W(d,e,f,g,_.G(_.B(a.f,16),!1),_.G(_.B(a.f,9),!1)),a.b.K("open",a.Kb,!1,a),a.b.K("close",a.Jb,!1,a),a.b.K("msc",a.Lb,!1,a),_.hi(),_.u("gbar.C",W),W.prototype.ca=W.prototype.hd,W.prototype.cb=W.prototype.W,W.prototype.cc=W.prototype.S,W.prototype.cd=W.prototype.$,W.prototype.ce=W.prototype.T,W.prototype.cf=W.prototype.Ae,W.prototype.cg=W.prototype.close,
W.prototype.ch=W.prototype.X,W.prototype.ci=W.prototype.kj,W.prototype.cj=W.prototype.ji,W.prototype.ck=W.prototype.Hb,_.u("gbar.D",Vh),Vh.prototype.da=Vh.prototype.og,Vh.prototype.db=Vh.prototype.qg,Vh.prototype.dc=Vh.prototype.Ai,Vh.prototype.dd=Vh.prototype.Bi,_.u("gbar.E",Sh),Sh.prototype.ea=Sh.prototype.G,Sh.prototype.eb=Sh.prototype.Mc,Sh.prototype.ec=Sh.prototype.Ci,Sh.prototype.ed=Sh.prototype.ad,_.u("gbar.F",Th),Th.prototype.fa=Th.prototype.Di,Th.prototype.fb=Th.prototype.dj,Th.prototype.fc=
Th.prototype.bj,Th.prototype.fd=Th.prototype.Gf,Th.prototype.ed=Th.prototype.ad,_.me(_.J.ra().b,a.b)):a.X.log(Error("z"))}else a.X.log(Error("A"))}else a.X.log(Error("B"))}else a.X.log(Error("C"));d=_.G(_.B(a.f,14),!1)}d&&a.$("back");a.b&&!a.N&&a.$("default");a.b&&a.Mb&&a.$("none");vi(a);a.Nb||a.ya?a.Z=!0:(d="gb_Za"==c,e=_.G(_.B(a.f,5),!1),f=_.G(_.B(a.f,7),!1),a.Z=!(a.P||d&&(e||f)));d=wi(a,c);if(a.b&&d)a:{if(!_.xi(a)){if(a.Ca){if(null==a.W)break a;d=_.P("gb_he");a.W.parentNode!=d&&_.mh(d,a.W,0);_.T(a.A,
"gb_7d")}else d=_.P("gb_he"),a.A.parentNode!=d&&_.mh(d,a.A,0),_.U(a.A,"gb_5d");a.ka();a.dispatchEvent("upi")}}else a:if(_.xi(a)&&a.o){if(a.Ca){if(null==a.W)break a;_.mh(a.eg,a.W,0);_.U(a.A,"gb_7d")}else a.o.appendChild(a.A),_.T(a.A,"gb_5d");a.ka();a.dispatchEvent("upo")}d="gb_Za"==c;a.L&&!a.ya&&(e=a.L.G(),f=!a.P,_.V(e,"gb_bb",!f),f&&(a.F&&d?(a.Ja(!1),ri(a,!0)):gh(a.L,a.Z&&(!a.F||!d))));a.b&&(a.b.ua("menu")||a.b.ua("back"))&&!ai(a.b)&&(a.wb=a.b.Hb());e=_.oe(Qh);_.Ag(a.j,e);_.T(a.j,c);_.B(a.f,7);a.U&&
null!=a.B&&("gb_qc"!=c?(_.Uf(a.B,"min-width",""),_.Uf(a.A,"min-width","")):(f=_.bg(a.B).width,g=_.bg(a.A).width,f=Math.max(f,g),_.Uf(a.B,"min-width",f+"px"),_.Uf(a.A,"min-width",f+"px")));d?a.T||(a.T=!a.F,ui(a,a.T),ri(a,!0)):(ri(a,!1),a.T=!1,a.qe());yi(a,a.C);yi(a,a.B);null!=a.C&&(f="gb_Jd"==c,_.V(a.C,"gb_1d",!d&&!f),_.V(a.C,"gb_0d",d||f));a.b&&(d=a.b.b,_.Ag(d,e),_.T(d,c),ai(a.b)?_.P("gb_ie",void 0).appendChild(d):a.j.appendChild(d),a.b.ua("menu")||a.b.ua("back"))&&(c=!ai(a.b),d=a.b.Hb(),c&&!d&&a.wb?
a.b.Ae():!c&&d&&a.b.close());_.zi(a)},yi=function(a,c){var d="gb_Za"==a.D.b;null!=c&&_.V(c,"gb_Zd",d&&a.F)},li=function(a,c,d){var e=320,f=_.I(_.B(a.f,29),0);0<f&&(e=f);f=e+2*Math.max(c,d);c=e+c+d;return f!=c&&a.U?[{id:1,max:c},{id:2,max:f},{id:3}]:[{id:1,max:c},{id:3}]},ji=function(a,c){if(a=_.P(c?"gb_Ee":"gb_Fe",a.j)){var d=a.offsetWidth;(0,_.za)(a.children,function(a){_.S(a,"gb_bb")&&(d-=a.offsetWidth)});return d}return 0},Ai=function(a){return function(){a.click()}},Bi=function(a){var c=_.P("gb_Ee",
a.j),d=_.P("gb_Fe",a.j),e=[];c&&(0,_.za)(c.children,function(a){e.push(a)});_.G(_.B(a.f,7),!1)&&(a=_.P("gb_Pd",a.C))&&(a=a.children[0],a.b=!0,e.push(a));d&&(0,_.za)(d.children,function(a){e.push(a)});return e};
X.prototype.va=function(){if(this.ta&&this.o){var a=Bi(this),c=!1;a=(0,_.Aa)(a,function(a){c=c||_.S(a,"gb_Ie");return _.S(a,"gb_Jb")||_.S(a,"gb_zf")||_.S(a,"gb_9e")});var d=this.$a.b.Gd,e=!1;if(a.length>d||c)e=!0,d--;var f=a.length-d;if(e!=!_.S(this.Ia,"gb_bb")||f!=this.V.children){_.V(this.Ia,"gb_bb",!e);if(e)for(;this.V.firstChild;)this.V.removeChild(this.V.firstChild);Ci(this,a,d);e?this.Y.j(window.document.body,qi,this.vb,!0,this):this.Y.Fa(window.document.body,qi,this.vb,!1,this)}}};
var Ci=function(a,c,d){c=(0,_.Aa)(c,function(a){return _.S(a,"gb_Ie")?(Di(this,a),!1):!0},a);for(var e=0;e<c.length;e++){var f=c[e];e>=d?Di(a,f):_.U(f,"gb_bb")}},Di=function(a,c){_.T(c,"gb_bb");var d=_.Ad("LI");_.zg(d,["gb_re","gb_vc","gb_Bc"]);_.sh(d,!0);_.Eg(a.Y,d,Ai(c));var e=_.Q("A","gb_yc");d.appendChild(e);var f=_.Q("SPAN","gb_zc");e.appendChild(f);e=c.b?c.getAttribute("aria-label"):c.title;_.Gf(f,e);e=!1;_.S(c,"gb_zf")&&(e=!0);var g,h=c.children[0];e?g=h.children[0].children[0].src:c.b?g="https://www.gstatic.com/images/icons/material/system/1x/search_black_24dp.png":
g=h.src;a.w=_.Q("IMG");_.zg(a.w,["gb_Ac","gb_se"]);a.w.setAttribute("src",g);f.parentNode&&f.parentNode.insertBefore(a.w,f);a.V.appendChild(d)};X.prototype.vb=function(a){!_.S(this.R,"gb_bb")&&a.target instanceof window.Node&&("keydown"==a.type?27==a.keyCode&&(a.preventDefault(),a.stopPropagation(),_.T(this.R,"gb_bb"),this.G().focus()):_.Ff(this.R,a.target)||("touchstart"==a.type&&(a.preventDefault(),a.stopPropagation()),_.T(this.R,"gb_bb")))};
X.prototype.Ib=function(){pi(this,this.D.b);this.b&&_.Ei(this,this.b.Hb(),!1);this.dispatchEvent("ffc")};_.Ei=function(a,c,d){a.b&&(ai(a.b)&&(c=!1),a=window.document.body,_.V(a,"gb_ne",c),_.V(a,"gb_me",d))};X.prototype.Kb=function(){_.Ei(this,!0,!0)};X.prototype.Jb=function(){_.Ei(this,!1,!0)};X.prototype.Lb=function(){var a=this.b.b;ai(this.b)?_.P("gb_ie",void 0).appendChild(a):this.j.appendChild(a)};_.xi=function(a){return!!a.b&&(a.Ca?_.S(a.A,"gb_7d"):a.A.parentNode!=a.o)};
X.prototype.$=function(a){var c=!1;switch(a){case "back":this.N=!0;ci(this.b);bi(this.b,"back");c=!0;break;case "close":this.N=!0;ci(this.b);bi(this.b,"close");c=!0;break;case "default":this.N=!1;wi(this,this.D.b)||this.Ob?(this.b&&!this.b.ua("menu")&&(ci(this.b),bi(this.b,"menu")),c=!0):(this.b&&this.b.ua("back")&&ci(this.b),this.b&&this.b.ua("menu")?(a=this.b,a.close(),_.T(a.G(),"gb_bb"),di(a.A)&&_.U(a.G(),"gb_nc")):(a=_.P("gb_jc",this.j))&&_.T(a,"gb_bb"),c=!1);break;case "none":this.N=!0,ci(this.b),
c=!1}null!=this.B&&_.V(this.B,"gb_xe",c)};var wi=function(a,c){var d="gb_Za"==c;c="gb_Jd"==c;var e=_.G(_.B(a.f,5),!1),f=_.G(_.B(a.f,2),!1);return!(_.G(_.B(a.f,10),!1)||a.ya)&&f&&(d||c&&(e||a.P))};X.prototype.getHeight=function(){return this.j.offsetHeight};_.zi=function(a){var c=a.getHeight()+"px";a.Za!=c&&(a.Za=c,a.Ab&&(a.Ab.style.height=c),a.dispatchEvent("resize"))};X.prototype.Qb=function(){this.M&&_.zi(this)};
X.prototype.Ua=function(){if(!this.M){var a=_.Ad("DIV");_.zg(a,["gb_Md","gb_be"]);Fi(a,si(this));a.style.backgroundColor=this.Na();this.H.push(a);var c=this.o;c.parentNode&&c.parentNode.insertBefore(a,c.nextSibling);this.M=a}return this.M};X.prototype.$b=function(){_.Bd(this.M);this.M=null;_.zi(this)};_.Gi=function(a,c){a.o&&a.o.appendChild(c)};X.prototype.dg=function(a){for(var c=0;c<this.H.length;c++)Fi(this.H[c],a);ti(this,a)};
var ti=function(a,c){if(a.L){if(2==c){c=_.H(_.B(a.f,24),"");var d=_.H(_.B(a.f,27),"")}else 1==c?(c=_.H(_.B(a.f,23),""),d=_.H(_.B(a.f,26),"")):(c=_.H(_.B(a.f,22),""),d=_.H(_.B(a.f,25),""));""==c&&""==d||ih(a.L,c,d)}},si=function(a){a=a.H[0];return a.classList.contains("gb_de")?1:a.classList.contains("gb_ce")?2:0},Fi=function(a,c){_.Ag(a,["gb_ce","gb_de"]);1==c?_.T(a,"gb_de"):2==c&&_.T(a,"gb_ce")};X.prototype.Oc=function(a){for(var c=0;c<this.H.length;c++)this.H[c].style.backgroundColor=a};
X.prototype.Na=function(){return this.H[0].style.backgroundColor};X.prototype.ka=function(){var a=_.Id("dd");_.$g(a)&&_.$g(a).$c(!1);a.Md(null)};X.prototype.Sd=function(a){ki(this,a-8);vi(this)};var ki=function(a,c){if(null==a.C)throw Error("I");if(a.U)throw Error("J");if(0>c)throw Error("K");a.yb=c},vi=function(a){null!=a.B&&("gb_Za"==a.D.b?_.Uf(a.B,"min-width",""):null!=a.yb&&_.Uf(a.B,"min-width",a.yb+"px"))};X.prototype.Ja=function(a){_.V(_.P("gb_cc",this.o),"gb_bb",!a)}; var ri=function(a,c){a.F&&(null!=a.B&&_.V(a.B,"gb_Xd",c),null!=a.S&&_.V(a.S,"gb_bb",c||!a.P))};X.prototype.bc=function(a){if(a){var c=_.P("gb_Fa");null!=c&&_.ch(c,a);_.J.ra().j.then(function(c){c.Pf(a)})}};
var Hi;var Ii=_.P("gb_Xa");
if(null==Ii)Hi=null;else{var Ji=_.E(_.oc,eh,6)||new eh,Ki=new X(Ii,Ji,_.K,_.P("gb_Id"));_.u("gbar.P",X);X.prototype.pa=X.prototype.getHeight;X.prototype.pb=X.prototype.hj;X.prototype.pc=X.prototype.dg;X.prototype.pd=X.prototype.Oc;X.prototype.pe=X.prototype.Ua;X.prototype.pf=X.prototype.Qb;X.prototype.pg=X.prototype.$b;X.prototype.ph=X.prototype.Ug;X.prototype.pi=X.prototype.ka;X.prototype.pj=X.prototype.Sd;X.prototype.pk=X.prototype.Ja;X.prototype.pl=X.prototype.bc;X.prototype.pm=X.prototype.$;X.prototype.pn= X.prototype.Na;X.prototype.po=X.prototype.fj;_.me(_.J.ra().f,Ki);Hi=Ki}_.Y=Hi;

}catch(e){_._DumpException(e)}
/* _Module_:qaid */
try{
var Li=window.document.querySelector(".gb_jb .gb_b");Li&&_.Pc(_.yc,Li,"click");
}catch(e){_._DumpException(e)}
/* _Module_:qalo */
try{
(function(){for(var a=window.document.querySelectorAll(".gb_fc"),c=0;c<a.length;c++)_.Pc(_.yc,a[c],"click");_.J.ra().f.then(function(a){if(a){var c=_.P("gb_cc",a.o);c&&(c=new _.Yg(c,_.K,_.uc),a.ej(c))}})})();
}catch(e){_._DumpException(e)}
/* _Module_:qano */
try{
var Mi=window.document.querySelector(".gb_Nc");if(Mi){var Ni=Mi.querySelector(".gb_b");Ni&&_.Pc(_.yc,Ni,"click")};
}catch(e){_._DumpException(e)}
/* _GlobalSuffix_ */
})(this.gbar_);
// Google Inc.
</script></div></div></div></div><div aria-hidden="true" class="drive-viewer-details-panel drive-viewer-details-panel-hidden"><div class="drive-viewer-details-header"><div aria-activedescendant="dvdt_goog_1622930334" aria-label="Barra de pestañas del panel de detalles. Para cambiar de pestaña, pulsa las flechas hacia la derecha y hacia la izquierda." role="tablist" style="-moz-user-select: none;" class="drive-viewer-details-tabbar drive-viewer-details-tabbar-horizontal drive-viewer-details-tabbar-top"><div tabindex="0" id="dvdt_goog_1622930334" aria-selected="true" style="-moz-user-select: none;" role="tab" class="drive-viewer-details-tab drive-viewer-details-tab-hover drive-viewer-details-tab-selected">Detalles</div><div aria-hidden="true" id="dvdt_goog_1622930335" aria-selected="false" style="-moz-user-select: none; display: none;" role="tab" class="drive-viewer-details-tab drive-viewer-details-tab-indicator">Comentarios</div></div><div data-tooltip="Ocultar detalles" aria-label="Ocultar detalles" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" tabindex="0" style="-moz-user-select: none;" role="button" class="drive-viewer-close-button drive-viewer-dark-button drive-viewer-button"><div class="drive-viewer-icon drive-viewer-nav-icon"></div></div></div><div class="drive-viewer-details-content drive-viewer-scrollable"><div aria-labelledby="dvdt_goog_1622930334" style="" class="drive-viewer-details-info-view" role="tabpanel"><div style="" class="drive-viewer-details-subpane" role="region" aria-label="Información general" tabindex="-1"><div class="drive-viewer-details-subpane-header"><span class="drive-viewer-details-subpane-header-text" role="heading">Información general</span><div class="drive-viewer-details-subpane-separator-container"><div class="drive-viewer-details-subpane-separator"></div></div></div><div aria-hidden="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-dark-button drive-viewer-details-edit-button drive-viewer-button"><div class="drive-viewer-icon"></div></div><div class="drive-viewer-details-subpane-content"><div class="drive-viewer-details-info-subpane"><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Tipo</div><div class="drive-viewer-details-subpane-item">JavaScript</div></div><div style="display: none;" class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Dimensiones</div><div class="drive-viewer-details-subpane-item"></div></div><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Tamaño</div><div class="drive-viewer-details-subpane-item">314 KB</div></div><div style="display: none;" class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Duración</div><div class="drive-viewer-details-subpane-item"></div></div><div style="display: none;" class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Ubicación</div><div class="drive-viewer-details-subpane-item"><div class="drive-viewer-details-location-items"></div></div></div><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Modificado</div><div class="drive-viewer-details-subpane-item">19 dic. 2016 a las 22:02</div></div><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Creado</div><div class="drive-viewer-details-subpane-item">28 ago. 2016 a las 5:47</div></div><div style="display: none;" class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-info-label">Abierto por mí</div><div class="drive-viewer-details-subpane-item"></div></div></div></div></div><div style="" class="drive-viewer-details-subpane" role="region" aria-label="Uso compartido" tabindex="-1"><div class="drive-viewer-details-subpane-header"><span class="drive-viewer-details-subpane-header-text" role="heading">Uso compartido</span><div class="drive-viewer-details-subpane-separator-container"><div class="drive-viewer-details-subpane-separator"></div></div></div><div aria-hidden="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-dark-button drive-viewer-details-edit-button drive-viewer-button"><div class="drive-viewer-icon"></div></div><div class="drive-viewer-details-subpane-content"><div class="drive-viewer-details-info-subpane"><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-permission-label"><div class="drive-viewer-details-permission-avatar"><div data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" aria-label="Cualquier usuario con el enlace" data-tooltip="Cualquier usuario con el enlace" class="drive-viewer-details-default-avatar-thumbnail"><div class="drive-viewer-icon drive-viewer-details-avatar-icon drive-viewer-details-anyone-avatar-with-link" role="img"></div></div></div><div data-tooltip-only-on-overflow="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" data-tooltip="Cualquier usuario con el enlace" class="drive-viewer-details-permission-name">Cualquier usuario con el enlace</div></div><div class="drive-viewer-details-permission-role">Puede ver</div></div><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-subpane-label drive-viewer-details-permission-label"><div class="drive-viewer-details-permission-avatar"><img data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" aria-label="arafkarim01@gmail.com" data-tooltip="arafkarim01@gmail.com" class="drive-viewer-details-comment-avatar" alt="" src="jspdf.js%20-%20Google%20Drive_files/photo.jpg" role="img"></div><div data-tooltip-only-on-overflow="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" data-tooltip="Araf Karim" class="drive-viewer-details-permission-name">Araf Karim</div></div><div class="drive-viewer-details-permission-role">Propietario</div></div></div></div></div><div style="" class="drive-viewer-details-subpane" role="region" aria-label="Descripción" tabindex="-1"><div class="drive-viewer-details-subpane-header"><span class="drive-viewer-details-subpane-header-text" role="heading">Descripción</span><div class="drive-viewer-details-subpane-separator-container"><div class="drive-viewer-details-subpane-separator"></div></div></div><div data-tooltip="Editar descripción" aria-label="Editar descripción" aria-hidden="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-dark-button drive-viewer-details-edit-button drive-viewer-button"><div class="drive-viewer-icon"></div></div><div class="drive-viewer-details-subpane-content"><div><div class="drive-viewer-details-description">Sin descripción</div><textarea style="display: none;" class="drive-viewer-details-description-edit drive-viewer-scrollable" role="textbox" aria-multiline="true"></textarea></div></div></div><div style="" class="drive-viewer-details-subpane" role="region" aria-label="Permiso de descarga" tabindex="-1"><div class="drive-viewer-details-subpane-header"><span class="drive-viewer-details-subpane-header-text" role="heading">Permiso de descarga</span><div class="drive-viewer-details-subpane-separator-container"><div class="drive-viewer-details-subpane-separator"></div></div></div><div aria-hidden="true" data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" style="-moz-user-select: none; display: none;" role="button" class="drive-viewer-dark-button drive-viewer-details-edit-button drive-viewer-button"><div class="drive-viewer-icon"></div></div><div class="drive-viewer-details-subpane-content"><div class="drive-viewer-details-info-row"><div class="drive-viewer-details-download-permission-message" id="dvddp_goog_1622930333">Los lectores pueden descargar</div></div></div></div><div></div></div><div aria-labelledby="dvdt_goog_1622930335" style="display: none;" class="drive-viewer-details-comments-view" role="tabpanel"></div></div></div><div role="alertdialog" style="display: none;" class="drive-viewer-comment-callout-mask"><div class="drive-viewer-comment-callout"><div data-tooltip-offset="-6" data-tooltip-align="b,c" data-tooltip-class="drive-viewer-jfk-tooltip" data-tooltip-delay="500" data-tooltip-unhoverable="true" tabindex="0" style="-moz-user-select: none;" role="button" class="drive-viewer-comment-callout-button drive-viewer-button"><div class="drive-viewer-comment-callout-button-circle"><div class="drive-viewer-comment-callout-button-icon drive-viewer-icon drive-viewer-custom-button-icon"></div></div></div><h2 class="drive-viewer-comment-callout-header">Añadir un comentario</h2><p class="drive-viewer-comment-callout-message">Toca aquí para comentar este archivo con otros usuarios</p></div></div></div><span aria-hidden="true" tabindex="0" style="" class="drive-viewer-tab-sentinel"></span><div ng-non-bindable=""><div class="gb_De"></div><div class="gb_kc">Menú principal</div></div><script>/* _GlobalPrefix_ */
this.gbar_=this.gbar_||{};(function(_){var window=this;
/* _Module_:qebr */
try{
if(_.Y){var Oi=_.Y,Pi;if(Pi=_.B(Oi.f,3))for(var Qi=_.kh(Pi),Ri=0;Ri<Qi.length;Ri++)_.wh(Qi[Ri],"ogpc","");_.Ei(Oi,!!Oi.b&&Oi.b.Hb(),!1)};
}catch(e){_._DumpException(e)}
/* _Module_:sy13 */
try{
_.Si=function(a){_.A(this,a,0,-1,null)};_.v(_.Si,_.z);_.Ti=function(a){_.cd("From proto message. b/12014412");a=_.B(a,4)||"";return _.jd(a)};
}catch(e){_._DumpException(e)}
/* _Module_:qein */
try{
var Ui=function(a){_.A(this,a,0,-1,null)};_.v(Ui,_.z);
var Vi=_.E(_.oc,Ui,17)||new Ui,Wi,Xi=(Wi=_.E(Vi,_.Si,1))?_.Ti(Wi):null,Yi,Zi=(Yi=_.E(Vi,_.Si,2))?_.Ti(Yi):null,$i=function(a,c,d){_.uc.log(46,{att:a,max:c,url:d})},bj=function(a,c,d){_.uc.log(47,{att:a,max:c,url:d});a<c?aj(a+1,c):_.K.log(Error("L`"+a+"`"+c),{url:d})},aj=function(a,c){if(Xi){var d=_.Ad("SCRIPT");d.async=!0;d.type="text/javascript";d.charset="UTF-8";_.xd(d,Xi);d.onload=_.Rc($i,a,c,d.src);d.onerror=_.Rc(bj,a,c,d.src);_.uc.log(45,{att:a,max:c,url:d.src});_.zd("HEAD")[0].appendChild(d)}};
aj(1,2);if(Zi){var cj=_.Ad("LINK");cj.setAttribute("type","text/css");cj.rel="stylesheet";cj.href=_.id(Zi);_.zd("HEAD")[0].appendChild(cj)};
}catch(e){_._DumpException(e)}
/* _GlobalSuffix_ */
})(this.gbar_);
// Google Inc.
</script><iframe aria-hidden="true" tabindex="-1" style="width: 1px; height: 1px; position: absolute; top: -100px;" src="jspdf.js%20-%20Google%20Drive_files/postmessageRelay.html" id="oauth2relay227067264" name="oauth2relay227067264"></iframe><iframe aria-hidden="true" tabindex="-1" src="jspdf.js%20-%20Google%20Drive_files/proxy.html" style="width: 1px; height: 1px; position: absolute; top: -100px; display: none;" name="apiproxyeebe1320f446b7458f3b41692156a85e328834e30.3634935618" id="apiproxyeebe1320f446b7458f3b41692156a85e328834e30.3634935618"></iframe><div class="gb_ve"><div class="gb_ue"><div>Cuenta de Google</div><div class="gb_Hb">Jose Antonio Albalat</div><div>proyectojosealbalat@gmail.com</div></div></div><iframe aria-hidden="true" tabindex="-1" src="jspdf.js%20-%20Google%20Drive_files/proxy_002.html" style="width: 1px; height: 1px; position: absolute; top: -100px; display: none;" name="apiproxy5aff79ef67bbaa07de8efc8a2f761845d0cc60a20.3384469243" id="apiproxy5aff79ef67bbaa07de8efc8a2f761845d0cc60a20.3384469243"></iframe><div aria-atomic="true" aria-live="polite" style="position: absolute; top: -1000px; height: 1px; overflow: hidden;">Mostrando jspdf.js.</div></body></html>
#include <stdio.h>

int main() {
int i;
int * pi;

i=2;
pi=&i;

printf("%p ",&pi);
}
